#!/bin/sh

# Command to use:
#Installation.sh [Path_working_directory] [Path_to_assembly_folder] [Path_to_query_folder]

# Definition of the access path to the working directory:
Path_working_directory=$1

# Definition of the access path to the assembly directory:
Path_to_assembly_folder=$2

# Definition of the access path to the query directory:
Path_to_query_folder=$2

# Creation of initial directories:
mkdir $Path_working_directory/assemblies
mkdir $Path_working_directory/annotation
mkdir $Path_working_directory/annotation/queries

# Recovery of assemblies
cp $Path_to_assembly_folder/* $Path_working_directory/assemblies/

# Recovery of assemblies
cp $Path_to_query_folder/* $Path_working_directory/annotation/queries/
