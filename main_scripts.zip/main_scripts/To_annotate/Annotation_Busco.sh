#!/bin/sh

# Command to use:
#Annotation_Busco.sh [Path_working_directory] [CPU] [odb_BUSCO]

# Definition of the access path to the working directory:
Path_working_directory=$1

# Definition of the number of CPUs:
CPU=$2

# odb library
odb=$3

# Creation of directories for Busco annotation:
mkdir $Path_working_directory/annotation/busco
mkdir $Path_working_directory/annotation/busco/busco_outputs

# bbmap path
#export PATH=$PATH:/bin/bbmap/

# Execution of the annotation
counter=1; for assembly_path in $(ls $Path_working_directory/assemblies/*); do assembly_file=$(basename "$assembly_path"); sp=$(echo "$assembly_file" | cut -d '_' -f2-3); echo "START: ${sp}"; echo "Species n°$counter"; busco -i ${assembly_path} --out_path $Path_working_directory/annotation/busco/busco_outputs/ -o busco_${sp} -l $odb -m genome -c $CPU; ((counter++)); done

# Creation of a csv file summarising busco results for all species
echo "Species;Number_of_complete_and_single_copy_BUSCOs_(S);Percentage_of_complete_and_single_copy_BUSCOs_(S)" > $Path_working_directory/annotation/busco/busco_results_summary.csv; for dir in $(ls $Path_working_directory/annotation/busco/busco_outputs/); do if [ ! -d "$dir" ]; then echo "$dir is not a directory"; elif [ "$dir" == "busco_downloads" ]; then echo "$dir is equal to 'busco_downloads'"; else num_S=$(grep "Complete and single-copy BUSCOs (S)" $Path_working_directory/annotation/busco/busco_outputs/$dir/short_summary*.txt | sed 's/^[[:space:]]*\([0-9]\+\).*$/\1/'); percent_S=$(grep -E 'C:[0-9]+(\.[0-9]+)?%\[S:[0-9]+(\.[0-9]+)?%,D:[0-9]+(\.[0-9]+)?%\],F:[0-9]+(\.[0-9]+)?%,M:[0-9]+(\.[0-9]+)?%,n:[0-9]+' $Path_working_directory/annotation/busco/busco_outputs/$dir/short_summary*.txt | sed 's/.*S:\([0-9.]\+\)%,.*/\1/'); echo "$dir;$num_S;$percent_S" >> $Path_working_directory/annotation/busco/busco_results_summary.csv; fi; done
