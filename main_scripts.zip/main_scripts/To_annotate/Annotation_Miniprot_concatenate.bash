#!/bin/sh

# Command to use:
#Annotation_Miniprot_concatenate.bash [Path_working_directory]

# Definition of the access path to the working directory:
Path_working_directory=$1

# Species used to query for Miniprot:
sp1=One
sp2=Two
sp3=Thr

# reuniting gff output files and transforming into fasta files:
for assembly_path in $(ls $Path_working_directory/assemblies/*); do 
    # keep basename
    assembly_file=$(basename "$assembly_path");
    # keep the species name
    sp=$(echo "$assembly_file" | cut -d '_' -f2-3);
    # create a directory for each species
    mkdir $Path_working_directory/annotation/miniprot/miniprot_query_cat/gfftofasta_${sp};
    # move into the species directory
    cd $Path_working_directory/annotation/miniprot/miniprot_query_cat/gfftofasta_${sp};
    
    echo "SUMMARY FILE: concatenation of Miniprot outputs" >> concatenation_${sp}.out;
    echo "SPECIES: $sp" >> concatenation_${sp}.out;
    echo "INFO: gfftogff_${sp} directory has been created" >> concatenation_${sp}.out;
    
    # copy gff files
    cp $Path_working_directory/annotation/miniprot/miniprot_query_${sp1}/miniprot_${sp}.gff $Path_working_directory/annotation/miniprot/miniprot_query_cat/gfftofasta_${sp}/miniprot_${sp}_${sp1}.gff;
    cp $Path_working_directory/annotation/miniprot/miniprot_query_${sp2}/miniprot_${sp}.gff $Path_working_directory/annotation/miniprot/miniprot_query_cat/gfftofasta_${sp}/miniprot_${sp}_${sp2}.gff;
    cp $Path_working_directory/annotation/miniprot/miniprot_query_${sp3}/miniprot_${sp}.gff $Path_working_directory/annotation/miniprot/miniprot_query_cat/gfftofasta_${sp}/miniprot_${sp}_${sp3}.gff;
    echo "INFO: GFF files from references $sp1, $sp2 and $sp3 have been copied" >> concatenation_${sp}.out;
    
    # extract CDS and rename gene
    grep -P "\tCDS\t" miniprot_${sp}_${sp1}.gff | sed "s/;Rank/_${sp1};Rank/" | bedtools sort > ${sp}_${sp1}_CDS.gff;
    grep -P "\tCDS\t" miniprot_${sp}_${sp2}.gff | sed "s/;Rank/_${sp2};Rank/" | bedtools sort > ${sp}_${sp2}_CDS.gff;
    grep -P "\tCDS\t" miniprot_${sp}_${sp3}.gff | sed "s/;Rank/_${sp3};Rank/" | bedtools sort > ${sp}_${sp3}_CDS.gff;
    
    bedtools window -a ${sp}_${sp1}_CDS.gff -b ${sp}_${sp1}_CDS.gff -w 0 > tmp;
    $Path_working_directory/scripts/listAlternativeTranscript2.py tmp > tmp2;
    $Path_working_directory/scripts/ExcludeCDSFromGFF.py ${sp}_${sp1}_CDS.gff ./tmp2 > ${sp}_${sp1}_CDS_clean.gff;
    
    bedtools window -a ${sp}_${sp2}_CDS.gff -b ${sp}_${sp2}_CDS.gff -w 0 > tmp;
    $Path_working_directory/scripts/listAlternativeTranscript2.py tmp > tmp2;
    $Path_working_directory/scripts/ExcludeCDSFromGFF.py ${sp}_${sp2}_CDS.gff ./tmp2 > ${sp}_${sp2}_CDS_clean.gff;
    
    bedtools window -a ${sp}_${sp3}_CDS.gff -b ${sp}_${sp3}_CDS.gff -w 0 > tmp;
    $Path_working_directory/scripts/listAlternativeTranscript2.py tmp > tmp2;
    $Path_working_directory/scripts/ExcludeCDSFromGFF.py ${sp}_${sp3}_CDS.gff ./tmp2 > ${sp}_${sp3}_CDS_clean.gff;
    
    cat ${sp}_${sp1}_CDS_clean.gff ${sp}_${sp2}_CDS_clean.gff ${sp}_${sp3}_CDS_clean.gff | bedtools sort > ${sp}_${sp1}${sp2}${sp3}_CDS.gff;
    
    bedtools window -a ${sp}_${sp1}${sp2}${sp3}_CDS.gff -b ${sp}_${sp1}${sp2}${sp3}_CDS.gff -w 0 > tmp;
    $Path_working_directory/scripts/listAlternativeTranscript2.py tmp > tmp2
    $Path_working_directory/scripts/ExcludeCDSFromGFF.py ${sp}_${sp1}${sp2}${sp3}_CDS.gff ./tmp2 > ${sp}_${sp1}${sp2}${sp3}_CDS_clean.gff;
    
    nb_CDS=$(cut -f9 ${sp}_${sp1}${sp2}${sp3}_CDS.gff | cut -d";" -f1 | sort -u | wc -l);
    echo "INFO: The GFF file contains $nb_CDS cds" >> concatenation_${sp}.out;
    
    nb_CDS_clean=$(cut -f9 ${sp}_${sp1}${sp2}${sp3}_CDS_clean.gff | cut -d";" -f1 | sort -u | wc -l);
    echo "INFO: The cleaned GFF file contains $nb_CDS_clean cds" >> concatenation_${sp}.out;
    
    # puts the gene's name in column 3 of the GFF
    $Path_working_directory/scripts/putIDinNameGFF.py -f ${sp}_${sp1}${sp2}${sp3}_CDS_clean.gff > ${sp}_exon.gff;

    # converts GFF to exons
    bedtools getfasta -s -name -fi $assembly_path -bed ${sp}_exon.gff > ${sp}_exons.fasta;
    
    cut -d"_" -f1,2 ${sp}_exons.fasta > tmp && mv tmp ${sp}_exons.fasta;

    # concatenates exons to transcripts
    $Path_working_directory/scripts/concateExonFromBedtoolsGetFasta2_forCat.py ${sp}_exons.fasta > ${sp}_Transcript.fasta;
    
    # sort the gff
    bedtools sort -i ${sp}_exon.gff > ${sp}_exon_sort.gff;

    # retrieve list of gene without overlapping exons
    $Path_working_directory/scripts/SelectOverlappingExonGFFsort_forCat.py ${sp}_exon_sort.gff > ${sp}_gene2keep.txt;

    # copy unique transcripts
    $Path_working_directory/scripts/SelectSeq.py -l ${sp}_gene2keep.txt -f ${sp}_Transcript.fasta -c partial -o ${sp}_Transcript_uniq.fasta;

    transeq -sequence ${sp}_Transcript_uniq.fasta -outseq ${sp}_Transcript_uniq.faa;
    
    nb_Transcript_uniq=$(grep -c "^>" ${sp}_Transcript_uniq.faa);
    echo "INFO: The FASTA file contains $nb_Transcript_uniq transcripts" >> concatenation_${sp}.out;
    
    grep '^>' ${sp}_Transcript_uniq.faa > List_Transcript_uniq.txt;
    
    sed -i 's/>//' List_Transcript_uniq.txt;
    
    sort List_Transcript_uniq.txt > List_Transcript_uniq_sort.txt;
    
    touch List_Transcript_uniq_rename.txt;
    
    $Path_working_directory/scripts/RenameTranscriptRedundants_forList.py List_Transcript_uniq_sort.txt List_Transcript_uniq_rename.txt;
    
    touch ${sp}_Transcript_uniq_rename.faa;
    
    $Path_working_directory/scripts/RenameTranscriptRedundants_forFasta.py ${sp}_Transcript_uniq.faa ${sp}_Transcript_uniq_rename.faa;
    
    $Path_working_directory/scripts/SelectSeq.py -f ${sp}_Transcript_uniq_rename.faa -l List_Transcript_uniq_rename.txt -c partial -o ${sp}_Transcript_uniq_seqperline.faa;
    
    grep -A1 -E '>[M][P][0-9]{6}_[A-Za-z]{4}_1' ${sp}_Transcript_uniq_seqperline.faa > ${sp}_Transcript_uniq_final.faa;
    
    nb_Transcript_uniq_final=$(grep -c "^>" ${sp}_Transcript_uniq_final.faa);
    echo "INFO: The final FASTA file contains $nb_Transcript_uniq_final unique transcripts" >> concatenation_${sp}.out;
    
    sed -i "s/>/>Miniprot_${sp}_/" ${sp}_Transcript_uniq_final.faa;
        
done
    
