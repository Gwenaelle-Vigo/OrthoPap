#!/bin/sh

# Command to use:
#Annotation_Miniprot.sh [Path_working_directory] [CPU]

# Definition of the access path to the working directory:
Path_working_directory=$1

# Definition of the number of CPUs:
CPU=$2

# Creation of directories for Busco annotation:
mkdir $Path_working_directory/annotation/miniprot
mkdir $Path_working_directory/annotation/miniprot/miniprot_mpi
mkdir $Path_working_directory/annotation/miniprot/miniprot_query_one
mkdir $Path_working_directory/annotation/miniprot/miniprot_query_two
mkdir $Path_working_directory/annotation/miniprot/miniprot_query_thr
mkdir $Path_working_directory/annotation/miniprot/miniprot_query_cat

# Annotation with the first query:
counter=1; for assembly_path in $(ls $Path_working_directory/assemblies/*); do assembly_file=$(basename "$assembly_path"); sp=$(echo "$assembly_file" | cut -d '_' -f2-3); echo "START: ${sp}"; echo "Species n°$counter"; miniprot -t$CPU -d $Path_working_directory/annotation/miniprot/miniprot_mpi/genome_${sp}.mpi ${assembly_path}; miniprot -Iut$CPU --gff $Path_working_directory/annotation/miniprot/miniprot_mpi/genome_${sp}.mpi $Path_working_directory/annotation/queries/query_one.fasta > $Path_working_directory/annotation/miniprot/miniprot_query_one/miniprot_${sp}.gff; ((counter++)); done

# Annotation with the second query:
counter=1; for assembly_path in $(ls $Path_working_directory/assemblies/*); do assembly_file=$(basename "$assembly_path"); sp=$(echo "$assembly_file" | cut -d '_' -f2-3); echo "START: ${sp}"; echo "Species n°$counter"; miniprot -Iut$CPU --gff $Path_working_directory/annotation/miniprot/miniprot_mpi/genome_${sp}.mpi $Path_working_directory/annotation/queries/query_two.fasta > $Path_working_directory/annotation/miniprot/miniprot_query_two/miniprot_${sp}.gff; ((counter++)); done

# Annotation with the thrid query:
counter=1; for assembly_path in $(ls $Path_working_directory/assemblies/*); do assembly_file=$(basename "$assembly_path"); sp=$(echo "$assembly_file" | cut -d '_' -f2-3); echo "START: ${sp}"; echo "Species n°$counter"; miniprot -Iut$CPU --gff $Path_working_directory/annotation/miniprot/miniprot_mpi/genome_${sp}.mpi $Path_working_directory/annotation/queries/query_thr.fasta > $Path_working_directory/annotation/miniprot/miniprot_query_thr/miniprot_${sp}.gff; ((counter++)); done

