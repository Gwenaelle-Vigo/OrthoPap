#!/bin/bash

if [ "$#" -ne 2 ]; then
  echo "Usage: $0 Orthogroup_Sequences_txt List_orthogroup_names_one_paralog_sister.txt"
  exit 1
fi

input_folder="$1"
input_folder=${input_folder%/}

list_OG="$2"

species="Baronia_brevicornis Battus_polydamas Bhutanitis_thaidina Byasa_hedistus Graphium_agamemnon Graphium_antheus Graphium_antiphates Graphium_doson Iphiclides_podalirius Lamproptera_curius Luehdorfia_chinensis Meandrusa_payeni Ornithoptera_alexandrae Ornithoptera_priamus Pachliopta_arisolochiae Papilio_bianor Papilio_demoleus Papilio_elwesi Papilio_machaon Papilio_protenor Papilio_xuthus Parides_eurimedes Parides_vertumnus Parnassius_apollo Parnassius_orleans Pharmacophagus_antenor Sericinus_montela Teinopalpus_imperialis Troides_helena Troides_oblongomaculatus"

files_modified=0

for OG in $(cat $list_OG); do

  file_path="${input_folder}/${OG}.txt";
  
  for sp in $species; do
  
    nb_gene=$(grep -o "$sp" $file_path | wc -l);
    
    if [ "$nb_gene" -eq 2 ]; then
      genes=$(grep -o "$sp" $file_path)
      echo "Suppression des genes $genes chez l'espece $sp dans le fichier $OG."
      files_modified=$((files_modified + 1))
      sed -i "/$sp/d" $file_path;
      echo "Jusqu'ici $files_modified fichiers ont ete modifie."
      break
    fi
  
  done

done

echo "Il y a $files_modified fichiers pour lesquels une espece a ete retire."
