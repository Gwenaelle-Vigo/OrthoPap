#! /usr/bin/env python3

import sys

gff = open(sys.argv[1])


gene2Exclude = {}
gene2Keep = {}
# loop over the GFF
for li in gff:
	li = li.rstrip()
	
	# split the line according to the "tab"
	arrli = li.split()


	gene1 = arrli[8].split(";")[0]
	gene2 = arrli[19].split(";")[0]

	if gene1 == gene2:
		continue
	
	if gene1 in gene2Exclude and gene2 not in gene2Keep:
		gene2Exclude[gene2] = 1
		continue
	elif gene1 in gene2Exclude and gene2 in gene2Keep:
		continue
		
	if gene1 != gene2:
		if gene2 not in gene2Exclude:
			gene2Exclude[gene2] = 1
			gene2Keep[gene1] = 1
			
for gene in gene2Exclude:
	print(gene)
