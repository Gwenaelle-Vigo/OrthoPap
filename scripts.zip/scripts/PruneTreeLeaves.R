#!/usr/bin/env Rscript

# Installer le package 'ape' si ce n'est pas déjà fait
if (!requireNamespace("ape", quietly = TRUE)) {
  install.packages("ape")
}

# Charger le package 'ape'
library(ape)

# Vérifier les arguments en ligne de commande
args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 2) {
  stop("2 arguments must be supplied: [1] folder_path [2] species_file", call. = FALSE)
}

folder_path <- args[1]  # path to the folder containing .tre files
file_path <- args[2]    # path to the file containing species to be removed for each .tre file

# Lire le fichier texte et créer une liste
remove_leaves_list <- read.table(file_path, header = FALSE, comment.char = "#", sep = "\t", stringsAsFactors = FALSE)

# Ajouter "_macse_final_mask_align_NT.aln.treefile" à tous les noms d'arbre
remove_leaves_list$V1 <- paste0(remove_leaves_list$V1, "_macse_final_mask_align_NT.aln.treefile")

# Regrouper les feuilles par arbre dans une liste
remove_leaves_groups <- split(remove_leaves_list$V2, remove_leaves_list$V1)

# Parcourir les fichiers .tre et supprimer les feuilles spécifiées
for (filename in list.files(folder_path, pattern = "^OG.*\\.treefile$")) {
  
  # Si le fichier .tre n'a pas besoin d'être modifié passer au suivant
  if (!(filename %in% names(remove_leaves_groups))) {
    next
  }
  
  tree_file <- file.path(folder_path, filename)
  out_tree_name <- sub(".treefile$", "_pruned.treefile", tree_file)
  
  # Lire l'arbre phylogénétique
  phylo <- read.tree(tree_file)
  
  # Si le fichier .tre contiendra moins de cinq branches après modification, l'afficher et passer au suivant
  if ( ( (Ntip(phylo)) - (length(remove_leaves_groups[[filename]])) ) < 5) {
    filename_remove <- paste0(filename, "_remove")
    cat(filename_remove, "\n")
    next
  }
  
  # Identifier les feuilles à supprimer
  leaves_to_remove <- remove_leaves_groups[[filename]]
  
  # Supprimer les feuilles spécifiées
  pruned_phylo <- drop.tip(phylo, leaves_to_remove)
  
  # Sauvegarder l'arbre phylogénétique pruné
  write.tree(pruned_phylo, file = out_tree_name)
  
  # Afficher le nom du fichier .tre modifié 
  filename_pruned <- paste0(filename, "_pruned")
  cat(filename_pruned, "\n")
}


