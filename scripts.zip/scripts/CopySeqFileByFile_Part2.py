#! /usr/bin/env python3

import sys
import os
import argparse

# Fonction pour lire le fichier FASTA ligne par ligne et extraire les séquences
def read_fasta(fp):
    name, seq = None, []
    for line in fp:
        line = line.rstrip()
        if line.startswith(">"):
            if name:
                yield (name, ''.join(seq))
            name, seq = line, []
        else:
            seq.append(line)
    if name:
        yield (name, ''.join(seq))
        
# Fonction principale pour extraire les séquences en fonction des fichiers d'entrée
def extract_sequences(input_dir, fasta_file, output_dir):
    # Création du répertoire de sortie s'il n'existe pas
    os.makedirs(output_dir, exist_ok=True)
    
    # Liste pour enregistrer les gènes non trouvés dans le fichier FASTA
    genes_not_found = []
    
    # Parcours des fichiers dans le répertoire d'entrée
    for txt_file in os.listdir(input_dir):
        if txt_file.endswith(".txt"):
            txt_file_path = os.path.join(input_dir, txt_file)
            # Obtention du nom de base du fichier sans l'extension
            basename = os.path.splitext(txt_file)[0]
            
            # Afficher le nom du fichier .txt en cours de traitement
            #print(f"Lecture du fichier : {txt_file_path}")
            
            # Chemin du fichier de sortie .fna avec le nom de base du fichier .txt
            output_file = os.path.join(output_dir, f"{basename}.fna")

            # Lecture des noms de gènes à extraire à partir du fichier .txt
            with open(txt_file_path, 'r') as list_file:
                seq_list = list_file.read().splitlines()

            # Ouverture du fichier FASTA pour parcourir les séquences
            with open(fasta_file, 'r') as fp, open(output_file, 'w') as out_f:
                # Ensemble pour enregistrer les gènes du fichier .txt trouvés dans le fichier FASTA
                found_genes = set()
                # Parcours des séquences dans le fichier FASTA
                for name, seq in read_fasta(fp):
                    # Vérification si le nom de gène est présent dans la liste à extraire
                    if name in seq_list:
                        #print(f"Gène {name} trouvé dans le fichier FASTA.")
                        # Écriture de la séquence extraite dans le fichier de sortie .fna
                        out_f.write(name + "\n" + seq + "\n")
                        #print(f"Fichier {output_file} créé avec succès.")

                        # Ajout du nom de gène à l'ensemble des noms de gène trouvés 
                        found_genes.add(name)

                # Trouver les gènes non trouvés dans le fichier FASTA
                not_found = set(seq_list) - found_genes
                genes_not_found.extend(not_found)
                if not_found:
                    print(not_found)

    # Affichage des gènes non trouvés dans la console
    if genes_not_found:
        print("Liste des gènes non trouvés :")
        for gene in genes_not_found:
            print(gene)
        print(f"Nombre de gènes non trouvés : {len(genes_not_found)}")

# Fonction principale pour exécuter le script
def main():
    # Définition des arguments en ligne de commande
    parser = argparse.ArgumentParser()
    parser.add_argument('-i', '--input_dir', action="store", dest="inputDir", type=str)
    parser.add_argument('-f', '--fasta_file', action="store", dest="fastaIn", type=str)
    parser.add_argument('-o', '--output_dir', action="store", dest="outputDir", type=str)
    args = parser.parse_args()

    # Appel de la fonction pour extraire les séquences
    extract_sequences(args.inputDir, args.fastaIn, args.outputDir)

# Appel de la fonction principale si le script est exécuté directement
if __name__ == "__main__":
    main()

