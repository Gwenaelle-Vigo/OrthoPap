#! /usr/bin/env python3

import sys

tsv = open(sys.argv[1])

segments = []
segments_30 = []
segments_29 = []
segments_28 = []
segments_27 = []
segments_26 = []
segments_25 = []
segments_24 = []
segments_23 = []
segments_22 = []
segments_21 = []
segments_20 = []
segments_19 = []
segments_18 = []
segments_17 = []
segments_16 = []
segments_15 = []
segments_14 = []
segments_13 = []
segments_12 = []
segments_11 = []
segments_10 = []
segments_09 = []
segments_08 = []
segments_07 = []
segments_06 = []
segments_05 = []
segments_04 = []
segments_03 = []
segments_02 = []

for line in tsv:
    if line.startswith("Ortho"):
        continue #or print(line)
    
    line = line.rstrip()
    segment = line.split("\t")
    
    #print(segments)
    
    contains_one_2 = all(seg in ('0', '1', '2') for seg in segment[1:31]) and segment[1:31].count('2') == 1
    
    if contains_one_2:
    
    	#print(segment)
    	segments.append(segment)
    	
    	if segment[31] == '31':
    		segments_30.append(segment)
    		
    	elif segment[31] == '30':
    		segments_29.append(segment)
    		
    	elif segment[31] == '29':
    		segments_28.append(segment)
    		
    	elif segment[31] == '28':
    		segments_27.append(segment)
    		
    	elif segment[31] == '27':
    		segments_26.append(segment)
    		
    	elif segment[31] == '26':
    		segments_25.append(segment)
    		
    	elif segment[31] == '25':
    		segments_24.append(segment)
    		
    	elif segment[31] == '24':
    		segments_23.append(segment)
    		
    	elif segment[31] == '23':
    		segments_22.append(segment)
    		
    	elif segment[31] == '22':
    		segments_21.append(segment)
    		
    	elif segment[31] == '21':
    		segments_20.append(segment)
    		
    	elif segment[31] == '20':
    		segments_19.append(segment)
    		
    	elif segment[31] == '19':
    		segments_18.append(segment)
    		
    	elif segment[31] == '18':
    		segments_17.append(segment)
    		
    	elif segment[31] == '17':
    		segments_16.append(segment)
    		
    	elif segment[31] == '16':
    		segments_15.append(segment)
    		
    	elif segment[31] == '15':
    		segments_14.append(segment)
    		
    	elif segment[31] == '14':
    		segments_13.append(segment)
    		
    	elif segment[31] == '13':
    		segments_12.append(segment)
    		
    	elif segment[31] == '12':
    		segments_11.append(segment)
    		
    	elif segment[31] == '11':
    		segments_10.append(segment)
    		
    	elif segment[31] == '10':
    		segments_09.append(segment)
    		
    	elif segment[31] == '9':
    		segments_08.append(segment)
    		
    	elif segment[31] == '8':
    		segments_07.append(segment)
    		
    	elif segment[31] == '7':
    		segments_06.append(segment)
    		
    	elif segment[31] == '6':
    		segments_05.append(segment)
    		
    	elif segment[31] == '5':
    		segments_04.append(segment)
    		
    	elif segment[31] == '4':
    		segments_03.append(segment)
    		
    	elif segment[31] == '3':
    		segments_02.append(segment)

Total = len(segments_30) + len(segments_29) + len(segments_28) + len(segments_27) + len(segments_26) + len(segments_25) + len(segments_24) + len(segments_23) + len(segments_22) + len(segments_21) + len(segments_20) + len(segments_19) + len(segments_18) + len(segments_17) + len(segments_16) + len(segments_15) + len(segments_14) + len(segments_13) + len(segments_12) + len(segments_11) + len(segments_10) + len(segments_09) + len(segments_08) + len(segments_07) + len(segments_06) + len(segments_05) + len(segments_04) + len(segments_03) + len(segments_02)

print(f"Number of orthologues shared by 30 species : {len(segments_30)}")
print(f"Number of orthologues shared by 29 species : {len(segments_29)}")
print(f"Number of orthologues shared by 28 species : {len(segments_28)}")
print(f"Number of orthologues shared by 27 species : {len(segments_27)}")
print(f"Number of orthologues shared by 26 species : {len(segments_26)}")
print(f"Number of orthologues shared by 25 species : {len(segments_25)}")
print(f"Number of orthologues shared by 24 species : {len(segments_24)}")
print(f"Number of orthologues shared by 23 species : {len(segments_23)}")
print(f"Number of orthologues shared by 22 species : {len(segments_22)}")
print(f"Number of orthologues shared by 21 species : {len(segments_21)}")
print(f"Number of orthologues shared by 20 species : {len(segments_20)}")
print(f"Number of orthologues shared by 19 species : {len(segments_19)}")
print(f"Number of orthologues shared by 18 species : {len(segments_18)}")
print(f"Number of orthologues shared by 17 species : {len(segments_17)}")
print(f"Number of orthologues shared by 16 species : {len(segments_16)}")
print(f"Number of orthologues shared by 15 species : {len(segments_15)}")
print(f"Number of orthologues shared by 14 species : {len(segments_14)}")
print(f"Number of orthologues shared by 13 species : {len(segments_13)}")
print(f"Number of orthologues shared by 12 species : {len(segments_12)}")
print(f"Number of orthologues shared by 11 species : {len(segments_11)}")
print(f"Number of orthologues shared by 10 species : {len(segments_10)}")
print(f"Number of orthologues shared by 09 species : {len(segments_09)}")
print(f"Number of orthologues shared by 08 species : {len(segments_08)}")
print(f"Number of orthologues shared by 07 species : {len(segments_07)}")
print(f"Number of orthologues shared by 06 species : {len(segments_06)}")
print(f"Number of orthologues shared by 05 species : {len(segments_05)}")
print(f"Number of orthologues shared by 04 species : {len(segments_04)}")
print(f"Number of orthologues shared by 03 species : {len(segments_03)}")
print(f"Number of orthologues shared by 02 species : {len(segments_02)}")
print(f"TOTAL : {Total}")
