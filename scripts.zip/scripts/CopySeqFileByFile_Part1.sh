#!/bin/bash

#Script 1 : copier les noms de gènes des fichiers contenus dans un dossier d'entrée donné et créer des fichiers avec uniquement les noms de gènes dans un dossier de sortie spécifié.


# Indique le chemin du dossier d'entrée qui contient les fichiers .fa
input_dir=$1

# Indique le chemin du dossier de sortie
output_dir=$2

# Boucle
for filename in $(ls $input_dir); do 

  # Recherche les lignes commençant par ">" dans le fichier d'entrée et les copie dans le fichier de sortie
  grep "^>" ${input_dir}/$filename > ${output_dir}/${filename%.faa}.txt
  
done

#Ce script utilise la commande grep pour extraire les lignes commençant par ">" dans chaque fichier .fa du dossier d'entrée spécifié, puis les écrit dans un nouveau fichier portant le même nom que le fichier d'entrée mais avec l'extension .txt, dans le dossier de sortie spécifié.

#Pour l'executer : ~/programmes/CopySeqFileByFile_Part1.sh <input_directory> <output_directory>
