#!/bin/sh

if [ "$#" -lt 2 ]; then
    echo "Usage: $0 output_PhylteR folder_path"
    exit 1
fi

phylterfile_path="$1"  # path to the file containing species to be removed for each .aln file
folder_path="$2" # path to the folder containing ***aln*** (not folders)
folder_path1="${folder_path%/}"

# Lire le fichier de sortie PhylteR
while IFS=$'\t' read -r line; do
    # Ignorer les lignes commençant par '#'
    if [ "$(echo "$line" | cut -c1)" = "#" ]; then
        continue
    fi
    
    # Extraire les valeurs OG_name et seq_name
    OG_name=$(echo "$line" | cut -f1)
    seq_name=$(echo "$line" | cut -f2)
    
    # Utiliser sed pour supprimer les lignes
    sed -i "/${seq_name}/{N;d;}" $folder_path1/${OG_name}*
    
    echo "$OG_name $seq_name" 

done < "$phylterfile_path"
