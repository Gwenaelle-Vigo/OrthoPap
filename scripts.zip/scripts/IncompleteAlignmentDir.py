#! /usr/bin/env python3

import os
import sys

if len(sys.argv) != 3:
    print("Utilisation: script.py chemin_du_répertoire_de_dossiers nb_fichiers")
    sys.exit(1)

directory_path = sys.argv[1]
number = int(sys.argv[2])

count = 0
empty = 0

for root, dirs, files in os.walk(directory_path):
    nb_files = len(files)
    if root != directory_path:
        if nb_files == 0:
            print(f"Dossier '{root}' ne contient aucun fichier.")
            empty += 1
        elif nb_files < number:
            print(f"Dossier '{root}' contient {nb_files} fichiers.")
            count += 1

print(f"\nNombre total de dossiers vides : {empty}")
print(f"\nNombre total de dossiers contenant moins de {number} fichiers : {count}")

