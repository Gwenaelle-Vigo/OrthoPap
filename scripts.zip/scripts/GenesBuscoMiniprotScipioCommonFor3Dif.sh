#!/bin/bash

comparison=$1
compared_1=$2
compared_2=$3
compared_3=$4

# Lecture du fichier ligne par ligne
while IFS=';' read -r _ aln_1 aln_2 aln_3; do
    # Ignorer l'en-tête du fichier
    if [ "$aln_1" = "OG_Busco" ]; then
    continue
    fi
         
    # Extraction des noms d'OG depuis les noms d'alignement
    OG_aln_1=$(sed 's/_macse_.*//' <<< "$aln_1")
    OG_aln_2=$(sed 's/_macse_.*//' <<< "$aln_2")
    OG_aln_3=$(sed 's/_macse_.*//' <<< "$aln_3")

    # Récupération des noms des genes contenant ">Maker" dans les alignements 
    Oale_1=$(grep -e '^>Maker' ~/Work/Work1/MapNH/MapNH_${compared_1}/Alignments_post_mapNH/${OG_aln_1}_mapNH/${aln_1})
    Oale_2=$(grep -e '^>Maker' ~/Work/Work1/MapNH/MapNH_${compared_2}/Alignments_post_mapNH/${OG_aln_2}_mapNH/${aln_2})
    Oale_3=$(grep -e '^>Maker' ~/Work/Work1/MapNH/MapNH_${compared_3}/Alignments_post_mapNH/${OG_aln_3}_mapNH/${aln_3})

    # Vérification des noms de genes
    if { [ -z "$Oale_1" ] && [ -z "$Oale_2" ]; } || \
        { [ -z "$Oale_1" ] && [ -z "$Oale_3" ]; } || \
        { [ -z "$Oale_2" ] && [ -z "$Oale_3" ]; } || \
        { [ -z "$Oale_1" ] && [ -z "$Oale_2" ] && [ -z "$Oale_3" ]; }; then
        echo "${OG_aln_1};${OG_aln_2};${OG_aln_3};abs"
    elif { [ -z "$Oale_1" ] && [ "$Oale_2" = "$Oale_3" ]; } || \
        { [ -z "$Oale_2" ] && [ "$Oale_1" = "$Oale_3" ]; } || \
        { [ -z "$Oale_3" ] && [ "$Oale_1" = "$Oale_2" ]; } || \
        { [ "$Oale_1" = "$Oale_2" ] && [ "$Oale_1" = "$Oale_3" ]; }; then
        echo "${OG_aln_1};${OG_aln_2};${OG_aln_3};equ"
    else
        echo "${OG_aln_1};${OG_aln_2};${OG_aln_3};dif"
    fi
  
    # Récupération des noms des genes contenant ">Maker" dans les alignements 
    Pxut_1=$(grep -e '^>NCBI_GCF' ~/Work/Work1/MapNH/MapNH_${compared_1}/Alignments_post_mapNH/${OG_aln_1}_mapNH/${aln_1})
    Pxut_2=$(grep -e '^>NCBI_GCF' ~/Work/Work1/MapNH/MapNH_${compared_2}/Alignments_post_mapNH/${OG_aln_2}_mapNH/${aln_2})
    Pxut_3=$(grep -e '^>NCBI_GCF' ~/Work/Work1/MapNH/MapNH_${compared_3}/Alignments_post_mapNH/${OG_aln_3}_mapNH/${aln_3})
    
    # Vérification des noms de genes
    if { [ -z "$Pxut_1" ] && [ -z "$Pxut_2" ]; } || \
        { [ -z "$Pxut_1" ] && [ -z "$Pxut_3" ]; } || \
        { [ -z "$Pxut_2" ] && [ -z "$Pxut_3" ]; } || \
        { [ -z "$Pxut_1" ] && [ -z "$Pxut_2" ] && [ -z "$Pxut_3" ]; }; then
        echo "${OG_aln_1};${OG_aln_2};${OG_aln_3};abs"
    elif { [ -z "$Pxut_1" ] && [ "$Pxut_2" = "$Pxut_3" ]; } || \
        { [ -z "$Pxut_2" ] && [ "$Pxut_1" = "$Pxut_3" ]; } || \
        { [ -z "$Pxut_3" ] && [ "$Pxut_1" = "$Pxut_2" ]; } || \
        { [ "$Pxut_1" = "$Pxut_2" ] && [ "$Pxut_1" = "$Pxut_3" ]; }; then
        echo "${OG_aln_1};${OG_aln_2};${OG_aln_3};equ"
    else
        echo "${OG_aln_1};${OG_aln_2};${OG_aln_3};dif"
    fi
    
    # Récupération des noms des genes contenant ">Maker" dans les alignements 
    Papo_1=$(grep -e '^>NCBI_GCA' ~/Work/Work1/MapNH/MapNH_${compared_1}/Alignments_post_mapNH/${OG_aln_1}_mapNH/${aln_1})
    Papo_2=$(grep -e '^>NCBI_GCA' ~/Work/Work1/MapNH/MapNH_${compared_2}/Alignments_post_mapNH/${OG_aln_2}_mapNH/${aln_2})
    Papo_3=$(grep -e '^>NCBI_GCA' ~/Work/Work1/MapNH/MapNH_${compared_3}/Alignments_post_mapNH/${OG_aln_3}_mapNH/${aln_3})
    
    # Vérification des noms de genes
    if { [ -z "$Papo_1" ] && [ -z "$Papo_2" ]; } || \
        { [ -z "$Papo_1" ] && [ -z "$Papo_3" ]; } || \
        { [ -z "$Papo_2" ] && [ -z "$Papo_3" ]; } || \
        { [ -z "$Papo_1" ] && [ -z "$Papo_2" ] && [ -z "$Papo_3" ]; }; then
        echo "${OG_aln_1};${OG_aln_2};${OG_aln_3};abs"
    elif { [ -z "$Papo_1" ] && [ "$Papo_2" = "$Papo_3" ]; } || \
        { [ -z "$Papo_2" ] && [ "$Papo_1" = "$Papo_3" ]; } || \
        { [ -z "$Papo_3" ] && [ "$Papo_1" = "$Papo_2" ]; } || \
        { [ "$Papo_1" = "$Papo_2" ] && [ "$Papo_1" = "$Papo_3" ]; }; then
        echo "${OG_aln_1};${OG_aln_2};${OG_aln_3};equ"
    else
        echo "${OG_aln_1};${OG_aln_2};${OG_aln_3};dif"
    fi
    
done < ~/Work/Work1/MapNH/Common_OG_lists/list_aln_${comparison}_new_names.csv



