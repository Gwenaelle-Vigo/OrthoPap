#! /usr/bin/env python3

import sys

def read_fasta(fp):
    name, seq = None, []
    for line in fp:
        line = line.rstrip()
        if line.startswith(">"):
            if name: yield (name, ''.join(seq))
            name, seq = line, []
        else:
            seq.append(line)
    if name: yield (name, ''.join(seq))

f = open(sys.argv[1])
oldname = ""
seqCDS = []
with f as fp:
    for name, seq in read_fasta(fp):
        newName = name.lstrip('>')
        newName = newName.split('_')[0]+"_"+name.split("_")[1]
        #newName = newName+"_"+name.split("_")[1]
        if oldname == "":
            oldname = newName
        if oldname == newName:
            seqCDS.append(seq)
        if oldname != newName:
            print(">"+oldname)
            print("".join(str(e) for e in seqCDS))
            oldname = newName
            seqCDS = []
            seqCDS.append(seq)

print(">"+oldname)
print("".join(str(e) for e in seqCDS))

















