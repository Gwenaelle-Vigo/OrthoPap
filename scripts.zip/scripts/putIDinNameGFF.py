#! /usr/bin/env python3

import sys
import numpy as np
import argparse

# Création du parser d'arguments
parser = argparse.ArgumentParser(description="Traitement d'un fichier GFF.")

# Définition des options (arguments) avec argparse
parser.add_argument('-f', '--gff_file', action="store", dest="namegff", type=str, required=True, 
                    help="Nom du fichier GFF à traiter")

# Parsing des arguments de la ligne de commande
args = parser.parse_args()

# Récupération du nom du fichier GFF
namefile = args.namegff
fp = open(namefile)

# Traitement du fichier ligne par ligne
for line in fp:
    if line.startswith("#"):
        continue
    line = line.rstrip()
    arrl = line.split("\t")
    newname = arrl[8].split(";")[0]
    newname = newname.lstrip("Parent=")
    newname = newname.strip('"')
    strand = arrl[6]
    tab = '\t'
    newline = tab.join(str(e) for e in arrl[0:2]) + tab + newname + "_" + strand + tab + tab.join(str(e) for e in arrl[3:])
    print(newline)

# Fermeture du fichier
fp.close()

