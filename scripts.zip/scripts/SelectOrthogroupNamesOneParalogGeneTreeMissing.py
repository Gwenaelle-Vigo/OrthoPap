#! /usr/bin/env python3

# Ce script utilise le package ETE pour comparer les noms des feuilles dans les arbres de gène des orthogroupes contenant un gène paraloguà partir d'une liste de noms d'orthogroupes. Il identifie les orthogroupes où le nom d'une espèce apparait deux fois dans le même arbre de gène et déterminer si ces deux gènes paralogues appartiennent à des feuilles sœurs (provenant d'un même ancêtre) ou non.

import sys
from ete3 import Tree

# Vérifier si le nombre d'arguments est correct
if len(sys.argv) != 3:
    print("Utilisation : script.py list_Orthogroups_one_paralog.txt pathway_to_directory_OrthoFinder_Results")
    sys.exit(1)

# Récupérer le chemin vers le fichier contenant la liste des orthogroupes possédant un gène paralogue à partir des arguments en ligne de commande
list_Orthogroups_one_paralog = sys.argv[1]

# Récupérer le chemin vers le répertoire contenant les arbres phylogénétiques résolus
pathway_to_directory_OrthoFinder_Results = sys.argv[2]

# Initialiser une liste pour stocker le noms des orthogroupes possédant un gène paralogue pour lesquels le fichier n'a pas été trouvé
missing_files = []

# Parcourir les orthogroupes avec un paralogue
with open(list_Orthogroups_one_paralog, 'r') as og_one_paralog_file:
    for OG in og_one_paralog_file:
        OG = OG.strip()  # Supprimer les espaces ou retours à la ligne
        # Récupérer le chemin vers le fichier contenant l'arbre Newick au format texte
        file_tree = f"{pathway_to_directory_OrthoFinder_Results}/Resolved_Gene_Trees/{OG}_tree.txt"
        file_aln = f"{pathway_to_directory_OrthoFinder_Results}/MultipleSequenceAlignments/{OG}.fa"
        # Lire le contenu du fichier
        try:
            with open(file_tree, 'r') as file_Newick:
                tree_Newick = file_Newick.read()
        except FileNotFoundError:
            print(file_aln)
            missing_files.append(OG)
            continue  # Passer au fichier suivant

# Afficher le nombre de fichiers d'arbres phylogénétiques non trouvés pour les orthogroupes avec un paralogue
if len(sys.argv) != 3:
    print(f"Il y a {len(missing_files)} fichiers OG_tree.txt qui n'ont pas été trouvés pour les orthogroupes possédant un gène paralogue.")

# Afficher les noms des fichiers d'arbres phylogénétiques non trouvés pour les orthogroupes avec un paralogue
if len(sys.argv) != 3 and missing_files:
    print("Voici les orthogroupes possédant un gène paralogue pour lesquels le fichier n'a pas été trouvé :")
    print(", ".join(missing_files))

