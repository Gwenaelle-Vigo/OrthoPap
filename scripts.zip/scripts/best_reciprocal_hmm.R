library(tidyverse)

Threshold=0.9 
scan<-list.files(path="/media/gwen/bigvol/Data_Base_Papilionidae/Analysis_30_species/Profiling/Leptocircini_Profiles_ANNOTATOR/SPECIES_HMM/scan_out/", pattern="_res.txt")
sear<-list.files(path="/media/gwen/bigvol/Data_Base_Papilionidae/Analysis_30_species/Profiling/Leptocircini_Profiles_ANNOTATOR/SPECIES_HMM/search_out/", pattern="_res.txt")

### Best hit scan search
seq<-c()
al<-c()
for(file in scan){
	d<-read.delim(paste("/media/gwen/bigvol/Data_Base_Papilionidae/Analysis_30_species/Profiling/Leptocircini_Profiles_ANNOTATOR/SPECIES_HMM/scan_out/",file, sep=""))
	seq<-c(seq, file)
	if(length(d[,1]) == 0){
		al<-c(al, NA)
	}else if(length(d[,1]) == 1){
		al<-c(al, as.vector(d$target.name[1]))
	}else{
		if(d$score[1]*Threshold> d$score[2]){
			al<-c(al, as.vector(d$target.name[1]))
		}else{
			al<-c(al, "Too_close")
		}
	}
}

Scan<-data.frame(seq, al)

### Best hit search search
seq<-c()
al<-c()
for(file in sear){
	d<-read.delim(paste("/media/gwen/bigvol/Data_Base_Papilionidae/Analysis_30_species/Profiling/Leptocircini_Profiles_ANNOTATOR/SPECIES_HMM/search_out/",file, sep=""))
	al<-c(al, file)
	if(length(d[,1]) == 0){
		seq<-c(seq, NA)
	}else if(length(d[,1]) == 1){
		seq<-c(seq, as.vector(d$target.name[1]))
	}else{
		if(d$score[1]*Threshold> d$score[2]){
			seq<-c(seq, as.vector(d$target.name[1]))
		}else{
			seq<-c(seq, "Too_close")
		}
	}
}

Search<-data.frame(seq, al)

Scan$seq<-sub("_res.txt", "", Scan$seq)
Scan$al<-sub("HMM_", "", Scan$al)
Search$al<-sub("_res.txt", "", Search$al)


Search$name<-paste(Search$seq, Search$al)
Scan$name<-paste(Scan$seq, Scan$al)

a<-Search[Search$name %in% Scan$name,]
b<-Scan[Scan$name %in% Search$name,]

b<-b[b$al != "Too_close",]

Final<-b[,1:2]

#### Add Species to the table
write_csv(Final, "/media/gwen/bigvol/Data_Base_Papilionidae/Analysis_30_species/Profiling/Leptocircini_Profiles_ANNOTATOR/SPECIES_HMM/orthogroups_SPECIES.csv")
