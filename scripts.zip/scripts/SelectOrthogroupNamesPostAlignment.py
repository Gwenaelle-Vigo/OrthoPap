#! /usr/bin/env python3

import os
import sys
import re

if len(sys.argv) != 2:
    print("Utilisation: script.py chemin_du_répertoire_de_dossiers")
    sys.exit(1)

directory_path = sys.argv[1]

#count = 0

for root, dirs, files in os.walk(directory_path):
    nb_files = len(files)
    if root != directory_path:
        if nb_files == 10:
            #OG_name = os.path.basename(root)
            #print(f"{OG_name}")
            OG_match = re.search(r'OG\d+', root) # Recherche du motif OG suivi de chiffres
            OG_code = OG_match.group() # Récupère le code OG correspondant
            print(f"{OG_code}")
            #count += 1

#print(f"\nNombre total de dossiers complets : {count}")

