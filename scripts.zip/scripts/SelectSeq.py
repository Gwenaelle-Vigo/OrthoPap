#! /usr/bin/env python3

import sys
import os
import argparse

def read_fasta(fp):
    name, seq = None, []
    for line in fp:
        line = line.rstrip()
        if line.startswith(">"):
            if name:
                yield (name, ''.join(seq))
            name, seq = line, []
        else:
            seq.append(line)
    if name:
        yield (name, ''.join(seq))

parser = argparse.ArgumentParser()

parser.add_argument('-f', '--fasta_file', action="store", dest="fastaIn", type=str)
parser.add_argument('-l', '--sequence_list', action="store", dest="seqList", type=str)
parser.add_argument('-c', '--complete_name', dest="typeName", default="complete", choices=["complete", "partial"])
parser.add_argument('-o', '--output_file', action="store", dest="outputFile", type=str)

args = parser.parse_args()

with open(args.seqList, 'r') as list_file:
    seq_list = list_file.read().splitlines()

with open(args.fastaIn, 'r') as fp, open(args.outputFile, 'w') as out_f:
    for name, seq in read_fasta(fp):
        #name = name.lstrip(">")
        if args.typeName == "complete":
            if name in seq_list:
                out_f.write(name + "\n" + seq + "\n")
                    
        elif args.typeName == "partial":
            for seq_n in seq_list:
                if seq_n in name:
                    out_f.write(name + "\n" + seq + "\n")
                
#script pour selectionner les sequences d'un fichier FASTA selon une liste de noms de proteines
#L'option "complete" c'est pour que la sequence soit selectionnee si la ligne du fichier FASTA correspond parfaitement avec le nom de la proteine de la liste (excepte le ">")
#L'option "partial" c'est pour que la sequence soit selectionnee si une partie de la ligne du fichier FASTA contient le nom de la proteine de la liste

#Pour l'executer : SelectSeq.py -f 'fasta_file' -l 'sequence_list' -c complete/partial -o 'output_file'
