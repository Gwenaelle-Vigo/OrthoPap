#! /usr/bin/env python3

# Ce script crée un dictionnaire par jeu de données issus d'annotation différente (Busco, Miniprot et Scipio) avec le nom du fichier d'alignement en clé et le nom des gènes des trois espèces de références en values. Puis il compare les noms de gène des trois espèces (values) uniques ou partagés entre les trois dictionnaires afin de récupérer les nom des fichiers d'alignements (clés) spécifiques à chaque annotation.

import sys
import os

if len(sys.argv) != 5:
    sys.exit("4 arguments must be supplied: [1] Busco/Miniprot/Scipio [2] folder_path_Busco [3] folder_path_Miniprot [4] folder_path_Scipio")

### Partie 1
# La partie suivante parcourt tous les dossiers d'alignements du répertoire d'entrée, lit chaque ligne du fichier d'alignement, et ajoute les lignes qui commencent par l'une des chaînes cibles (nom du gène des trois espèces de référence) au dictionnaire avec le nom du fichier comme clé. Ensuite, il affiche le dictionnaire résultant.
    
# Définir les chaînes de caractères à rechercher
target_strings = [
    '>NCBI_GCA907164705.1_Parnassius_apollo',
    '>NCBI_GCF000836235.2_Papilio_xuthus',
    '>Maker_Out_Ornithoptera_alexandrae'
]

# Définir le dossier des alignements et les chemins de dossiers
annotation = sys.argv[1]
busco_folder_path = sys.argv[2]
miniprot_folder_path = sys.argv[3]
scipio_folder_path = sys.argv[4]

# Définition d'une fonction pour la création d'un dictionnaire par dossier
def create_dict_from_folder(folder_path, target_strings):
    # Initialiser le dictionnaire
    result_dict = {}
    
    # Parcourir tous les fichiers dans le dossier
    for directory in os.listdir(folder_path):
        filename = directory.replace("mapNH", "macse_final_mask_align_NT_pruned_complet.aln")
        file_path = os.path.join(folder_path, directory, filename)
        
        # Vérifier si le chemin correspond à un fichier
        if os.path.isfile(file_path):
            # Ouvrir le fichier en mode lecture
            with open(file_path, 'r') as file:
                # Lire chaque ligne du fichier
                for line in file:
                    # Vérifier si la ligne commence par l'une des chaînes cibles
                    for target_string in target_strings:
                        if line.startswith(target_string):
                            # Ajouter le fichier au dictionnaire s'il n'est pas déjà présent
                            if filename not in result_dict:
                                result_dict[filename] = []
                            # Ajouter la ligne au contenu associé à la clé
                            result_dict[filename].append(line.strip())
        else :
            print(f"Le chemin {file_path} ne correspond à aucun fichier")
    return result_dict

# Création du dictionnaire Busco
busco_dict = create_dict_from_folder(busco_folder_path, target_strings)

# Création du dictionnaire Miniprot
miniprot_dict = create_dict_from_folder(miniprot_folder_path, target_strings)

# Création du dictionnaire Scipio
scipio_dict = create_dict_from_folder(scipio_folder_path, target_strings)


### Partie 2
# La partie suivante compare les noms de gène des trois espèces (values) partagés entre deux dictionnaires afin de récupérer les nom des fichiers d'alignements (clés) spécifiques à chaque annotation.

# Fonction pour compter le nombre de clés avec au moins une ligne associée identique entre deux dictionnaires
def common_keys(dict1, dict2):
    list_dict1_keys = []
    list_dict2_keys = []
    list_dict1_keys_to_remove = []
    list_dict2_keys_to_remove = []
    
    for key1, value1 in dict1.items():
        for key2, value2 in dict2.items():
            if any(line1 in value2 for line1 in value1):
                
                if key1 not in list_dict1_keys and key2 not in list_dict2_keys:
                    list_dict1_keys.append(key1)
                    list_dict2_keys.append(key2)
                
                else:
                    list_dict1_keys_to_remove.append(key1)
                    list_dict2_keys_to_remove.append(key2)
                       
    dict_keys = {
        'keys_dict1': list_dict1_keys,
        'keys_dict2': list_dict2_keys,
        'keys_dict1_to_remove': list_dict1_keys_to_remove,
        'keys_dict2_to_remove': list_dict2_keys_to_remove
    }                    
    
    return dict_keys

# Récupération des noms de fichier à supprimer sous forme de liste selon l'annotateur déterminé en argument
if annotation == "Busco":
    # Retrait des genes séparés pour le 1er autre dictionnaire
    # Création du dictionnaire
    dict_keys_busco_miniprot = common_keys(busco_dict, miniprot_dict)
    # Récupérer la liste des genes à supprimer
    list_keys_busco_to_remove_BM = dict_keys_busco_miniprot.get('keys_dict1_to_remove', [])
    # Récupérer la liste des genes à supprimer en unique exemplaire
    list_keys_busco_unique_to_remove_BM = set(list_keys_busco_to_remove_BM)
    # Retrait des genes séparés pour le 2er autre dictionnaire
    # Création du dictionnaire
    dict_keys_busco_scipio = common_keys(busco_dict, scipio_dict)
    # Récupérer la liste des genes à supprimer
    list_keys_busco_to_remove_BS = dict_keys_busco_scipio.get('keys_dict1_to_remove', [])
    # Récupérer la liste des genes à supprimer en unique exemplaire
    list_keys_busco_unique_to_remove_BS = set(list_keys_busco_to_remove_BS)
    # Union des deux listes de genes à supprimer
    list_keys_busco_to_remove = list(list_keys_busco_unique_to_remove_BM) + list(list_keys_busco_unique_to_remove_BS)
    # Union des deux listes de genes uniques à supprimer 
    list_keys_busco_unique_to_remove = set(list_keys_busco_to_remove)
    # Afficher la liste dans le terminal pour l'enregister sous un fichier texte
    for file_name in list_keys_busco_unique_to_remove:
        print(file_name)
elif annotation == "Miniprot":
    # Retrait des genes séparés pour le 1er autre dictionnaire
    # Création du dictionnaire
    dict_keys_busco_miniprot = common_keys(busco_dict, miniprot_dict)
    # Récupérer la liste des genes à supprimer
    list_keys_miniprot_to_remove_BM = dict_keys_busco_miniprot.get('keys_dict2_to_remove', [])
    # Récupérer la liste des genes à supprimer en unique exemplaire
    list_keys_miniprot_unique_to_remove_BM = set(list_keys_miniprot_to_remove_BM)
    # Retrait des genes séparés pour le 2er autre dictionnaire
    # Création du dictionnaire
    dict_keys_miniprot_scipio = common_keys(miniprot_dict, scipio_dict)
    # Récupérer la liste des genes à supprimer
    list_keys_miniprot_to_remove_MS = dict_keys_miniprot_scipio.get('keys_dict1_to_remove', [])
    # Récupérer la liste des genes à supprimer en unique exemplaire
    list_keys_miniprot_unique_to_remove_MS = set(list_keys_miniprot_to_remove_MS)
    # Union des deux listes de genes à supprimer
    list_keys_miniprot_to_remove = list(list_keys_miniprot_unique_to_remove_BM) + list(list_keys_miniprot_unique_to_remove_MS)
    # Union des deux listes de genes uniques à supprimer 
    list_keys_miniprot_unique_to_remove = set(list_keys_miniprot_to_remove)
    # Afficher la liste dans le terminal pour l'enregister sous un fichier texte
    for file_name in list_keys_miniprot_unique_to_remove:
        print(file_name)
elif annotation == "Scipio":
# Retrait des genes séparés pour le 1er autre dictionnaire
    # Création du dictionnaire
    dict_keys_busco_scipio = common_keys(busco_dict, scipio_dict)
    # Récupérer la liste des genes à supprimer
    list_keys_scipio_to_remove_BS = dict_keys_busco_scipio.get('keys_dict2_to_remove', [])
    # Récupérer la liste des genes à supprimer en unique exemplaire
    list_keys_scipio_unique_to_remove_BS = set(list_keys_scipio_to_remove_BS)
    # Retrait des genes séparés pour le 2er autre dictionnaire
    # Création du dictionnaire
    dict_keys_miniprot_scipio = common_keys(miniprot_dict, scipio_dict)
    # Récupérer la liste des genes à supprimer
    list_keys_scipio_to_remove_MS = dict_keys_miniprot_scipio.get('keys_dict2_to_remove', [])
    # Récupérer la liste des genes à supprimer en unique exemplaire
    list_keys_scipio_unique_to_remove_MS = set(list_keys_scipio_to_remove_MS)
    # Union des deux listes de genes à supprimer
    list_keys_scipio_to_remove = list(list_keys_scipio_unique_to_remove_BS) + list(list_keys_scipio_unique_to_remove_MS)
    # Union des deux listes de genes uniques à supprimer 
    list_keys_scipio_unique_to_remove = set(list_keys_scipio_to_remove)
    # Afficher la liste dans le terminal pour l'enregister sous un fichier texte
    for file_name in list_keys_scipio_unique_to_remove:
        print(file_name)
else:
    print("ERREUR :")
    print("1er argument indique l'annotation pour la liste des fichiers alignments à supprimer (Busco/Miniprot/Scipio")




