# Script pour la création d'un fichier csv contenant tous les gènes associés aux OG pour toutes les espèces

sp_HMM <- list.files(path="/media/gwen/bigvol/Data_Base_Papilionidae/Analysis_30_species/Profiling/Leptocircini_Profiles_Busco/")

tab <- data.frame(al = character(), stringsAsFactors = FALSE)

for(dir in sp_HMM){
  sp<-sub("_HMM", "", dir)
  csv<-read.csv(paste("/media/gwen/bigvol/Data_Base_Papilionidae/Analysis_30_species/Profiling/Leptocircini_Profiles_Busco/",dir,"/orthogroups_",sp,".csv", sep=""))
  # Renommer la colonne seq selon le nom de l'espèce
  names(csv)[names(csv) == "seq"] <- paste("seq_",sp, sep="")
  # Fusionner les dataframes
  tab<-merge(tab, csv, by="al", all=TRUE)
}

write_csv(tab, "/media/gwen/bigvol/Data_Base_Papilionidae/Analysis_30_species/Profiling/orthogroups_busco_reunified.csv")
