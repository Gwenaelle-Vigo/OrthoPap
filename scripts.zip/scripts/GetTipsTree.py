#! /usr/bin/env python3

import sys

if len(sys.argv) != 2:
    print("Usage: GetTipsTree.py <tree_file.tree>")

    
tree_file = sys.argv[1]

from ete3 import Tree

def get_leaf_names(tree_file):
    # Charger l'arbre à partir du fichier .tree
    tree = Tree(tree_file)

    # Obtenir les noms des feuilles (espèces)
    leaf_names = [leaf.name for leaf in tree.iter_leaves()]

    return leaf_names

try:
    leaf_names = get_leaf_names(tree_file)
    for name in leaf_names:
        print(name)
except FileNotFoundError:
    print(f"Error: File '{tree_file}' not found.")

