#! /usr/bin/env python3

# Module
import sys

gff = open(sys.argv[1])

# create empty dictionary
GeneName = []
gene2exclude = []
KeptGenes = []

# loop over the GFF
previous_start = 0
previous_end = 0

for li in gff:

	if li[0] == "#":
		continue

	li = li.rstrip()

	# split the line according to the "tab"
	arrli = li.split()

	# store gene name
	gene = arrli[2][:-2]

	if gene not in GeneName:
		GeneName.append(gene)

	# store chromosome and start info and end info
	start = float(arrli[3])
	end = float(arrli[4])

	if previous_start <= start <= previous_end:
		gene2exclude.append(gene)
	else:
		previous_start = float(arrli[3])
		previous_end = float(arrli[4])

#print(gene2exclude)

for gene in GeneName:
	if gene not in gene2exclude:
		KeptGenes.append(gene)
		print(gene)

#print(len(KeptGenes))
#print(KeptGenes)
#print(GeneName)
