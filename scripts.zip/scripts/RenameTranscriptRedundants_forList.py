#! /usr/bin/env python3

# Script pour renommer les noms redondants (pattern : 'MP000000_Esp_1') en modifiant le '_1' a la fin du nom par '_2' pour la deuxieme occurrence, '_3' pour la troisieme occurrence, etc.
# Ce script ouvre le fichier en premier argument "inputfile", parcourt les lignes, et pour chaque nom, il tient compte du nombre d'occurrences dans le dictionnaire name_counts. Si le nom est deja present, il modifie le nom en ajoutant un suffixe numerique. Ensuite, il ecrit les lignes renommees dans le fichier en deuxieme argument de ligne de commande "output_file".

import sys
import re

if len(sys.argv) != 3:
    print("Utilisation: python script.py fichier_entree > fichier_sortie")
    sys.exit(1)

input_file = sys.argv[1]
output_file = sys.argv[2]

# Ouvrir le fichier d'entrée en lecture
with open(input_file, 'r') as file:
    lines = file.readlines()

# Créer un dictionnaire pour compter les occurrences des noms
name_counts = {}
output_lines = []

# Fonction pour obtenir la partie avant le dernier "_"
def get_base_name(name):
    parts = name.rsplit('_', 1)
    return parts[0]

# Parcourir les lignes du fichier
for line in lines:
    name = line.strip()
    base_name = get_base_name(name)
    if base_name in name_counts:
        name_counts[base_name] += 1
        new_name = f'{base_name}_{name_counts[base_name]}'
        output_lines.append(new_name)
    else:
        name_counts[base_name] = 1
        output_lines.append(name)

# Écrire les lignes renommées dans le fichier de sortie
with open(output_file, 'a') as output_file:
    output_file.write('\n'.join(output_lines))

print(f"Fichier renommé avec succès. Résultat enregistré dans {output_file.name}.")

#To execute : ./RenameTranscriptRedondants.py input_file.txt output_file.txt
