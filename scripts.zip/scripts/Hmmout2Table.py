#! /usr/bin/env python3
# convert the output of hmmsearch and hmmscan into table 
import sys

f = open(sys.argv[1])

print("target name\tquery name\tE-value\tscore\tbias")

for line in f:
	if line[0] == "#":
		continue
	arline = line.split()
	print(arline[0]+"\t"+arline[2]+"\t"+arline[4]+"\t"+arline[5]+"\t"+arline[6])


