#!/bin/bash

comparison=$1
compared_1=$2
compared_2=$3

# Lecture du fichier ligne par ligne
while IFS=';' read -r _ aln_1 aln_2; do     
    # Extraction des noms d'OG depuis les noms d'alignement
    OG_aln_1=$(sed 's/_macse_.*//' <<< "$aln_1")
    OG_aln_2=$(sed 's/_macse_.*//' <<< "$aln_2")

    # Récupération des noms des genes contenant ">Maker" dans les alignements 
    Oale_1=$(grep -e '^>Maker' ~/Work/Work1/MapNH/MapNH_${compared_1}/Alignments_post_mapNH/${OG_aln_1}_mapNH/${aln_1})
    Oale_2=$(grep -e '^>Maker' ~/Work/Work1/MapNH/MapNH_${compared_2}/Alignments_post_mapNH/${OG_aln_2}_mapNH/${aln_2})

    # Vérification des noms de genes
    if [ -z "$Oale_1" ] || [ -z "$Oale_2" ]; then
        echo "${OG_aln_1};${OG_aln_2};abs"
    elif [ "$Oale_1" = "$Oale_2" ]; then
        echo "${OG_aln_1};${OG_aln_2};equ"
    else
        echo "${OG_aln_1};${OG_aln_2};dif"
    fi
    
    # Récupération des noms des genes contenant ">Maker" dans les alignements 
    Pxut_1=$(grep -e '^>NCBI_GCF' ~/Work/Work1/MapNH/MapNH_${compared_1}/Alignments_post_mapNH/${OG_aln_1}_mapNH/${aln_1})
    Pxut_2=$(grep -e '^>NCBI_GCF' ~/Work/Work1/MapNH/MapNH_${compared_2}/Alignments_post_mapNH/${OG_aln_2}_mapNH/${aln_2})

    # Vérification des noms de genes
    if [ -z "$Pxut_1" ] || [ -z "$Pxut_2" ]; then
        echo "${OG_aln_1};${OG_aln_2};abs"
    elif [ "$Pxut_1" = "$Pxut_2" ]; then
        echo "${OG_aln_1};${OG_aln_2};equ"
    else
        echo "${OG_aln_1};${OG_aln_2};dif"
    fi
    
    # Récupération des noms des genes contenant ">Maker" dans les alignements 
    Papo_1=$(grep -e '^>NCBI_GCA' ~/Work/Work1/MapNH/MapNH_${compared_1}/Alignments_post_mapNH/${OG_aln_1}_mapNH/${aln_1})
    Papo_2=$(grep -e '^>NCBI_GCA' ~/Work/Work1/MapNH/MapNH_${compared_2}/Alignments_post_mapNH/${OG_aln_2}_mapNH/${aln_2})

    # Vérification des noms de genes
    if [ -z "$Papo_1" ] || [ -z "$Papo_2" ]; then
        echo "${OG_aln_1};${OG_aln_2};abs"
    elif [ "$Papo_1" = "$Papo_2" ]; then
        echo "${OG_aln_1};${OG_aln_2};equ"
    else
        echo "${OG_aln_1};${OG_aln_2};dif"
    fi
    
done < ~/Work/Work1/MapNH/Common_OG_lists/list_aln_${comparison}_CommonToTwo_new_names.csv


















