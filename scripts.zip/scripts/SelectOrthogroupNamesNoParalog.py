#! /usr/bin/env python3

import sys

tsv = open(sys.argv[1])

for line in tsv:
    if line.startswith("Ortho"):
        continue
    
    line = line.rstrip()
    segment = line.split("\t")
    
    #print(segments)
    
    if all(seg in ('0', '1') for seg in segment[1:31]) and segment[31] not in ['0', '1', '2', '3', '4']:
    
    	print(segment[0])

#Script pour obtenir une liste des orthogroups contenant exclusievement des sequences de genes orthologues 1:1

#To execute : ~/Work/Work1/Alignment/SelectOrthogroupNamesNoParalog.py Orthogroups/Orthogroups.GeneCount.tsv > output_file.txt
