#! /usr/bin/env python3

# Script pour renommer les noms des sequences (pattern : 'MP000000_Esp_1') dans un fichier FASTA (ou les noms sont sur des lignes commençant par '>') et conserver les lignes des sequences inchangees
# Ce script renommera les noms des sequences (lignes commençant par '>') en testant l'occurrence sur la partie avant le dernier "_". Les lignes de sequence seront conservees inchangees. Le resultat sera enregistre dans le fichier de sortie specifie en deuxieme argument de ligne de commande.

import sys
import re

if len(sys.argv) != 3:
    print("Utilisation: python script.py fichier_entree.fasta > fichier_sortie.fasta")
    sys.exit(1)

input_file = sys.argv[1]
output_file = sys.argv[2]

# Ouvrir le fichier d'entrée en lecture
with open(input_file, 'r') as file:
    lines = file.readlines()

# Créer un dictionnaire pour compter les occurrences des noms
name_counts = {}
output_lines = []

# Fonction pour obtenir la partie avant le dernier "_"
def get_base_name(name):
    parts = name.rsplit('_', 1)
    return parts[0]

# Variables pour garder la trace du nom de séquence en cours
current_seq_name = None

# Parcourir les lignes du fichier
for line in lines:
    line = line.strip()
    if line.startswith('>'):
        # Ligne de nom de séquence
        current_seq_name = line[1:]  # Retirer le ">"
        base_name = get_base_name(current_seq_name)
        if base_name in name_counts:
            name_counts[base_name] += 1
            new_name = f'{base_name}_{name_counts[base_name]}'
            output_lines.append(f'>{new_name}')
        else:
            name_counts[base_name] = 1
            output_lines.append(line)  # Conserver le nom de séquence inchangé
    else:
        # Ligne de séquence, la conserver telle quelle
        output_lines.append(line)

# Écrire les lignes renommées dans le fichier de sortie
with open(output_file, 'a') as output_file:
    output_file.write('\n'.join(output_lines))

print(f"Fichier renommé avec succès. Résultat enregistré dans {output_file.name}.")


#To execute : ./RenameTranscriptRedondants.py input_file.txt > output_file.txt
