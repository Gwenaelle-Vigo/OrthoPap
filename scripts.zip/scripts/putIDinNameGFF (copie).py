#! /usr/bin/env python3

import sys
import numpy as np
import optparse


parser = optparse.OptionParser()

parser.add_option('-f', '--gff_file',action="store", dest="namegff", type="string")
(options, args) = parser.parse_args()

namefile = str(options.namegff)
fp = open(namefile)

for line in fp:
	if line[0] == "#":
		continue
	line = line.rstrip()
	arrl = line.split("\t")
	newname = arrl[8].split(";")[0]
	newname = newname.lstrip("Parent=")
	newname = newname.strip('"')
	strand = arrl[6]
	tab = '\t'
	newline = tab.join(str(e) for e in arrl[0:2])+tab+newname+"_"+strand+tab+tab.join(str(e) for e in arrl[3:])
	#newline = tab.join(str(e) for e in arrl[0:2])+tab+newname+tab+tab.join(str(e) for e in arrl[3:])
	print(newline)
	

