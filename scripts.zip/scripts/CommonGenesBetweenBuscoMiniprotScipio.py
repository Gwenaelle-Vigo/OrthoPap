#! /usr/bin/env python3

# Ce script crée un dictionnaire par jeu de données issus d'annotation différente (Busco, Miniprot et Scipio) avec le nom du fichier d'alignement en clé et le nom des gènes des trois espèces de références en values. Puis il compare les noms de gène des trois espèces (values) uniques ou partagés entre les trois dictionnaires afin de récupérer les nom des fichiers d'alignements (clés) spécifiques à chaque annotation.

import sys
import os

if len(sys.argv) < 4:
    sys.exit("3 arguments must be supplied: [1] folder_path_Busco [2] folder_path_Miniprot [3] folder_path_Scipio")

### Partie 1
# La partie suivante parcourt tous les dossiers d'alignements du répertoire d'entrée, lit chaque ligne du fichier d'alignement, et ajoute les lignes qui commencent par l'une des chaînes cibles (nom du gène des trois espèces de référence) au dictionnaire avec le nom du fichier comme clé. Ensuite, il affiche le dictionnaire résultant.
    
# Définir les chaînes de caractères à rechercher
target_strings = [
    '>NCBI_GCA907164705.1_Parnassius_apollo',
    '>NCBI_GCF000836235.2_Papilio_xuthus',
    '>Maker_Out_Ornithoptera_alexandrae'
]

# Définir le chemin du dossier Busco
busco_folder_path = sys.argv[1]
miniprot_folder_path = sys.argv[2]
scipio_folder_path = sys.argv[3]

# Définition d'une fonction pour la création d'un dictionnaire par dossier
def create_dict_from_folder(folder_path, target_strings):
    # Initialiser le dictionnaire
    result_dict = {}
    
    # Parcourir tous les fichiers dans le dossier
    for directory in os.listdir(folder_path):
        filename = directory.replace("mapNH", "macse_final_mask_align_NT.aln")
        file_path = os.path.join(folder_path, directory, filename)
        
        # Vérifier si le chemin correspond à un fichier
        if os.path.isfile(file_path):
            # Ouvrir le fichier en mode lecture
            with open(file_path, 'r') as file:
                # Lire chaque ligne du fichier
                for line in file:
                    # Vérifier si la ligne commence par l'une des chaînes cibles
                    for target_string in target_strings:
                        if line.startswith(target_string):
                            # Ajouter le fichier au dictionnaire s'il n'est pas déjà présent
                            if filename not in result_dict:
                                result_dict[filename] = []
                            # Ajouter la ligne au contenu associé à la clé
                            result_dict[filename].append(line.strip())
        else :
            print(f"Le chemin {file_path} ne correspond à aucun fichier")
    return result_dict

# Création du dictionnaire Busco
busco_dict = create_dict_from_folder(busco_folder_path, target_strings)

# Afficher le dictionnaire résultant
#for key, value in busco_dict.items():
    #print(f"{key}: {value}")
    
# Afficher la liste des key du dictionnaire
for key, value in busco_dict.items():
    print(key)

# Création du dictionnaire Miniprot
miniprot_dict = create_dict_from_folder(miniprot_folder_path, target_strings)

# Création du dictionnaire Scipio
scipio_dict = create_dict_from_folder(scipio_folder_path, target_strings)

# Nombre de clés (noms de fichiers) pour chaque dictionnaire
num_keys_busco = len(busco_dict)
num_keys_miniprot = len(miniprot_dict)
num_keys_scipio = len(scipio_dict)

#print(f"Nombre de clés pour Busco: {num_keys_busco}")
#print(f"Nombre de clés pour Miniprot: {num_keys_miniprot}")
#print(f"Nombre de clés pour Scipio: {num_keys_scipio}")

### Partie 2
# La partie suivante compare les noms de gène des trois espèces (values) uniques ou partagés entre les trois dictionnaires afin de récupérer les nom des fichiers d'alignements (clés) spécifiques à chaque annotation.

# Fonction pour compter le nombre de clés avec aucune ligne associée identique entre les trois dictionnaires
def uncommon_keys(dict1, dict2, dict3):
    dict1_uncommon_keys = []
    
    for key1, value1 in dict1.items():
        found_in_other_dicts = False
        
        for key2, value2 in dict2.items():
            if any(line1 in value2 for line1 in value1):
                found_in_other_dicts = True
                break  # Si une correspondance est trouvée, pas besoin de continuer

        for key3, value3 in dict3.items():
            if any(line1 in value3 for line1 in value1):
                found_in_other_dicts = True
                break  # Si une correspondance est trouvée, pas besoin de continuer

        if not found_in_other_dicts:
            dict1_uncommon_keys.append(key1)
                        
    return dict1_uncommon_keys
    
# Nombre de values uniques 
#uncommon_keys_busco = uncommon_keys(busco_dict, miniprot_dict, scipio_dict)
#uncommon_keys_miniprot = uncommon_keys(miniprot_dict, busco_dict, scipio_dict)
#uncommon_keys_scipio = uncommon_keys(scipio_dict, busco_dict, miniprot_dict)

#print(f"Nombre de clés uniques pour Busco: {len(uncommon_keys_busco)}")
#print(f"Nombre de clés uniques pour Miniprot: {len(uncommon_keys_miniprot)}")
#print(f"Nombre de clés uniques pour Scipio: {len(uncommon_keys_scipio)}")


# Fonction pour compter le nombre de clés avec au moins une ligne associée identique entre deux dictionnaires
def common_keys(dict1, dict2):
    list_dict1_keys = []
    list_dict2_keys = []
    list_dict1_keys_to_remove = []
    list_dict2_keys_to_remove = []
    
    for key1, value1 in dict1.items():
        for key2, value2 in dict2.items():
            if any(line1 in value2 for line1 in value1):
                
                if key1 not in list_dict1_keys and key2 not in list_dict2_keys:
                    list_dict1_keys.append(key1)
                    list_dict2_keys.append(key2)
                
                else:
                    list_dict1_keys_to_remove.append(key1)
                    list_dict2_keys_to_remove.append(key2)
                       
    dict_keys = {
        'keys_dict1': list_dict1_keys,
        'keys_dict2': list_dict2_keys,
        'keys_dict1_to_remove': list_dict1_keys_to_remove,
        'keys_dict2_to_remove': list_dict2_keys_to_remove
    }                    
    
    return dict_keys
    
# Comparaisons entre Busco et Miniprot

#dict_keys_busco_miniprot = common_keys(busco_dict, miniprot_dict)
#print(dict_keys_busco_miniprot)

# Busco
# Récupérer la liste des genes Busco communs avec Miniprot
#list_keys_busco_BM = dict_keys_busco_miniprot.get('keys_dict1', [])
#print(keys_busco_BM)

# Obtenir le nombre de genes Busco communs avec Miniprot
#num_keys_busco_BM = len(list_keys_busco_BM)
#print(f"Nombre de clés Busco commune avec Miniprot : {num_keys_busco_BM}")

# Récupérer la liste des genes Busco à spprimer
#list_keys_busco_to_remove_BM = dict_keys_busco_miniprot.get('keys_dict1_to_remove', [])
# Obtenir le nombre de genes Busco communs avec Miniprot
#list_keys_busco_unique_to_remove_BM = set(list_keys_busco_to_remove_BM)
#num_keys_busco_unique_to_remove_BM = len(list_keys_busco_unique_to_remove_BM)
#print(f"Nombre de fichiers Busco à supprimer : {num_keys_busco_unique_to_remove_BM}")

# Récupérer la liste des genes Busco communs avec Miniprot sans ceux à supprimer
#list_keys_busco_filtered_BM = [key for key in list_keys_busco_BM if key not in list_keys_busco_unique_to_remove_BM]
#num_keys_busco_filtered_BM = len(list_keys_busco_filtered_BM)
#print(f"Nombre de fichiers Busco communs avec Miniprot sans les fichiers à gènes séparés : {num_keys_busco_filtered_BM}")

# Récupérer la liste des genes Busco à supprimer qui ne sont pas dans la liste des genes commmuns
#list_keys_busco_unique_to_remove_BM_not_find = [nom for nom in list_keys_busco_unique_to_remove_BM if nom not in list_keys_busco_BM]
#print("Fichiers à supprimer non trouvés dans liste des fichiers communs :", list_keys_busco_unique_to_remove_BM_not_find)

# Afficher la liste dans le terminal pour l'enregister sous un fichier texte
#for file_name in list_keys_busco_unique_to_remove_BM:
    #print(file_name)

# Miniprot
# Récupérer la liste des genes Miniprot communs avec Busco
#list_keys_miniprot_BM = dict_keys_busco_miniprot.get('keys_dict2', [])
#print(keys_miniprot_BM)

# Obtenir le nombre de genes Miniprot communs avec Busco
#num_keys_miniprot_BM = len(list_keys_miniprot_BM)
#print(f"Nombre de clés Miniprot commune avec Busco : {num_keys_miniprot_BM}")

# Récupérer la liste des genes Miniprot à spprimer
#list_keys_miniprot_to_remove_BM = dict_keys_busco_miniprot.get('keys_dict2_to_remove', [])
# Obtenir le nombre de genes Miniprot communs avec Busco
#list_keys_miniprot_unique_to_remove_BM = set(list_keys_miniprot_to_remove_BM)
#num_keys_miniprot_unique_to_remove_BM = len(list_keys_miniprot_unique_to_remove_BM)
#print(f"Nombre de fichiers Miniprot à supprimer : {num_keys_miniprot_unique_to_remove_BM}")

# Récupérer la liste des genes Miniprot communs avec Busco sans ceux à supprimer
#list_keys_miniprot_filtered_BM = [key for key in list_keys_miniprot_BM if key not in list_keys_miniprot_unique_to_remove_BM]
#num_keys_miniprot_filtered_BM = len(list_keys_miniprot_filtered_BM)
#print(f"Nombre de fichiers Miniprot communs avec Busco sans les fichiers à gènes séparés : {num_keys_miniprot_filtered_BM}")

# Afficher la liste dans le terminal pour l'enregister sous un fichier texte
#for file_name in list_keys_miniprot_unique_to_remove_BM:
    #print(file_name)

# Comparaisons entre Busco et Scipio

#dict_keys_busco_scipio = common_keys(busco_dict, scipio_dict)

# Busco
# Récupérer la liste des genes Busco communs avec Scipio
#list_keys_busco_BS = dict_keys_busco_scipio.get('keys_dict1', [])
#print(keys_busco_BS)

# Obtenir le nombre de genes Busco communs avec Scipio
#num_keys_busco_BS = len(list_keys_busco_BS)
#print(f"Nombre de clés Busco commune avec Scipio : {num_keys_busco_BS}")

# Récupérer la liste des genes Busco à spprimer
#list_keys_busco_to_remove_BS = dict_keys_busco_scipio.get('keys_dict1_to_remove', [])
# Obtenir le nombre de genes Busco communs avec Scipio
#list_keys_busco_unique_to_remove_BS = set(list_keys_busco_to_remove_BS)
#num_keys_busco_unique_to_remove_BS = len(list_keys_busco_unique_to_remove_BS)
#print(f"Nombre de fichiers Busco à supprimer : {num_keys_busco_unique_to_remove_BS}")

# Récupérer la liste des genes Busco communs avec Scipio sans ceux à supprimer
#list_keys_busco_filtered_BS = [key for key in list_keys_busco_BS if key not in list_keys_busco_unique_to_remove_BS]
#num_keys_busco_filtered_BS = len(list_keys_busco_filtered_BS)
#print(f"Nombre de fichiers Busco communs avec Scipio sans les fichiers à gènes séparés : {num_keys_busco_filtered_BS}")

# Afficher la liste dans le terminal pour l'enregister sous un fichier texte
#for file_name in list_keys_busco_unique_to_remove_BS:
    #print(file_name)

# Scipio
# Récupérer la liste des genes Scipio communs avec Busco
#list_keys_scipio_BS = dict_keys_busco_scipio.get('keys_dict2', [])
#print(keys_scipio_BS)

# Obtenir le nombre de genes Scipio communs avec Busco
#num_keys_scipio_BS = len(list_keys_scipio_BS)
#print(f"Nombre de clés Scipio commune avec Busco : {num_keys_scipio_BS}")

# Récupérer la liste des genes Scipio à spprimer
#list_keys_scipio_to_remove_BS = dict_keys_busco_scipio.get('keys_dict2_to_remove', [])
# Obtenir le nombre de genes Scipio communs avec Busco
#list_keys_scipio_unique_to_remove_BS = set(list_keys_scipio_to_remove_BS)
#num_keys_scipio_unique_to_remove_BS = len(list_keys_scipio_unique_to_remove_BS)
#print(f"Nombre de fichiers Scipio à supprimer : {num_keys_scipio_unique_to_remove_BS}")

# Récupérer la liste des genes Scipio communs avec Busco sans ceux à supprimer
#list_keys_scipio_filtered_BS = [key for key in list_keys_scipio_BS if key not in list_keys_scipio_unique_to_remove_BS]
#num_keys_scipio_filtered_BS = len(list_keys_scipio_filtered_BS)
#print(f"Nombre de fichiers Scipio communs avec Busco sans les fichiers à gènes séparés : {num_keys_scipio_filtered_BS}")

# Afficher la liste dans le terminal pour l'enregister sous un fichier texte
#for file_name in list_keys_scipio_unique_to_remove_BS:
    #print(file_name)

# Comparaisons entre Miniprot et Scipio

#dict_keys_miniprot_scipio = common_keys(miniprot_dict, scipio_dict)

# Miniprot
# Récupérer la liste des genes Miniprot communs avec Scipio
#list_keys_miniprot_MS = dict_keys_miniprot_scipio.get('keys_dict1', [])
#print(keys_miniprot_MS)

# Obtenir le nombre de genes Miniprot communs avec Scipio
#num_keys_miniprot_MS = len(list_keys_miniprot_MS)
#print(f"Nombre de clés Miniprot commune avec Scipio : {num_keys_miniprot_MS}")

# Récupérer la liste des genes Miniprot à spprimer
#list_keys_miniprot_to_remove_MS = dict_keys_miniprot_scipio.get('keys_dict1_to_remove', [])
# Obtenir le nombre de genes Miniprot communs avec Scipio
#list_keys_miniprot_unique_to_remove_MS = set(list_keys_miniprot_to_remove_MS)
#num_keys_miniprot_unique_to_remove_MS = len(list_keys_miniprot_unique_to_remove_MS)
#print(f"Nombre de fichiers Miniprot à supprimer : {num_keys_miniprot_unique_to_remove_MS}")

# Récupérer la liste des genes Miniprot communs avec Scipio sans ceux à supprimer
#list_keys_miniprot_filtered_MS = [key for key in list_keys_miniprot_MS if key not in list_keys_miniprot_unique_to_remove_MS]
#num_keys_miniprot_filtered_MS = len(list_keys_miniprot_filtered_MS)
#print(f"Nombre de fichiers Miniprot communs avec Scipio sans les fichiers à gènes séparés : {num_keys_miniprot_filtered_MS}")

# Afficher la liste dans le terminal pour l'enregister sous un fichier texte
#for file_name in list_keys_miniprot_unique_to_remove_MS:
    #print(file_name)
    
# Scipio
# Récupérer la liste des genes Scipio communs avec Miniprot
#list_keys_scipio_MS = dict_keys_miniprot_scipio.get('keys_dict2', [])
#print(keys_scipio_MS)

# Obtenir le nombre de genes Scipio communs avec Miniprot
#num_keys_scipio_MS = len(list_keys_scipio_MS)
#print(f"Nombre de clés Scipio commune avec Miniprot : {num_keys_scipio_MS}")

# Récupérer la liste des genes Scipio à spprimer
#list_keys_scipio_to_remove_MS = dict_keys_miniprot_scipio.get('keys_dict2_to_remove', [])
# Obtenir le nombre de genes Scipio communs avec Miniprot
#list_keys_scipio_unique_to_remove_MS = set(list_keys_scipio_to_remove_MS)
#num_keys_scipio_unique_to_remove_MS = len(list_keys_scipio_unique_to_remove_MS)
#print(f"Nombre de fichiers Scipio à supprimer : {num_keys_scipio_unique_to_remove_MS}")

# Récupérer la liste des genes Scipio communs avec Miniprot sans ceux à supprimer
#list_keys_scipio_filtered_MS = [key for key in list_keys_scipio_MS if key not in list_keys_scipio_unique_to_remove_MS]
#num_keys_scipio_filtered_MS = len(list_keys_scipio_filtered_MS)
#print(f"Nombre de fichiers Scipio communs avec Miniprot sans les fichiers à gènes séparés : {num_keys_scipio_filtered_MS}")

# Afficher la liste dans le terminal pour l'enregister sous un fichier texte
#for file_name in list_keys_scipio_unique_to_remove_MS:
    #print(file_name)


# Fonction pour trouver les clés communes avec au moins une ligne identique entre les trois dictionnaires
def common_keys_for_all(dict1, dict2, dict3):
    list_dict1_keys = []
    list_dict2_keys = []
    list_dict3_keys = []
    list_dict1_keys_to_remove = []
    list_dict2_keys_to_remove = []
    list_dict3_keys_to_remove = []

    for key1, value1 in dict1.items():
        for key2, value2 in dict2.items():
            for key3, value3 in dict3.items():
                if any(line1 in value2 for line1 in value1) and any(line1 in value3 for line1 in value1):

                    if key1 not in list_dict1_keys and key2 not in list_dict2_keys and key3 not in list_dict3_keys:
                        list_dict1_keys.append(key1)
                        print('aln Busco not in any list: ', key1)
                        list_dict2_keys.append(key2)
                        print('aln Miniprot not in any list: ', key2)
                        list_dict3_keys.append(key3)
                        print('aln Scipio not in any list: ', key3)
                    else:
                        list_dict1_keys_to_remove.append(key1)
                        print('aln Busco already in list: ', key1)
                        list_dict2_keys_to_remove.append(key2)
                        print('aln Miniprot already in list: ', key2)
                        list_dict3_keys_to_remove.append(key3)
                        print('aln Scipio already in list: ', key3)

    dict_keys = {
        'keys_dict1': list_dict1_keys,
        'keys_dict2': list_dict2_keys,
        'keys_dict3': list_dict3_keys,
        'keys_dict1_to_remove': list_dict1_keys_to_remove,
        'keys_dict2_to_remove': list_dict2_keys_to_remove,
        'keys_dict3_to_remove': list_dict3_keys_to_remove
    }

    return dict_keys

#dict_keys_BMS = common_keys_for_all(busco_dict, miniprot_dict, scipio_dict)
#print(dict_keys_BMS)

# Fonction pour trouver les clés communes avec au moins une ligne identique entre les deux dictionnaires en excluant celles communes aux trois
# A exectuer à partir des dossiers filtrés !
def common_keys_only_two(dict1, dict2, list_dict1_aln, list_dict2_aln):
    list_dict1_keys_only_two = []
    list_dict2_keys_only_two = []
    list_dict1_keys_common = []
    list_dict2_keys_common = []
    
    for key1, value1 in dict1.items():
        for key2, value2 in dict2.items():
            if any(line1 in value2 for line1 in value1):
                
                if key1 not in list_dict1_aln and key2 not in list_dict2_aln:
                    list_dict1_keys_only_two.append(key1)
                    list_dict2_keys_only_two.append(key2)
                
                else:
                    list_dict1_keys_common.append(key1)
                    list_dict2_keys_common.append(key2)
                       
    dict_keys = {
        'keys_dict1_only_two': list_dict1_keys_only_two,
        'keys_dict2_only_two': list_dict2_keys_only_two,
        'keys_dict1_common': list_dict1_keys_common,
        'keys_dict2_common': list_dict2_keys_common
    }                    
    
    return dict_keys

# Récupérer le chemin aux listes d'alignements communs aux trois jeux de données
path_busco_aln_common = "/home/gwen/Work/Work1/MapNH/list_aln_busco_BMS_to_keep.txt"
path_miniprot_aln_common = "/home/gwen/Work/Work1/MapNH/list_aln_miniprot_BMS_to_keep.txt"
path_scipio_aln_common = "/home/gwen/Work/Work1/MapNH/list_aln_scipio_BMS_to_keep.txt"

# Liste pour stocker les lignes du fichier
list_busco_aln_common = []
list_miniprot_aln_common = []
list_scipio_aln_common = []

# Ouvre le fichier en mode lecture
with open(path_busco_aln_common, 'r') as file_aln:
    # Lit chaque ligne du fichier et crée une liste
    for line in file_aln:
        # Supprime le caractère '/n' à la fin de la ligne
        line_cut = line.strip()
        # Ajoute la ligne à la liste
        list_busco_aln_common.append(line_cut)

#print(f"Nombre d'aln dans la liste Busco pour les trois jeux : {len(list_busco_aln_common)}")
#print(list_busco_aln_common)

# Ouvre le fichier en mode lecture
with open(path_miniprot_aln_common, 'r') as file_aln:
    # Lit chaque ligne du fichier et crée une liste
    for line in file_aln:
        # Supprime le caractère '/n' à la fin de la ligne
        line_cut = line.strip()
        # Ajoute la ligne à la liste
        list_miniprot_aln_common.append(line_cut)

# Ouvre le fichier en mode lecture
with open(path_scipio_aln_common, 'r') as file_aln:
    # Lit chaque ligne du fichier et crée une liste
    for line in file_aln:
        # Supprime le caractère '/n' à la fin de la ligne
        line_cut = line.strip()
        # Ajoute la ligne à la liste
        list_scipio_aln_common.append(line_cut)

# Comparaisons entre Busco et Miniprot
# WARNING : A exectuer à partir des dossiers filtrés !
#dict_keys_busco_miniprot_only_two = common_keys_only_two(busco_dict, miniprot_dict, list_busco_aln_common, list_miniprot_aln_common)
#print(dict_keys_busco_miniprot_only_two)

# Busco
# Récupérer la liste des genes Busco communs avec Miniprot
#list_keys_busco_BM_only_two = dict_keys_busco_miniprot_only_two.get('keys_dict1_only_two', [])
#print(f"Nombre de clés Busco commune avec Miniprot uniquement : {len(list_keys_busco_BM_only_two)}")

# Afficher la liste dans le terminal pour l'enregister sous un fichier texte
#for file_name in list_keys_busco_BM_only_two :
    #print(file_name)

# Miniprot
# Récupérer la liste des genes Miniprot communs avec Busco
#list_keys_miniprot_BM_only_two = dict_keys_busco_miniprot_only_two.get('keys_dict2_only_two', [])
#print(f"Nombre de clés Miniprot commune avec Busco uniquement : {len(list_keys_miniprot_BM_only_two)}")

# Afficher la liste dans le terminal pour l'enregister sous un fichier texte
#for file_name in list_keys_miniprot_BM_only_two :
    #print(file_name)

# Comparaisons entre Busco et Scipio
# A exectuer à partir des dossiers filtrés !
#dict_keys_busco_scipio_only_two = common_keys_only_two(busco_dict, scipio_dict, list_busco_aln_common, list_scipio_aln_common)

# Busco
# Récupérer la liste des genes Busco communs avec Scipio
#list_keys_busco_BS_only_two = dict_keys_busco_scipio_only_two.get('keys_dict1_only_two', [])
#print(f"Nombre de clés Busco commune avec Scipio uniquement : {len(list_keys_busco_BS_only_two)}")

# Afficher la liste dans le terminal pour l'enregister sous un fichier texte
#for file_name in list_keys_busco_BS_only_two :
    #print(file_name)

# Scipio
# Récupérer la liste des genes Scipio communs avec Busco
#list_keys_scipio_BS_only_two = dict_keys_busco_scipio_only_two.get('keys_dict2_only_two', [])
#print(f"Nombre de clés Scipio commune avec Busco uniquement : {len(list_keys_scipio_BS_only_two)}")

# Afficher la liste dans le terminal pour l'enregister sous un fichier texte
#for file_name in list_keys_scipio_BS_only_two :
    #print(file_name)

# Comparaisons entre Miniprot et Scipio
# A exectuer à partir des dossiers filtrés !
#dict_keys_miniprot_scipio_only_two = common_keys_only_two(miniprot_dict, scipio_dict, list_miniprot_aln_common, list_scipio_aln_common)
#print(dict_keys_busco_miniprot)

# Miniprot
# Récupérer la liste des genes Miniprot communs avec Scipio
#list_keys_miniprot_MS_only_two = dict_keys_miniprot_scipio_only_two.get('keys_dict1_only_two', [])
#print(f"Nombre de clés Miniprot commune avec Scipio uniquement : {len(list_keys_miniprot_MS_only_two)}")

# Afficher la liste dans le terminal pour l'enregister sous un fichier texte
#for file_name in list_keys_miniprot_MS_only_two :
    #print(file_name)

# Scipio
# Récupérer la liste des genes Scipio communs avec Miniprot
#list_keys_scipio_MS_only_two = dict_keys_miniprot_scipio_only_two.get('keys_dict2_only_two', [])
#print(f"Nombre de clés Scipio commune avec Miniprot uniquement : {len(list_keys_scipio_MS_only_two)}")

# Afficher la liste dans le terminal pour l'enregister sous un fichier texte
#for file_name in list_keys_scipio_MS_only_two :
    #print(file_name)



