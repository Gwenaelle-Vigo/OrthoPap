#!/usr/bin/env Rscript

# Installer le package 'ape' si ce n'est pas déjà fait
if (!requireNamespace("ape", quietly = TRUE)) {
  install.packages("ape")
}

# Charger le package 'ape'
library(ape)

# Vérifier les arguments en ligne de commande
args <- commandArgs(trailingOnly = TRUE)

if (length(args) < 2) {
  stop("2 arguments must be supplied: [1] tree_file_30_species [2] folder_path", call. = FALSE)
}

tree_file <- args[1]    # path to the file containing the complet Newick tree
folder_path <- args[2]  # path to the folder containing .tre files


# Lire l'arbre phylogénétique de toutes les espèces
phylo <- read.tree(tree_file)

# Parcourir les dossiers contenant les fichiers .aln
for (dirname in list.files(folder_path)) {
  #filename <- sub("mapNH$", "macse_final_mask_align_NT_pruned.aln", dirname)
  filename <- sub("$", "_macse_final_unmask_align_NT_NT_NT_filtered_rename_phyltered.aln", dirname)
  aln_path <- file.path(folder_path, dirname, filename)
  out_tree_name <- sub(".aln$", ".aln.treefile", aln_path)
  
  # Identifier les feuilles à garder
  align <- read.dna(aln_path, format = "fasta")
  sp_list <- labels(align)
  
  # Garder les feuilles spécifiées
  pruned_phylo <- keep.tip(phylo, sp_list)
  
  # Sauvegarder l'arbre phylogénétique élagué
  write.tree(pruned_phylo, file = out_tree_name)
}


