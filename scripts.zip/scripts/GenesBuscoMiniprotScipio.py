#! /usr/bin/env python3

# Ce script crée un dictionnaire par jeu de données issus d'annotation différente (Busco, Miniprot et Scipio) avec le nom du fichier d'alignement en clé et le nom des gènes des trois espèces de références en values. Puis il compare les noms de gène des trois espèces (values) uniques ou partagés entre les trois dictionnaires afin de récupérer les nom des fichiers d'alignements (clés) spécifiques à chaque annotation.

import sys
import os

if len(sys.argv) != 2:
    sys.exit("1 argument must be supplied: [1] folder_path")

### Partie 1
# La partie suivante parcourt tous les dossiers d'alignements du répertoire d'entrée, lit chaque ligne du fichier d'alignement, et ajoute les lignes qui commencent par l'une des chaînes cibles (nom du gène des trois espèces de référence) au dictionnaire avec le nom du fichier comme clé. Ensuite, il affiche le dictionnaire résultant.
    
# Définition d'une fonction pour la création d'un dictionnaire par dossier
def create_dict_from_folder(folder_path, target_strings):
    # Initialiser le dictionnaire
    result_dict = {}
    
    # Parcourir tous les fichiers dans le dossier
    for directory in os.listdir(folder_path):
        filename = directory.replace("mapNH", "macse_final_mask_align_NT_pruned_complet.aln")
        file_path = os.path.join(folder_path, directory, filename)
        
        # Vérifier si le chemin correspond à un fichier
        if os.path.isfile(file_path):
            # Ouvrir le fichier en mode lecture
            with open(file_path, 'r') as file:
                # Lire chaque ligne du fichier
                for line in file:
                    # Vérifier si la ligne commence par l'une des chaînes cibles
                    for target_string in target_strings:
                        if line.startswith(target_string):
                            # Ajouter le fichier au dictionnaire s'il n'est pas déjà présent
                            if filename not in result_dict:
                                result_dict[filename] = []
                            # Ajouter la ligne au contenu associé à la clé
                            result_dict[filename].append(line.strip())
        else :
            print(f"Le chemin {file_path} ne correspond à aucun fichier")
    return result_dict

# Définir les chaînes de caractères à rechercher
target_strings = [
    '>NCBI_GCA907164705.1_Parnassius_apollo',
    '>NCBI_GCF000836235.2_Papilio_xuthus',
    '>Maker_Out_Ornithoptera_alexandrae'
]

# Définir le chemin du dossier Busco
folder_path = sys.argv[1]

# Création du dictionnaire Busco
dictionary = create_dict_from_folder(folder_path, target_strings)

# Afficher la liste des key du dictionnaire
for key, value in dictionary.items():
    print(key)


