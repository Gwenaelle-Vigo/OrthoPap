#! /usr/bin/env python3

# Ce script crée un dictionnaire par jeu de données issus d'annotation différente (Busco, Miniprot et Scipio) avec le nom du fichier d'alignement en clé et le nom des gènes des trois espèces de références en values. Puis il compare les noms de gène des trois espèces (values) uniques ou partagés entre les trois dictionnaires afin de récupérer les nom des fichiers d'alignements (clés) spécifiques à chaque annotation.

import sys
import os

# WARNING : A exectuer à partir des dossiers filtrés !

if len(sys.argv) != 4:
    sys.exit("3 arguments must be supplied: [1] Comparison(1_2) [2] filtered_folder_path_1 [3] filtered_folder_path_2")

### Partie 1
# La partie suivante parcourt tous les dossiers d'alignements du répertoire d'entrée, lit chaque ligne du fichier d'alignement, et ajoute les lignes qui commencent par l'une des chaînes cibles (nom du gène des trois espèces de référence) au dictionnaire avec le nom du fichier comme clé. Ensuite, il affiche le dictionnaire résultant.
    
# Définition d'une fonction pour la création d'un dictionnaire par dossier
def create_dict_from_folder(folder_path, target_strings):
    # Initialiser le dictionnaire
    result_dict = {}
    
    # Parcourir tous les fichiers dans le dossier
    for directory in os.listdir(folder_path):
        filename = directory.replace("mapNH", "macse_final_mask_align_NT_pruned_complet.aln")
        file_path = os.path.join(folder_path, directory, filename)
        
        # Vérifier si le chemin correspond à un fichier
        if os.path.isfile(file_path):
            # Ouvrir le fichier en mode lecture
            with open(file_path, 'r') as file:
                # Lire chaque ligne du fichier
                for line in file:
                    # Vérifier si la ligne commence par l'une des chaînes cibles
                    for target_string in target_strings:
                        if line.startswith(target_string):
                            # Ajouter le fichier au dictionnaire s'il n'est pas déjà présent
                            if filename not in result_dict:
                                result_dict[filename] = []
                            # Ajouter la ligne au contenu associé à la clé
                            result_dict[filename].append(line.strip())
        else :
            print(f"Le chemin {file_path} ne correspond à aucun fichier")
    return result_dict


### Partie 2
# Fonction pour trouver les clés communes avec au moins une ligne identique entre les deux dictionnaires en excluant celles communes aux trois
def common_keys_only_two(dict1, dict2, list_dict1_aln, list_dict2_aln):
    list_dict1_keys_only_two = []
    list_dict2_keys_only_two = []
    list_dict1_keys_common = []
    list_dict2_keys_common = []
    
    for key1, value1 in dict1.items():
        for key2, value2 in dict2.items():
            if any(line1 in value2 for line1 in value1):
                
                if key1 not in list_dict1_aln and key2 not in list_dict2_aln:
                    list_dict1_keys_only_two.append(key1)
                    list_dict2_keys_only_two.append(key2)
                    print(f"CommonToTwo;{key1};{key2}")
                
                else:
                    list_dict1_keys_common.append(key1)
                    list_dict2_keys_common.append(key2)
                    print(f"CommonToThree;{key1};{key2}")
                       
    dict_keys = {
        'keys_dict1_only_two': list_dict1_keys_only_two,
        'keys_dict2_only_two': list_dict2_keys_only_two,
        'keys_dict1_common': list_dict1_keys_common,
        'keys_dict2_common': list_dict2_keys_common
    }                    
    
    return dict_keys
    
# Définir les chaînes de caractères à rechercher
target_strings = [
    '>NCBI_GCA907164705.1_Parnassius_apollo',
    '>NCBI_GCF000836235.2_Papilio_xuthus',
    '>Maker_Out_Ornithoptera_alexandrae'
]

# Définir la comparaison désirée
comparison = sys.argv[1]

# Récupération des noms de fichier aln de gene commun sous forme de liste selon l'annotateur déterminé en argument
if comparison == "Busco_Miniprot":
    # Récupérer les chemins des dossiers
    busco_folder_path = sys.argv[2]
    miniprot_folder_path = sys.argv[3]
    # Récupérer le chemin aux listes d'alignements communs aux trois jeux de données
    path_busco_aln_common = "/home/gwen/Work/Work1/MapNH/Common_OG_lists/list_aln_busco_BMS_to_keep.txt"
    path_miniprot_aln_common = "/home/gwen/Work/Work1/MapNH/Common_OG_lists/list_aln_miniprot_BMS_to_keep.txt"
    # Création des dictionnaires initiaux
    busco_dict = create_dict_from_folder(busco_folder_path, target_strings)
    miniprot_dict = create_dict_from_folder(miniprot_folder_path, target_strings)
    # Liste pour stocker les lignes du fichier
    list_busco_aln_common = []
    list_miniprot_aln_common = []
    # Ouvre le fichier en mode lecture
    with open(path_busco_aln_common, 'r') as file_aln:
        # Lit chaque ligne du fichier et crée une liste
        for line in file_aln:
            # Supprime le caractère '/n' à la fin de la ligne
            line_cut = line.strip()
            # Ajoute la ligne à la liste
            list_busco_aln_common.append(line_cut)
    # Ouvre le fichier en mode lecture
    with open(path_miniprot_aln_common, 'r') as file_aln:
        # Lit chaque ligne du fichier et crée une liste
        for line in file_aln:
            # Supprime le caractère '/n' à la fin de la ligne
            line_cut = line.strip()
            # Ajoute la ligne à la liste
            list_miniprot_aln_common.append(line_cut)
    # Création du dictionnaire
    dict_keys_busco_miniprot_only_two = common_keys_only_two(busco_dict, miniprot_dict, list_busco_aln_common, list_miniprot_aln_common)

elif comparison == "Busco_Scipio":
    # Récupérer les chemins des dossiers
    busco_folder_path = sys.argv[2]
    scipio_folder_path = sys.argv[3]
    # Récupérer le chemin aux listes d'alignements communs aux trois jeux de données
    path_busco_aln_common = "/home/gwen/Work/Work1/MapNH/Common_OG_lists/list_aln_busco_BMS_to_keep.txt"
    path_scipio_aln_common = "/home/gwen/Work/Work1/MapNH/Common_OG_lists/list_aln_scipio_BMS_to_keep.txt"
    # Création des dictionnaires initiaux
    busco_dict = create_dict_from_folder(busco_folder_path, target_strings)
    scipio_dict = create_dict_from_folder(scipio_folder_path, target_strings)
    # Liste pour stocker les lignes du fichier
    list_busco_aln_common = []
    list_scipio_aln_common = []
    # Ouvre le fichier en mode lecture
    with open(path_busco_aln_common, 'r') as file_aln:
        # Lit chaque ligne du fichier et crée une liste
        for line in file_aln:
            # Supprime le caractère '/n' à la fin de la ligne
            line_cut = line.strip()
            # Ajoute la ligne à la liste
            list_busco_aln_common.append(line_cut)
    # Ouvre le fichier en mode lecture
    with open(path_scipio_aln_common, 'r') as file_aln:
        # Lit chaque ligne du fichier et crée une liste
        for line in file_aln:
            # Supprime le caractère '/n' à la fin de la ligne
            line_cut = line.strip()
            # Ajoute la ligne à la liste
            list_scipio_aln_common.append(line_cut)
    # Création du dictionnaire
    dict_keys_busco_scipio_only_two = common_keys_only_two(busco_dict, scipio_dict, list_busco_aln_common, list_scipio_aln_common)
 
elif comparison == "Miniprot_Scipio":
    # Récupérer les chemins des dossiers
    miniprot_folder_path = sys.argv[2]
    scipio_folder_path = sys.argv[3]
    # Récupérer le chemin aux listes d'alignements communs aux trois jeux de données
    path_miniprot_aln_common = "/home/gwen/Work/Work1/MapNH/Common_OG_lists/list_aln_miniprot_BMS_to_keep.txt"
    path_scipio_aln_common = "/home/gwen/Work/Work1/MapNH/Common_OG_lists/list_aln_scipio_BMS_to_keep.txt"
    # Création des dictionnaires initiaux
    miniprot_dict = create_dict_from_folder(miniprot_folder_path, target_strings)
    scipio_dict = create_dict_from_folder(scipio_folder_path, target_strings)
    # Liste pour stocker les lignes du fichier
    list_miniprot_aln_common = []
    list_scipio_aln_common = []
    # Ouvre le fichier en mode lecture
    with open(path_miniprot_aln_common, 'r') as file_aln:
        # Lit chaque ligne du fichier et crée une liste
        for line in file_aln:
            # Supprime le caractère '/n' à la fin de la ligne
            line_cut = line.strip()
            # Ajoute la ligne à la liste
            list_miniprot_aln_common.append(line_cut)
    # Ouvre le fichier en mode lecture
    with open(path_scipio_aln_common, 'r') as file_aln:
        # Lit chaque ligne du fichier et crée une liste
        for line in file_aln:
            # Supprime le caractère '/n' à la fin de la ligne
            line_cut = line.strip()
            # Ajoute la ligne à la liste
            list_scipio_aln_common.append(line_cut)
    # Création du dictionnaire
    dict_keys_miniprot_scipio_only_two = common_keys_only_two(miniprot_dict, scipio_dict, list_miniprot_aln_common, list_scipio_aln_common)
    
else:
    print("ERREUR :")
    print("Le 1er argument doit indiquer la comparaison désirée")
    print("OPTIONS :")
    print("- entre Busco et Miniprot : 'Busco_Miniprot'")
    print("- entre Busco et Scipio : 'Busco_Scipio'")
    print("- entre Miniprot et Scipio : 'Miniprot_Scipio'")





