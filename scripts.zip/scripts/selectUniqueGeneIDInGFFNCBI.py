#! /usr/bin/env python

## Make a list of the gene that have a unique position in the GFF
## If two gene share a exon then only on is kept (longer)

## work with NCBI GFF
import sys


# Function to find information in position in FORMAT field 
def findNameinAttributesField(Attribute):
	Name = ""
	findIt = "no"
	info = Attribute.split(";")
	for i in info:
		if "Name=" in i:
			name=i.split("=")[1]
			return(name)
			break
	return("NoName")
	
def findGeneIDinAttributesField(Attribute):
	GeneID = ""
	findIt = "no"
	info = Attribute.split(";")
	for i in info:
		if "GeneID:" in i:
			name=i.split(",")[0]
			GeneID=name.split(":")[1]
			return(GeneID)
			break
	return("NoGeneID")		

# SeqSize
def SeqSize(file_fasta):
	sSeq = 0
	nSeq = ""
	gene_size = {}
	for line in file_fasta:
		line = line.rstrip();
		if ">" in line:
			line = line.lstrip(">")
			if nSeq == "":
				nSeq = line
				continue
		
			gene_size[nSeq] = sSeq
			nSeq = line
			sSeq = 0
		else:
			sSeq = sSeq + len(line)

	gene_size[nSeq] = sSeq
	return(gene_size)
	

## fasta file with proteins
f = open(sys.argv[1])
gene_size = SeqSize(f)
	
	
gff = open(sys.argv[2])
EXON_pos = {}
gene2exclude = {}
GENEID = {}
GENENAME = {}

for li in gff:

	if li[0] == "#":
		continue
		
	li = li.rstrip()
	arrli = li.split()
	
	if arrli[2] != "CDS":
		continue
		
	exonInfo1 =  arrli[8]
	pos = arrli[0]+"_"+arrli[3]+"_"+arrli[4]
		
	geneID = findGeneIDinAttributesField(exonInfo1)
	gene1 = findNameinAttributesField(exonInfo1)
	
	GENENAME[gene1] = geneID
	
	if geneID in GENEID:
		gene2 = GENEID[geneID]
		
		if gene1 == gene2:
			continue
		
		#print(gene1+" "+gene2)
		sizeg1 = gene_size[gene1]
		sizeg2 = gene_size[gene2]
		
		# keep gene1
		if sizeg1 == sizeg2 or sizeg1 > sizeg2:
			GENEID[geneID] = gene1
			continue
			
		# keep gene2 if it is not already excluded in a previous comparison
		if sizeg1 < sizeg2:
			continue
	else:
		GENEID[geneID] = gene1
	
for geneID in GENEID:
	print(GENEID[geneID])

		

