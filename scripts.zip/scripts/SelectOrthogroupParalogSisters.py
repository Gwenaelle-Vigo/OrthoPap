#! /usr/bin/env python3

# Ce script utilise le package ETE pour comparer les noms des feuilles dans les arbres de gène des orthogroupes contenant un gène paraloguà partir d'une liste de noms d'orthogroupes. Il identifie les orthogroupes où le nom d'une espèce apparait deux fois dans le même arbre de gène et déterminer si ces deux gènes paralogues appartiennent à des feuilles sœurs (provenant d'un même ancêtre) ou non.

import sys
from ete3 import Tree

# Vérifier si le nombre d'arguments est correct
if len(sys.argv) != 3:
    print("Utilisation : script.py List_orthogroup_names_one_paralog.txt pathway_to_directory_Resolved_Gene_Trees")
    sys.exit(1)

# Récupérer le chemin vers le fichier contenant la liste des orthogroups possédant un gène paralogue à partir des arguments en ligne de commande
list_Orthogroups_one_paralogs = sys.argv[1]

# Récupérer le chemin vers le répertoire contenant les arbres phylogénétiques résolus
pathway_to_directory_Resolved_Gene_Trees = sys.argv[2]

# Liste des noms d'espèces à parcourir
species = ["Baronia_brevicornis", "Battus_polydamas", "Bhutanitis_thaidina", "Byasa_hedistus", "Graphium_agamemnon", "Graphium_antheus", "Graphium_antiphates", "Graphium_doson", "Iphiclides_podalirius", "Lamproptera_curius", "Luehdorfia_chinensis", "Meandrusa_payeni", "Ornithoptera_alexandrae", "Ornithoptera_priamus", "Pachliopta_arisolochiae", "Papilio_bianor", "Papilio_demoleus", "Papilio_elwesi", "Papilio_machaon", "Papilio_protenor", "Papilio_xuthus", "Parides_eurimedes", "Parides_vertumnus", "Parnassius_apollo", "Parnassius_orleans", "Pharmacophagus_antenor", "Sericinus_montela", "Teinopalpus_imperialis", "Troides_helena", "Troides_oblongomaculatus"]

# Initialiser une liste pour stocker les noms des feuilles correspondantes
leaf_names = []

# Initialiser une liste pour stocker les orthogroupes pour lesquels le fichier n'a pas été trouvé
missing_files = []

# Initialiser une liste pour stocker les orthogroupes avec des feuilles sœurs
list_OG_paralog_sisters = []

# Initialiser une liste pour stocker les orthogroupes avec des feuilles cousines
list_OG_paralog_cousins  = []

# Initialiser une liste pour stocker les orthogroupes sans feuilles sœurs
list_OG_paralog_notsisters = []


# Parcourir les orthogroups
with open(list_Orthogroups_one_paralogs, 'r') as og_file:
    for OG in og_file:
        OG = OG.strip()  # Supprimer les espaces ou retours à la ligne
        # Récupérer le chemin vers le fichier contenant l'arbre Newick au format texte
        file_tree = f"{pathway_to_directory_Resolved_Gene_Trees}/{OG}_tree.txt"

        # Lire le contenu du fichier
        try:
            with open(file_tree, 'r') as file_t:
                tree_Newick = file_t.read()
        except FileNotFoundError:
            print(f"Le fichier {file_tree} n'a pas été trouvé.")
            missing_files.append(OG)
            continue  # Passer au fichier suivant

        # Charger l'arbre phylogénétique depuis le contenu du fichier
        tree = Tree(tree_Newick, format=1)  # format 1 : flexible with internal node names

        # Parcourir les noms d'especes
        for sp in species:
            # Parcourir les feuilles de l'arbre
            for leaf1 in tree:
                if leaf1.is_leaf():
                    for leaf2 in tree:
                        if leaf2.is_leaf() and leaf1 != leaf2:
                            # Vérifier si le mot spécifié est présent dans le nom des deux feuilles
                            if sp in leaf1.name and sp in leaf2.name:
                                # Ajouter les noms des feuilles correspondantes pour cet OG à la liste principale
                                leaf_names.append((OG, leaf1.name, leaf2.name))
                                
                                # Vérifier si les feuilles sont sœurs
                                common_ancestor = tree.get_common_ancestor(leaf1.name, leaf2.name)
                                if len(common_ancestor.get_leaves()) == 2:
                                    # Les feuilles sont sœurs
                                    if OG not in list_OG_paralog_sisters:
                                        list_OG_paralog_sisters.append(OG)
                                elif len(common_ancestor.get_leaves()) == 3:
                                    # Les feuilles sont cousines
                                    if OG not in list_OG_paralog_cousins:
                                        list_OG_paralog_cousins.append(OG)
                                else:
                                    # Les feuilles ne sont pas sœurs
                                    if OG not in list_OG_paralog_notsisters:
                                        list_OG_paralog_notsisters.append(OG)
                                
                                break # Passer à l'OG suivant dès qu'une paire est trouvée

# Afficher les noms des feuilles correspondantes
for og, name1, name2 in leaf_names:
    print(f"OG : {og}, Feuille 1 : {name1}, Feuille 2 : {name2}")

# Afficher les orthogroupes dont les paralogues sont des feuilles sœurs
if list_OG_paralog_sisters:
    print("Voici les orthogroupes dont les paralogues sont des feuilles sœur :")
    print(", ".join(list_OG_paralog_sisters))

# Afficher les orthogroupes dont les paralogues sont des feuilles cousines
if list_OG_paralog_cousins:
    print("Voici les orthogroupes dont les paralogues sont des feuilles cousines :")
    print(", ".join(list_OG_paralog_cousins))

# Afficher les orthogroupes dont les paralogues ne sont pas des feuilles sœur
if list_OG_paralog_notsisters:
    print("Voici les orthogroupes dont les paralogues ne sont pas des feuilles sœur :")
    print(", ".join(list_OG_paralog_notsisters))

# Afficher les noms des fichiers d'arbres phylogénétiques non trouvés
if missing_files:
    print("Voici les orthogroupes pour lesquels le fichier n'a pas été trouvé :")
    print(", ".join(missing_files))

# Afficher le nombre d'orthogroupes dont les paralogues sont des feuilles sœur
print(f"Il y a {len(list_OG_paralog_sisters)} orthogroupes dont les paralogues sont des feuilles sœur.")

# Afficher le nombre d'orthogroupes dont les paralogues sont des feuilles cousines
print(f"Il y a {len(list_OG_paralog_cousins)} orthogroupes dont les paralogues sont des feuilles cousines.")

# Afficher le nombre d'orthogroupes dont les paralogues ne sont pas des feuilles sœur
print(f"Il y a {len(list_OG_paralog_notsisters)} orthogroupes dont les paralogues ne sont pas des feuilles sœur.")

# Afficher le nombre de fichiers d'arbres phylogénétiques non trouvés
print(f"Il y a {len(missing_files)} fichiers OG_tree.txt qui n'ont pas été trouvés.")

