#! /usr/bin/env python3

# Ce script crée un dictionnaire par jeu de données issus d'annotation différente (Busco, Miniprot et Scipio) avec le nom du fichier d'alignement en clé et le nom des gènes des trois espèces de références en values. Puis il compare les noms de gène des trois espèces (values) uniques ou partagés entre les trois dictionnaires afin de récupérer les nom des fichiers d'alignements (clés) spécifiques à chaque annotation.

import sys
import os

if len(sys.argv) < 4:
    sys.exit("3 arguments must be supplied: [1] folder_path_Busco [2] folder_path_Miniprot [3] folder_path_Scipio")

### Partie 1
# La partie suivante parcourt tous les dossiers d'alignements du répertoire d'entrée, lit chaque ligne du fichier d'alignement, et ajoute les lignes qui commencent par l'une des chaînes cibles (nom du gène des trois espèces de référence) au dictionnaire avec le nom du fichier comme clé. Ensuite, il affiche le dictionnaire résultant.
    
# Définir les chaînes de caractères à rechercher
target_strings = [
    '>NCBI_GCA907164705.1_Parnassius_apollo',
    '>NCBI_GCF000836235.2_Papilio_xuthus',
    '>Maker_Out_Ornithoptera_alexandrae'
]

# Définir le chemin du dossier 
busco_folder_path = sys.argv[1]
miniprot_folder_path = sys.argv[2]
scipio_folder_path = sys.argv[3]

# Définition d'une fonction pour la création d'un dictionnaire par dossier
def create_dict_from_folder(folder_path, target_strings):
    # Initialiser le dictionnaire
    result_dict = {}
    
    # Parcourir tous les fichiers dans le dossier
    for directory in os.listdir(folder_path):
        filename = directory.replace("mapNH", "macse_final_mask_align_NT_pruned_complet.aln")
        file_path = os.path.join(folder_path, directory, filename)
        
        # Vérifier si le chemin correspond à un fichier
        if os.path.isfile(file_path):
            # Ouvrir le fichier en mode lecture
            with open(file_path, 'r') as file:
                # Lire chaque ligne du fichier
                for line in file:
                    # Vérifier si la ligne commence par l'une des chaînes cibles
                    for target_string in target_strings:
                        if line.startswith(target_string):
                            # Ajouter le fichier au dictionnaire s'il n'est pas déjà présent
                            if filename not in result_dict:
                                result_dict[filename] = []
                            # Ajouter la ligne au contenu associé à la clé
                            result_dict[filename].append(line.strip())
        else :
            print(f"Le chemin {file_path} ne correspond à aucun fichier")
    return result_dict

# Création du dictionnaire Busco
busco_dict = create_dict_from_folder(busco_folder_path, target_strings)

# Création du dictionnaire Miniprot
miniprot_dict = create_dict_from_folder(miniprot_folder_path, target_strings)

# Création du dictionnaire Scipio
scipio_dict = create_dict_from_folder(scipio_folder_path, target_strings)

# Fonction pour trouver les clés communes avec au moins une ligne identique entre les trois dictionnaires
def common_keys_for_all(dict1, dict2, dict3):
    list_dict1_keys = []
    list_dict2_keys = []
    list_dict3_keys = []
    list_dict1_keys_to_remove = []
    list_dict2_keys_to_remove = []
    list_dict3_keys_to_remove = []

    for key1, value1 in dict1.items():
        for key2, value2 in dict2.items():
            for key3, value3 in dict3.items():
                if any(line1 in value2 for line1 in value1) and any(line1 in value3 for line1 in value1):

                    if key1 not in list_dict1_keys and key2 not in list_dict2_keys and key3 not in list_dict3_keys:
                        list_dict1_keys.append(key1)
                        list_dict2_keys.append(key2)
                        list_dict3_keys.append(key3)
                        print(f"Rename_OG;{key1};{key2};{key3}")
                    else:
                        list_dict1_keys_to_remove.append(key1)
                        list_dict2_keys_to_remove.append(key2)
                        list_dict3_keys_to_remove.append(key3)
                        print(f"Remove_OG;{key1};{key2};{key3}")

    dict_keys = {
        'keys_dict1': list_dict1_keys,
        'keys_dict2': list_dict2_keys,
        'keys_dict3': list_dict3_keys,
        'keys_dict1_to_remove': list_dict1_keys_to_remove,
        'keys_dict2_to_remove': list_dict2_keys_to_remove,
        'keys_dict3_to_remove': list_dict3_keys_to_remove
    }

    return dict_keys

# Création du dictionnaire des genes communs aux trois
print(f"OG_Common;OG_Busco;OG_Miniprot;OG_Scipio")
dict_keys_BMS = common_keys_for_all(busco_dict, miniprot_dict, scipio_dict)


