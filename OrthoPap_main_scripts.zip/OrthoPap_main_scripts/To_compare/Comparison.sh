#!/bin/sh

# Command to use:
#Comparison.sh [Path_working_directory]

### Comparison step
# Search for common files between BUSCO, Miniprot and Scipio using reference genes from reference species

# Definition of the access path to the working directory:
Path_working_directory=$1

# Definition of the number of CPUs:
CPU=$2

# Creation of directories for cleaning
mkdir $Path_working_directory/comparison
mkdir $Path_working_directory/comparison/comparison_busco
mkdir $Path_working_directory/comparison/comparison_miniprot
mkdir $Path_working_directory/comparison/comparison_scipio
mkdir $Path_working_directory/comparison/common_OG_lists

# Copy of the phylter directories so that alignments can be deleted safely
cp -r $Path_working_directory/cleaning/phylter_busco/alignment_phylter_busco/* $Path_working_directory/comparison/comparison_busco
cp -r $Path_working_directory/cleaning/phylter_miniprot/alignment_phylter_miniprot/* $Path_working_directory/comparison/comparison_miniprot
cp -r $Path_working_directory/cleaning/phylter_scipio/alignment_phylter_scipio/* $Path_working_directory/comparison/comparison_scipio

# Add the full name of the sequences to the pruned alignment file (for Busco, then Miniprot and Scipio)
for dir in $(ls $Path_working_directory/comparison/comparison_busco/*); do for name in $(grep '>' $Path_working_directory/comparison/comparison_busco/${dir}/${dir%_phylter}_macse_final_mask_align_NT_rename_pruned.aln); do grep -A1 "$name" $Path_working_directory/comparison/comparison_busco/${dir}/${dir%_phylter}_macse_final_mask_align_NT.aln; done > $Path_working_directory/comparison/comparison_busco/${dir}/${dir%_phylter}_macse_final_mask_align_NT_pruned_complet.aln; done

for dir in $(ls $Path_working_directory/comparison/comparison_miniprot/*); do for name in $(grep '>' $Path_working_directory/comparison/comparison_miniprot/${dir}/${dir%_phylter}_macse_final_mask_align_NT_rename_pruned.aln); do grep -A1 "$name" $Path_working_directory/comparison/comparison_miniprot/${dir}/${dir%_phylter}_macse_final_mask_align_NT.aln; done > $Path_working_directory/comparison/comparison_miniprot/${dir}/${dir%_phylter}_macse_final_mask_align_NT_pruned_complet.aln; done

for dir in $(ls $Path_working_directory/comparison/comparison_scipio/*); do for name in $(grep '>' $Path_working_directory/comparison/comparison_scipio/${dir}/${dir%_phylter}_macse_final_mask_align_NT_rename_pruned.aln); do grep -A1 "$name" $Path_working_directory/comparison/comparison_scipio/${dir}/${dir%_phylter}_macse_final_mask_align_NT.aln; done > $Path_working_directory/comparison/comparison_scipio/${dir}/${dir%_phylter}_macse_final_mask_align_NT_pruned_complet.aln; done

# Removal of OGs whose reference genes are found in different alignments (for Busco, then Miniprot and Scipio)
$Path_working_directory/scripts/GenesBuscoMiniprotScipioToRemove.py Busco $Path_working_directory/comparison/comparison_busco/ $Path_working_directory/comparison/comparison_miniprot/ $Path_working_directory/comparison/comparison_scipio/ > $Path_working_directory/comparison/common_OG_lists/list_aln_busco_to_remove.txt

$Path_working_directory/scripts/GenesBuscoMiniprotScipioToRemove.py Miniprot $Path_working_directory/comparison/comparison_busco/ $Path_working_directory/comparison/comparison_miniprot/ $Path_working_directory/comparison/comparison_scipio/ > $Path_working_directory/comparison/common_OG_lists/list_aln_busco_to_remove.txt

$Path_working_directory/scripts/GenesBuscoMiniprotScipioToRemove.py Scipio $Path_working_directory/comparison/comparison_busco/ $Path_working_directory/comparison/comparison_miniprot/ $Path_working_directory/comparison/comparison_scipio/ > $Path_working_directory/comparison/common_OG_lists/list_aln_busco_to_remove.txt

# Removal of OG files whose reference species genes are not found in the same OG between two different annotation sets (for Busco, then Miniprot and Scipio)
for aln in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_busco_to_remove.txt); do dir=$(sed 's/macse_final_mask_align_NT_pruned_complet.aln/phylter/' <<< ${aln}); rm -r $Path_working_directory/comparison/comparison_busco/${dir_OG}; fi; done

for aln in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_miniprot_to_remove.txt); do dir=$(sed 's/macse_final_mask_align_NT_pruned_complet.aln/phylter/' <<< ${aln}); rm -r $Path_working_directory/comparison/comparison_miniprot/${dir_OG}; fi; done

for aln in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_scipio_to_remove.txt); do dir=$(sed 's/macse_final_mask_align_NT_pruned_complet.aln/phylter/' <<< ${aln}); rm -r $Path_working_directory/comparison/comparison_scipio/${dir_OG}; fi; done

# Listing of OGs (for Busco, then Miniprot and Scipio)
$Path_working_directory/scripts/GenesBuscoMiniprotScipio.py $Path_working_directory/comparison/comparison_busco > $Path_working_directory/comparison/common_OG_lists/list_aln_busco_filtered.txt

$Path_working_directory/scripts/GenesBuscoMiniprotScipio.py $Path_working_directory/comparison/comparison_miniprot > $Path_working_directory/comparison/common_OG_lists/list_aln_miniprot_filtered.txt

$Path_working_directory/scripts/GenesBuscoMiniprotScipio.py $Path_working_directory/comparison/comparison_scipio > $Path_working_directory/comparison/common_OG_lists/list_aln_scipio_filtered.txt

# Listing of unique OGs
$Path_working_directory/scripts/GenesBuscoMiniprotScipioUnique.py Busco $Path_working_directory/comparison/comparison_busco $Path_working_directory/comparison/comparison_miniprot $Path_working_directory/comparison/comparison_scipio > $Path_working_directory/comparison/common_OG_lists/list_aln_busco_uniq_filtered.txt

$Path_working_directory/scripts/GenesBuscoMiniprotScipioUnique.py Miniprot $Path_working_directory/comparison/comparison_busco $Path_working_directory/comparison/comparison_miniprot $Path_working_directory/comparison/comparison_scipio > $Path_working_directory/comparison/common_OG_lists/list_aln_miniprot_uniq_filtered.txt

$Path_working_directory/scripts/GenesBuscoMiniprotScipioUnique.py Scipio $Path_working_directory/comparison/comparison_busco $Path_working_directory/comparison/comparison_miniprot $Path_working_directory/comparison/comparison_scipio > $Path_working_directory/comparison/common_OG_lists/list_aln_scipio_uniq_filtered.txt

# Creation of a CSV file of OGs common to all three sets
$Path_working_directory/scripts/GenesBuscoMiniprotScipioCommonFor3.py $Path_working_directory/comparison/comparison_busco/ $Path_working_directory/comparison/comparison_miniprot/ $Path_working_directory/comparison/comparison_scipio/ > $Path_working_directory/comparison/common_OG_lists/list_aln_BMS_new_names.csv

# Creation of text files containing the list of common alignments per set
cut -d';' -f2 $Path_working_directory/comparison/common_OG_lists/list_aln_BMS_new_names.csv > $Path_working_directory/comparison/common_OG_lists/list_aln_busco_BMS_to_keep.txt
cut -d';' -f3 $Path_working_directory/comparison/common_OG_lists/list_aln_BMS_new_names.csv > $Path_working_directory/comparison/common_OG_lists/list_aln_miniprot_BMS_to_keep.txt
cut -d';' -f4 $Path_working_directory/comparison/common_OG_lists/list_aln_BMS_new_names.csv > $Path_working_directory/comparison/common_OG_lists/list_aln_scipio_BMS_to_keep.txt

# Remove the first header line from ‘to_keep’ files
sed -i '1d' $Path_working_directory/comparison/common_OG_lists/list_aln_busco_BMS_to_keep.txt
sed -i '1d' $Path_working_directory/comparison/common_OG_lists/list_aln_miniprot_BMS_to_keep.txt
sed -i '1d' $Path_working_directory/comparison/common_OG_lists/list_aln_scipio_BMS_to_keep.txt

# Creation of a CSV file of common OGs between two sets
$Path_working_directory/scripts/GenesBuscoMiniprotScipioCommonFor2.py Busco_Miniprot $Path_working_directory/comparison/comparison_busco/ $Path_working_directory/comparison/comparison_miniprot/ > $Path_working_directory/comparison/common_OG_lists/list_aln_BM_new_names.csv

$Path_working_directory/scripts/GenesBuscoMiniprotScipioCommonFor2.py Busco_Scipio $Path_working_directory/comparison/comparison_busco/ $Path_working_directory/comparison/comparison_scipio/ > $Path_working_directory/comparison/common_OG_lists/list_aln_BS_new_names.csv

$Path_working_directory/scripts/GenesBuscoMiniprotScipioCommonFor2.py Miniprot_Scipio $Path_working_directory/comparison/comparison_miniprot/ $Path_working_directory/comparison/comparison_scipio/ > $Path_working_directory/comparison/common_OG_lists/list_aln_MS_new_names.csv

# Creation of the CommonToTwo file to search for common OGs with a different gene
grep '^CommonToTwo' $Path_working_directory/comparison/common_OG_lists/list_aln_BM_new_names.csv > $Path_working_directory/comparison/common_OG_lists/list_aln_BM_CommonToTwo_new_names.csv
grep '^CommonToTwo' $Path_working_directory/comparison/common_OG_lists/list_aln_BS_new_names.csv > $Path_working_directory/comparison/common_OG_lists/list_aln_BS_CommonToTwo_new_names.csv
grep '^CommonToTwo' $Path_working_directory/comparison/common_OG_lists/list_aln_MS_new_names.csv > $Path_working_directory/comparison/common_OG_lists/list_aln_MS_CommonToTwo_new_names.csv

# Search for common OGs with a different gene by comparison with two different OGs.
$Path_working_directory/scripts/GenesBuscoMiniprotScipioCommonFor2Dif.sh BM Busco Miniprot > $Path_working_directory/comparison/common_OG_lists/list_aln_BM_comparison.csv 
grep 'dif' $Path_working_directory/comparison/common_OG_lists/list_aln_BM_comparison.csv | sort -u > $Path_working_directory/comparison/common_OG_lists/list_aln_BM_comparison_dif.csv

$Path_working_directory/scripts/GenesBuscoMiniprotScipioCommonFor2Dif.sh BS Busco Scipio > $Path_working_directory/comparison/common_OG_lists/list_aln_BS_comparison.csv
grep 'dif' $Path_working_directory/comparison/common_OG_lists/list_aln_BS_comparison.csv | sort -u > $Path_working_directory/comparison/common_OG_lists/list_aln_BS_comparison_dif.csv

$Path_working_directory/scripts/GenesBuscoMiniprotScipioCommonFor2Dif.sh MS Miniprot Scipio > $Path_working_directory/comparison/common_OG_lists/list_aln_MS_comparison.csv
grep 'dif' $Path_working_directory/comparison/common_OG_lists/list_aln_MS_comparison.csv | sort -u > $Path_working_directory/comparison/common_OG_lists/list_aln_MS_comparison_dif.csv

# Search for common OGs with a different gene by comparison with three
$Path_working_directory/scripts/GenesBuscoMiniprotScipioCommonFor3Dif.sh BMS Busco Miniprot Scipio > $Path_working_directory/comparison/common_OG_lists/list_aln_BMS_comparison.csv 
grep 'dif' $Path_working_directory/comparison/common_OG_lists/list_aln_BMS_comparison.csv | sort -u > $Path_working_directory/comparison/common_OG_lists/list_aln_BMS_comparison_dif.csv

# Removal of common OGs with a different gene
cut -d';' -f1 $Path_working_directory/comparison/common_OG_lists/list_aln_BM_comparison_dif.csv > $Path_working_directory/comparison/common_OG_lists/list_aln_busco_comparison_diff_to_remove.txt
cut -d';' -f1 $Path_working_directory/comparison/common_OG_lists/list_aln_BS_comparison_dif.csv >> $Path_working_directory/comparison/common_OG_lists/list_aln_busco_comparison_diff_to_remove.txt
cut -d';' -f1 $Path_working_directory/comparison/common_OG_lists/list_aln_BMS_comparison_dif.csv >> $Path_working_directory/comparison/common_OG_lists/list_aln_busco_comparison_diff_to_remove.txt
sort -u $Path_working_directory/comparison/common_OG_lists/list_aln_busco_comparison_diff_to_remove.txt > $Path_working_directory/comparison/common_OG_lists/temp.txt && mv $Path_working_directory/comparison/common_OG_lists/temp.txt $Path_working_directory/comparison/common_OG_lists/list_aln_busco_comparison_diff_to_remove.txt

cut -d';' -f2 $Path_working_directory/comparison/common_OG_lists/list_aln_BM_comparison_dif.csv > $Path_working_directory/comparison/common_OG_lists/list_aln_miniprot_comparison_diff_to_remove.txt
cut -d';' -f1 $Path_working_directory/comparison/common_OG_lists/list_aln_MS_comparison_dif.csv >> $Path_working_directory/comparison/common_OG_lists/list_aln_miniprot_comparison_diff_to_remove.txt
cut -d';' -f2 $Path_working_directory/comparison/common_OG_lists/list_aln_BMS_comparison_dif.csv >> $Path_working_directory/comparison/common_OG_lists/list_aln_miniprot_comparison_diff_to_remove.txt
sort -u $Path_working_directory/comparison/common_OG_lists/list_aln_miniprot_comparison_diff_to_remove.txt > $Path_working_directory/comparison/common_OG_lists/temp.txt && mv $Path_working_directory/comparison/common_OG_lists/temp.txt $Path_working_directory/comparison/common_OG_lists/list_aln_miniprot_comparison_diff_to_remove.txt

cut -d';' -f2 $Path_working_directory/comparison/common_OG_lists/list_aln_BS_comparison_dif.csv > $Path_working_directory/comparison/common_OG_lists/list_aln_scipio_comparison_diff_to_remove.txt
cut -d';' -f2 $Path_working_directory/comparison/common_OG_lists/list_aln_MS_comparison_dif.csv >> $Path_working_directory/comparison/common_OG_lists/list_aln_scipio_comparison_diff_to_remove.txt
cut -d';' -f3 $Path_working_directory/comparison/common_OG_lists/list_aln_BMS_comparison_dif.csv >> $Path_working_directory/comparison/common_OG_lists/list_aln_scipio_comparison_diff_to_remove.txt
sort -u $Path_working_directory/comparison/common_OG_lists/list_aln_scipio_comparison_diff_to_remove.txt > $Path_working_directory/comparison/common_OG_lists/temp.txt && mv $Path_working_directory/comparison/common_OG_lists/temp.txt $Path_working_directory/comparison/common_OG_lists/list_aln_scipio_comparison_diff_to_remove.txt

for OG in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_busco_comparison_diff_to_remove.txt); do rm -r $Path_working_directory/comparison/comparison_busco/${OG}_phylter; fi; done

for OG in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_miniprot_comparison_diff_to_remove.txt); do rm -r $Path_working_directory/comparison/comparison_miniprot/${OG}_phylter; fi; done

for OG in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_scipio_comparison_diff_to_remove.txt); do rm -r $Path_working_directory/comparison/comparison_scipio/${OG}_phylter; fi; done

# Repeat searches for unique and common OGs
$Path_working_directory/scripts/GenesBuscoMiniprotScipio.py $Path_working_directory/comparison/comparison_busco > $Path_working_directory/comparison/common_OG_lists/list_aln_busco_filtered_2.txt

$Path_working_directory/scripts/GenesBuscoMiniprotScipioUnique.py Busco $Path_working_directory/comparison/comparison_busco/ $Path_working_directory/comparison/comparison_miniprot/ $Path_working_directory/comparison/comparison_scipio/ > $Path_working_directory/comparison/common_OG_lists/list_aln_busco_uniq_filtered_2.txt

$Path_working_directory/scripts/GenesBuscoMiniprotScipio.py $Path_working_directory/comparison/comparison_miniprot > $Path_working_directory/comparison/common_OG_lists/list_aln_miniprot_filtered_2.txt

$Path_working_directory/scripts/GenesBuscoMiniprotScipioUnique.py Miniprot $Path_working_directory/comparison/comparison_busco/ $Path_working_directory/comparison/comparison_miniprot/ $Path_working_directory/comparison/comparison_scipio/ > $Path_working_directory/comparison/common_OG_lists/list_aln_miniprot_uniq_filtered_2.txt

$Path_working_directory/scripts/GenesBuscoMiniprotScipio.py $Path_working_directory/comparison/comparison_scipio > $Path_working_directory/comparison/common_OG_lists/list_aln_scipio_filtered_2.txt

$Path_working_directory/scripts/GenesBuscoMiniprotScipioUnique.py Scipio $Path_working_directory/comparison/comparison_busco/ $Path_working_directory/comparison/comparison_miniprot/ $Path_working_directory/comparison/comparison_scipio/ > $Path_working_directory/comparison/common_OG_lists/list_aln_scipio_uniq_filtered_2.txt

$Path_working_directory/scripts/GenesBuscoMiniprotScipioCommonFor3.py $Path_working_directory/comparison/comparison_busco/ $Path_working_directory/comparison/comparison_miniprot/ $Path_working_directory/comparison/comparison_scipio/ > $Path_working_directory/comparison/common_OG_lists/list_aln_BMS_new_names_2.csv

cut -d';' -f2 $Path_working_directory/comparison/common_OG_lists/list_aln_BMS_new_names_2.csv > $Path_working_directory/comparison/common_OG_lists/list_aln_busco_BMS_to_keep_2.txt
cut -d';' -f3 $Path_working_directory/comparison/common_OG_lists/list_aln_BMS_new_names_2.csv > $Path_working_directory/comparison/common_OG_lists/list_aln_miniprot_BMS_to_keep_2.txt
cut -d';' -f4 $Path_working_directory/comparison/common_OG_lists/list_aln_BMS_new_names_2.csv > $Path_working_directory/comparison/common_OG_lists/list_aln_scipio_BMS_to_keep_2.txt

sed -i '1d' $Path_working_directory/comparison/common_OG_lists/list_aln_busco_BMS_to_keep_2.txt
sed -i '1d' $Path_working_directory/comparison/common_OG_lists/list_aln_miniprot_BMS_to_keep_2.txt
sed -i '1d' $Path_working_directory/comparison/common_OG_lists/list_aln_scipio_BMS_to_keep_2.txt

$Path_working_directory/scripts/GenesBuscoMiniprotScipioCommonFor2_2.py Busco_Miniprot $Path_working_directory/comparison/comparison_busco/ $Path_working_directory/comparison/comparison_miniprot/ > $Path_working_directory/comparison/common_OG_lists/list_aln_BM_new_names_2.csv

$Path_working_directory/scripts/GenesBuscoMiniprotScipioCommonFor2_2.py Busco_Scipio $Path_working_directory/comparison/comparison_busco/ $Path_working_directory/comparison/comparison_scipio/ > $Path_working_directory/comparison/common_OG_lists/list_aln_BS_new_names_2.csv

$Path_working_directory/scripts/GenesBuscoMiniprotScipioCommonFor2_2.py Miniprot_Scipio $Path_working_directory/comparison/comparison_miniprot/ $Path_working_directory/comparison/comparison_scipio/ > $Path_working_directory/comparison/common_OG_lists/list_aln_MS_new_names_2.csv

# Search for OGs present in the two duos but absent in the trio for Miniprot and Scipio
comm -12 <(grep 'CommonToTwo' $Path_working_directory/comparison/common_OG_lists/list_aln_BM_new_names_2.csv | cut -d';' -f3 | sort -u) <(grep 'CommonToTwo' $Path_working_directory/comparison/common_OG_lists/list_aln_MS_new_names_2.csv | cut -d';' -f2 | sort -u) > $Path_working_directory/comparison/common_OG_lists/list_aln_BM_MS_to_BMS.txt


comm -12 <(grep 'CommonToTwo' $Path_working_directory/comparison/common_OG_lists/list_aln_BS_new_names_2.csv | cut -d';' -f3 | sort -u) <(grep 'CommonToTwo' $Path_working_directory/comparison/common_OG_lists/list_aln_MS_new_names_2.csv | cut -d';' -f3 | sort -u) > $Path_working_directory/comparison/common_OG_lists/list_aln_BS_MS_to_BMS.txt

# Copy files to modify them without the risk of losing the originals
cp $Path_working_directory/comparison/common_OG_lists/list_aln_BMS_new_names_2.csv $Path_working_directory/comparison/common_OG_lists/list_aln_BMS_new_names_2_complet.csv
cp $Path_working_directory/comparison/common_OG_lists/list_aln_BM_new_names_2.csv $Path_working_directory/comparison/common_OG_lists/list_aln_BM_new_names_2_complet.csv
cp $Path_working_directory/comparison/common_OG_lists/list_aln_BS_new_names_2.csv $Path_working_directory/comparison/common_OG_lists/list_aln_BS_new_names_2_complet.csv
cp $Path_working_directory/comparison/common_OG_lists/list_aln_MS_new_names_2.csv $Path_working_directory/comparison/common_OG_lists/list_aln_MS_new_names_2_complet.csv

# Addition in BMS of the two duets Miniprot and Scipio which were absent in trio and removal from BM, BS and MS of the Mniprot and Scipio duo which were absent in trio
for aln_M in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_BM_MS_to_BMS.txt); do 
    # Recovery of the Busco alignment name associated with that of Miniprot
    aln_B=$(grep "${aln_M}$" $Path_working_directory/comparison/common_OG_lists/list_aln_BM_new_names_2.csv | cut -d';' -f2); 
    # Recovery of the Scipio alignment name associated with that of Miniprot
    aln_S=$(grep "CommonToTwo;${aln_M}" $Path_working_directory/comparison/common_OG_lists/list_aln_MS_new_names_2.csv | cut -d';' -f3); 
    # Addition of the three alignment names in BMS file
    echo "Rename_OG;$aln_B;$aln_M;$aln_S" >> $Path_working_directory/comparison/common_OG_lists/list_aln_BMS_new_names_2_complet.csv;
    # Deletion of the line in BM file
    sed -i "/^CommonToTwo;$aln_B;$aln_M/d" $Path_working_directory/comparison/common_OG_lists/list_aln_BM_new_names_2_complet.csv;
    # Deletion of the line in MS file
    sed -i "/^CommonToTwo;$aln_M;$aln_S/d" $Path_working_directory/comparison/common_OG_lists/list_aln_MS_new_names_2_complet.csv; 
done

for aln_S in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_BS_MS_to_BMS.txt); do 
    # Recovery of the Busco alignment name associated with that of Scipio
    aln_B=$(grep "${aln_M}$" $Path_working_directory/comparison/common_OG_lists/list_aln_BS_new_names_2.csv | cut -d';' -f2);
    # Recovery of the Miniprot alignment name associated with that of Scipio
    aln_M=$(grep "${aln_M}$" $Path_working_directory/comparison/common_OG_lists/list_aln_MS_new_names_2.csv | cut -d';' -f2);
    # Addition of the three alignment names in BMS file
    echo "Rename_OG;$aln_B;$aln_M;$aln_S" >> $Path_working_directory/comparison/common_OG_lists/list_aln_BMS_new_names_2_complet.csv;
    # Deletion of the line in BS file
    sed -i "/^CommonToTwo;$aln_B;$aln_S/d" $Path_working_directory/comparison/common_OG_lists/list_aln_BS_new_names_2_complet.csv;
    # Deletion of the line in MS file
    sed -i "/^CommonToTwo;$aln_M;$aln_S/d" $Path_working_directory/comparison/common_OG_lists/list_aln_MS_new_names_2_complet.csv; 
done

# Associate a common name for the common OGs Busco, Miniprot and Scipio
compteur=0; for line in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_BMS_new_names_2_complet.csv); do new_OG="OGBMS$(printf '%05d' "$compteur")"; sed "s/Rename_OG/${new_OG}/" <<< ${line} >> $Path_working_directory/comparison/common_OG_lists/list_aln_BMS_new_names_2_complet_rename.csv; ((compteur++)); done

# Recovery of CommonToTow in a file for renaming (I've forgotten the purpose of this intermediary)
grep 'CommonToTwo' $Path_working_directory/comparison/common_OG_lists/list_aln_BM_new_names_2_complet.csv > $Path_working_directory/comparison/common_OG_lists/list_aln_BM_CommonToTwo_new_names_2_complet.csv
grep 'CommonToTwo' $Path_working_directory/comparison/common_OG_lists/list_aln_BS_new_names_2_complet.csv > $Path_working_directory/comparison/common_OG_lists/list_aln_BS_CommonToTwo_new_names_2_complet.csv
grep 'CommonToTwo' $Path_working_directory/comparison/common_OG_lists/list_aln_MS_new_names_2_complet.csv > $Path_working_directory/comparison/common_OG_lists/list_aln_MS_CommonToTwo_new_names_2_complet.csv

# Associate a common name for common OGs per pair
echo 'OG_Common;OG_Busco;OG_Miniprot' > $Path_working_directory/comparison/common_OG_lists/list_aln_BM_CommonToTwo_new_names_2_complet_rename.csv; compteur=1; for line in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_BM_CommonToTwo_new_names_2_complet.csv); do new_OG="OGBMX$(printf '%05d' "$compteur")"; sed "s/CommonToTwo/${new_OG}/" <<< ${line} >> $Path_working_directory/comparison/common_OG_lists/list_aln_BM_CommonToTwo_new_names_2_complet_rename.csv; ((compteur++)); done

echo 'OG_Common;OG_Busco;OG_Scipio' > $Path_working_directory/comparison/common_OG_lists/list_aln_BS_CommonToTwo_new_names_2_complet_rename.csv; compteur=1; for line in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_BS_CommonToTwo_new_names_2_complet.csv); do new_OG="OGBXS$(printf '%05d' "$compteur")"; sed "s/CommonToTwo/${new_OG}/" <<< ${line} >> $Path_working_directory/comparison/common_OG_lists/list_aln_BS_CommonToTwo_new_names_2_complet_rename.csv; ((compteur++)); done

echo 'OG_Common;OG_Miniprot;OG_Scipio' > $Path_working_directory/comparison/common_OG_lists/list_aln_MS_CommonToTwo_new_names_2_complet_rename.csv; compteur=1; for line in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_MS_CommonToTwo_new_names_2_complet.csv); do new_OG="OGXMS$(printf '%05d' "$compteur")"; sed "s/CommonToTwo/${new_OG}/" <<< ${line} >> $Path_working_directory/comparison/common_OG_lists/list_aln_MS_CommonToTwo_new_names_2_complet_rename.csv; ((compteur++)); done

# Associate a name for the unique OGs Busco, Miniprot and Scipio
echo 'OG_New;OG_Busco' > $Path_working_directory/comparison/common_OG_lists/list_aln_busco_uniq_filtered_2_rename.csv; compteur=1; for line in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_busco_uniq_filtered_2.txt); do new_OG="OGBXX$(printf '%05d' "$compteur")"; sed "s/^/${new_OG};/" <<< ${line} >> $Path_working_directory/comparison/common_OG_lists/list_aln_busco_uniq_filtered_2_rename.csv; ((compteur++)); done

echo 'OG_New;OG_Miniprot' > $Path_working_directory/comparison/common_OG_lists/list_aln_miniprot_uniq_filtered_2_rename.csv; compteur=1; for line in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_miniprot_uniq_filtered_2.txt); do new_OG="OGXMX$(printf '%05d' "$compteur")"; sed "s/^/${new_OG};/" <<< ${line} >> $Path_working_directory/comparison/common_OG_lists/list_aln_miniprot_uniq_filtered_2_rename.csv; ((compteur++)); done

echo 'OG_New;OG_Scipio' > $Path_working_directory/comparison/common_OG_lists/list_aln_scipio_uniq_filtered_2_rename.csv; compteur=1; for line in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_scipio_uniq_filtered_2.txt); do new_OG="OGXXS$(printf '%05d' "$compteur")"; sed "s/^/${new_OG};/" <<< ${line} >> $Path_working_directory/comparison/common_OG_lists/list_aln_scipio_uniq_filtered_2_rename.csv; ((compteur++)); done
