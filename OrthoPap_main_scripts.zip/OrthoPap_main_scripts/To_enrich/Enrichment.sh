#!/bin/sh

# Command to use:
#Profiling.sh [Path_working_directory] [CPU]

### Enrichment step

# Definition of the access path to the working directory:
Path_working_directory=$1

# Definition of the number of CPUs:
CPU=$2

### I) Installation step

# Definition of the access path to the assembly directory:
Path_to_assembly_folder=$3

# Definition of the access path to the query directory:
Path_to_query_folder=$4

# Creation of initial directories:
mkdir $Path_working_directory/enrichment
mkdir $Path_working_directory/enrichment/assemblies
mkdir $Path_working_directory/enrichment/annotation
mkdir $Path_working_directory/enrichment/annotation/queries

# Recovery of assemblies
cp $Path_to_assembly_folder/* $Path_working_directory/enrichment/assemblies/

# Recovery and renaming of queries
query_names=(query_one query_two query_thr); counter=0; for query_path in $(ls $Path_to_query_folder/*.faa); do query=$(basename "$query_path"); species="$query%.*"; sed "s/>/>Query_${species}_/" $Path_to_query_folder/$query > $Path_working_directory/enrichment/annotation/queries/${query_names[$counter]}.faa; ((counter++)); done

query_names=(query_one query_two query_thr); counter=0; for query_path in $(ls $Path_to_query_folder/*.fna); do query=$(basename "$query_path"); species="$query%.*"; sed "s/>/>Query_${species}_/" $Path_to_query_folder/$query > $Path_working_directory/enrichment/annotation/queries/${query_names[$counter]}.fna; ((counter++)); done


### II) Annotation step (BUSCO)

# odb library
odb=$5

# Creation of directories for BUSCO annotation:
mkdir $Path_working_directory/enrichment/annotation/busco
mkdir $Path_working_directory/enrichment/annotation/busco/busco_outputs
mkdir $Path_working_directory/enrichment/annotation/busco/busco_genomes

# bbmap path
#export PATH=$PATH:/bin/bbmap/ (run if busco error message about bbmap)

# Execution of the annotation
counter=1; for assembly in $(ls $Path_working_directory/enrichment/assemblies/); do species="$assembly%.*"; echo "START: ${species}"; echo "Species n°$counter"; busco -i $Path_working_directory/enrichment/assemblies/${assembly} --out_path $Path_working_directory/enrichment/annotation/busco/busco_outputs/ -o busco_${species} -l $odb -m genome -c $CPU; ((counter++)); done

# Creation of a csv file summarising busco results for all species
echo "Species;Number_of_complete_and_single_copy_BUSCOs_(S);Percentage_of_complete_and_single_copy_BUSCOs_(S)" > $Path_working_directory/enrichment/annotation/busco/busco_results_summary.csv; for dir in $(ls $Path_working_directory/enrichment/annotation/busco/busco_outputs/); do if [ ! -d "$dir" ]; then echo "$dir is not a directory"; elif [ "$dir" == "busco_downloads" ]; then echo "$dir is equal to 'busco_downloads'"; else num_S=$(grep "Complete and single-copy BUSCOs (S)" $Path_working_directory/enrichment/annotation/busco/busco_outputs/$dir/short_summary*.txt | sed 's/^[[:space:]]*\([0-9]\+\).*$/\1/'); percent_S=$(grep -E 'C:[0-9]+(\.[0-9]+)?%\[S:[0-9]+(\.[0-9]+)?%,D:[0-9]+(\.[0-9]+)?%\],F:[0-9]+(\.[0-9]+)?%,M:[0-9]+(\.[0-9]+)?%,n:[0-9]+' $Path_working_directory/enrichment/annotation/busco/busco_outputs/$dir/short_summary*.txt | sed 's/.*S:\([0-9.]\+\)%,.*/\1/'); echo "$dir;$num_S;$percent_S" >> $Path_working_directory/enrichment/annotation/busco/busco_results_summary.csv; fi; done

# Concatenation of single copy genes to obtain a protein set for each species
for assembly in $(ls $Path_working_directory/enrichment/assemblies/) ; do species="$assembly%.*"; for faa in $Path_working_directory/enrichment/annotation/busco/busco_outputs/busco_${species}/run_${odb}/busco_sequences/single_copy_busco_sequences/*.faa; do gene=$(basename $faa .faa); sed "s/>/>Busco_${species}_${gene}_/" $faa >> $Path_working_directory/enrichment/annotation/busco/busco_genomes/${species}.faa; done; done

for assembly in $(ls $Path_working_directory/enrichment/assemblies/) ; do species="$assembly%.*"; for fna in $Path_working_directory/enrichment/annotation/busco/busco_outputs/busco_${species}/run_${odb}/busco_sequences/single_copy_busco_sequences/*.fna; do gene=$(basename $fna .fna); sed "s/>/>Busco_${species}_${gene}_/" $fna >> $Path_working_directory/enrichment/annotation/busco/busco_genomes/${species}.fna; done; done

### III) Annotation step (Miniprot)

# Creation of directories for Miniprot annotation:
mkdir $Path_working_directory/annotation/miniprot
mkdir $Path_working_directory/annotation/miniprot/miniprot_mpi
mkdir $Path_working_directory/annotation/miniprot/miniprot_query_one
mkdir $Path_working_directory/annotation/miniprot/miniprot_query_two
mkdir $Path_working_directory/annotation/miniprot/miniprot_query_thr
mkdir $Path_working_directory/annotation/miniprot/miniprot_query_cat
mkdir $Path_working_directory/annotation/miniprot/miniprot_genomes

# Annotation with the first query:
counter=1; for assembly in $(ls $Path_working_directory/assemblies/); do species="$assembly%.*"; echo "START: ${species}"; echo "Species n°$counter"; miniprot -t$CPU -d $Path_working_directory/annotation/miniprot/miniprot_mpi/genome_${species}.mpi $Path_working_directory/assemblies/${assembly}; miniprot -Iut$CPU --gff $Path_working_directory/annotation/miniprot/miniprot_mpi/genome_${species}.mpi $Path_working_directory/annotation/queries/query_one.fasta > $Path_working_directory/annotation/miniprot/miniprot_query_one/miniprot_${species}.gff; ((counter++)); done

# Annotation with the second query:
counter=1; for assembly in $(ls $Path_working_directory/assemblies/); do species="$assembly%.*"; echo "START: ${species}"; echo "Species n°$counter"; miniprot -Iut$CPU --gff $Path_working_directory/annotation/miniprot/miniprot_mpi/genome_${species}.mpi $Path_working_directory/annotation/queries/query_two.fasta > $Path_working_directory/annotation/miniprot/miniprot_query_two/miniprot_${species}.gff; ((counter++)); done

# Annotation with the thrid query:
counter=1; for assembly in $(ls $Path_working_directory/assemblies/); do species="$assembly%.*"; echo "START: ${species}"; echo "Species n°$counter"; miniprot -Iut$CPU --gff $Path_working_directory/annotation/miniprot/miniprot_mpi/genome_${species}.mpi $Path_working_directory/annotation/queries/query_thr.fasta > $Path_working_directory/annotation/miniprot/miniprot_query_thr/miniprot_${species}.gff; ((counter++)); done

# Concatenation of three different queries

# Species used to query for Miniprot:
sp1=one
sp2=two
sp3=thr

# reuniting gff output files and transforming into fasta files:
for assembly in $(ls $Path_working_directory/assemblies/); do 
    # keep the species name
    sp="$assembly%.*";
    # create a directory for each species
    mkdir $Path_working_directory/annotation/miniprot/miniprot_query_cat/gfftofasta_${sp};
    # move into the species directory
    cd $Path_working_directory/annotation/miniprot/miniprot_query_cat/gfftofasta_${sp};
    
    echo "SUMMARY FILE: concatenation of Miniprot outputs" >> concatenation_${sp}.out;
    echo "SPECIES: $sp" >> concatenation_${sp}.out;
    echo "INFO: gfftogff_${sp} directory has been created" >> concatenation_${sp}.out;
    
    # copy gff files
    cp $Path_working_directory/annotation/miniprot/miniprot_query_${sp1}/miniprot_${sp}.gff $Path_working_directory/annotation/miniprot/miniprot_query_cat/gfftofasta_${sp}/miniprot_${sp}_${sp1}.gff;
    cp $Path_working_directory/annotation/miniprot/miniprot_query_${sp2}/miniprot_${sp}.gff $Path_working_directory/annotation/miniprot/miniprot_query_cat/gfftofasta_${sp}/miniprot_${sp}_${sp2}.gff;
    cp $Path_working_directory/annotation/miniprot/miniprot_query_${sp3}/miniprot_${sp}.gff $Path_working_directory/annotation/miniprot/miniprot_query_cat/gfftofasta_${sp}/miniprot_${sp}_${sp3}.gff;
    echo "INFO: GFF files from references $sp1, $sp2 and $sp3 have been copied" >> concatenation_${sp}.out;
    
    # extract CDS and rename gene
    grep -P "\tCDS\t" miniprot_${sp}_${sp1}.gff | sed "s/;Rank/_${sp1};Rank/" | bedtools sort > ${sp}_${sp1}_CDS.gff;
    grep -P "\tCDS\t" miniprot_${sp}_${sp2}.gff | sed "s/;Rank/_${sp2};Rank/" | bedtools sort > ${sp}_${sp2}_CDS.gff;
    grep -P "\tCDS\t" miniprot_${sp}_${sp3}.gff | sed "s/;Rank/_${sp3};Rank/" | bedtools sort > ${sp}_${sp3}_CDS.gff;
    
    # remove CDS include in an other CDS
    bedtools window -a ${sp}_${sp1}_CDS.gff -b ${sp}_${sp1}_CDS.gff -w 0 > tmp;
    $Path_working_directory/scripts/listAlternativeTranscript2.py tmp > tmp2;
    $Path_working_directory/scripts/ExcludeCDSFromGFF.py ${sp}_${sp1}_CDS.gff ./tmp2 > ${sp}_${sp1}_CDS_clean.gff;
    
    # remove CDS include in an other CDS
    bedtools window -a ${sp}_${sp2}_CDS.gff -b ${sp}_${sp2}_CDS.gff -w 0 > tmp;
    $Path_working_directory/scripts/listAlternativeTranscript2.py tmp > tmp2;
    $Path_working_directory/scripts/ExcludeCDSFromGFF.py ${sp}_${sp2}_CDS.gff ./tmp2 > ${sp}_${sp2}_CDS_clean.gff;
    
    # remove CDS include in an other CDS
    bedtools window -a ${sp}_${sp3}_CDS.gff -b ${sp}_${sp3}_CDS.gff -w 0 > tmp;
    $Path_working_directory/scripts/listAlternativeTranscript2.py tmp > tmp2;
    $Path_working_directory/scripts/ExcludeCDSFromGFF.py ${sp}_${sp3}_CDS.gff ./tmp2 > ${sp}_${sp3}_CDS_clean.gff;
    
    # concatenation of the gff files for each query
    cat ${sp}_${sp1}_CDS_clean.gff ${sp}_${sp2}_CDS_clean.gff ${sp}_${sp3}_CDS_clean.gff | bedtools sort > ${sp}_${sp1}${sp2}${sp3}_CDS.gff;
    
    # remove CDS include in an other CDS
    bedtools window -a ${sp}_${sp1}${sp2}${sp3}_CDS.gff -b ${sp}_${sp1}${sp2}${sp3}_CDS.gff -w 0 > tmp;
    $Path_working_directory/scripts/listAlternativeTranscript2.py tmp > tmp2
    $Path_working_directory/scripts/ExcludeCDSFromGFF.py ${sp}_${sp1}${sp2}${sp3}_CDS.gff ./tmp2 > ${sp}_${sp1}${sp2}${sp3}_CDS_clean.gff;
    
    # information retrieval
    nb_CDS=$(cut -f9 ${sp}_${sp1}${sp2}${sp3}_CDS.gff | cut -d";" -f1 | sort -u | wc -l);
    echo "INFO: The GFF file contains $nb_CDS cds" >> concatenation_${sp}.out;
    
    nb_CDS_clean=$(cut -f9 ${sp}_${sp1}${sp2}${sp3}_CDS_clean.gff | cut -d";" -f1 | sort -u | wc -l);
    echo "INFO: The cleaned GFF file contains $nb_CDS_clean cds" >> concatenation_${sp}.out;
    
    # puts the gene's name in column 3 of the GFF
    $Path_working_directory/scripts/putIDinNameGFF.py -f ${sp}_${sp1}${sp2}${sp3}_CDS_clean.gff > ${sp}_exon.gff;

    # converts GFF to exons
    bedtools getfasta -s -name -fi $Path_working_directory/assemblies/$assembly -bed ${sp}_exon.gff > ${sp}_exons.fasta;
    
    cut -d"_" -f1,2 ${sp}_exons.fasta > tmp && mv tmp ${sp}_exons.fasta;

    # concatenates exons to transcripts
    $Path_working_directory/scripts/concateExonFromBedtoolsGetFasta2_forCat.py ${sp}_exons.fasta > ${sp}_Transcript.fasta;
    
    # sort the gff
    bedtools sort -i ${sp}_exon.gff > ${sp}_exon_sort.gff;

    # retrieve list of gene without overlapping exons
    $Path_working_directory/scripts/SelectOverlappingExonGFFsort_forCat.py ${sp}_exon_sort.gff > ${sp}_gene2keep.txt;
    
    # retrieve sequences according to the list of genes to keep
    $Path_working_directory/scripts/SelectSeq.py -l ${sp}_gene2keep.txt -f ${sp}_Transcript.fasta -c partial -o ${sp}_Transcript_uniq.fasta;
    
    # conversion of nucleotide sequences into protein
    transeq -sequence ${sp}_Transcript_uniq.fasta -outseq ${sp}_Transcript_uniq.faa;
    
    # Add '_1' at the end of the unique fna file
    sed -i '/^>/s/$/_1/' ${sp}_Transcript_uniq.fasta
    
    # information retrieval
    nb_Transcript_uniq=$(grep -c "^>" ${sp}_Transcript_uniq.faa);
    echo "INFO: The FASTA file contains $nb_Transcript_uniq transcripts" >> concatenation_${sp}.out;
    
    # sort faa sequence names
    grep '^>' ${sp}_Transcript_uniq.faa | sed 's/>//'| sort > List_Transcript_uniq_sort.txt;
    
    # specify redundant sequence names in the list while preserving the origin of the query
    $Path_working_directory/scripts/RenameTranscriptRedundants_forList.py List_Transcript_uniq_sort.txt List_Transcript_uniq_rename.txt;
    
    # specify redundant sequence names in the faa while preserving the origin of the query    
    $Path_working_directory/scripts/RenameTranscriptRedundants_forFasta.py ${sp}_Transcript_uniq.faa ${sp}_Transcript_uniq_rename.faa;
    
    # specify redundant sequence names in the fna while preserving the origin of the query
    $Path_working_directory/scripts/RenameTranscriptRedundants_forFasta.py ${sp}_Transcript_uniq.fasta ${sp}_Transcript_uniq_rename.fna;
    
    # retrieve faa sequences according to the list of genes to keep
    $Path_working_directory/scripts/SelectSeq.py -f ${sp}_Transcript_uniq_rename.faa -l List_Transcript_uniq_rename.txt -c partial -o ${sp}_Transcript_uniq_seqperline.faa;
    
    grep -A1 -E '>[M][P][0-9]{6}_[A-Za-z]{4}_1' ${sp}_Transcript_uniq_seqperline.faa > ${sp}_Transcript_uniq_final.faa;
    
    # information retrieval
    nb_Transcript_uniq_final_faa=$(grep -c "^>" ${sp}_Transcript_uniq_final.faa);
    echo "INFO: The final FASTA (faa) file contains $nb_Transcript_uniq_final_faa unique transcripts" >> concatenation_${sp}.out;
    
    # retrieve fna sequences according to the list of genes to keep
    $Path_working_directory/scripts/SelectSeq.py -f ${sp}_Transcript_uniq_rename.fna -l List_Transcript_uniq_rename.txt -c partial -o ${sp}_Transcript_uniq_seqperline.fna;
    
    grep -A1 -E '>[M][P][0-9]{6}_[A-Za-z]{4}_1' ${sp}_Transcript_uniq_seqperline.fna > ${sp}_Transcript_uniq_final.fna;
    
    # information retrieval
    nb_Transcript_uniq_final_fna=$(grep -c "^>" ${sp}_Transcript_uniq_final.fna);
    echo "INFO: The final FASTA (fna) file contains $nb_Transcript_uniq_final_fna unique transcripts" >> concatenation_${sp}.out;
    
    # renames sequences
    sed -i "s/>/>Miniprot_${sp}_/" ${sp}_Transcript_uniq_final.faa;
    sed -i "s/>/>Miniprot_${sp}_/" ${sp}_Transcript_uniq_final.fna;
    
    #copy fasta files (fna and faa) to an upstream folder in the path
    cp ${sp}_Transcript_uniq_final.faa $Path_working_directory/annotation/miniprot/miniprot_genomes/${sp}.faa;
    cp ${sp}_Transcript_uniq_final.fna $Path_working_directory/annotation/miniprot/miniprot_genomes/${sp}.fna;
        
done

### IV) Annotation step (Scipio)

# Creation of directories for Scipio annotation:
mkdir $Path_working_directory/annotation/scipio
mkdir $Path_working_directory/annotation/scipio/scipio_query_one
mkdir $Path_working_directory/annotation/scipio/scipio_query_two
mkdir $Path_working_directory/annotation/scipio/scipio_query_thr
mkdir $Path_working_directory/annotation/scipio/scipio_query_cat
mkdir $Path_working_directory/annotation/scipio/scipio_genomes

# Creation of the scipio annotation script for parallelized running:
for assembly in $(ls $Path_working_directory/assemblies/); do species="$assembly%.*"; echo "echo \"START: ${species}\" ; scipio.1.4.1.pl $Path_working_directory/assemblies/$assembly $Path_working_directory/annotation/queries/query_one.fasta > $Path_working_directory/annotation/scipio/scipio_query_one/scipio_${species}.yaml ; scipio.1.4.1.pl $Path_working_directory/assemblies/$assembly $Path_working_directory/annotation/queries/query_two.fasta > $Path_working_directory/annotation/scipio/scipio_query_two/scipio_${species}.yaml ; scipio.1.4.1.pl $Path_working_directory/assemblies/$assembly $Path_working_directory/annotation/queries/query_thr.fasta > $Path_working_directory/annotation/scipio/scipio_query_thr/scipio_${species}.yaml"; done >> $Path_working_directory/annotation/scipio/script_scipio.sh

# Execution of the scipio annotation script:
cat $Path_working_directory/annotation/scipio/script_scipio.sh | parallel --jobs=$CPU

# YAML to GFF

for yaml in $Path_working_directory/annotation/scipio/scipio_query_one/*.yaml; do echo "yaml2gff.1.4.pl $yaml > ${yaml%.yaml}.gff" >> $Path_working_directory/annotation/scipio/script_yamltogff.sh; done

for yaml in $Path_working_directory/annotation/scipio/scipio_query_two/*.yaml; do echo "yaml2gff.1.4.pl $yaml > ${yaml%.yaml}.gff" >> $Path_working_directory/annotation/scipio/script_yamltogff.sh; done

for yaml in $Path_working_directory/annotation/scipio/scipio_query_thr/*.yaml; do echo "yaml2gff.1.4.pl $yaml > ${yaml%.yaml}.gff" >> $Path_working_directory/annotation/scipio/script_yamltogff.sh; done

cat $Path_working_directory/annotation/scipio/script_yamltogff.sh | parallel --jobs=$CPU

# Concatenation of three different queries

# species used to query for Scipio
sp1=one
sp2=two
sp3=thr

# reuniting gff output files and transforming into fasta files:
for assembly in $(ls $Path_working_directory/assemblies/); do
    # keep the species name
    sp="$assembly%.*";
    # create a directory for each species
    mkdir $Path_working_directory/annotation/scipio/scipio_query_cat/gfftofasta_${sp};
    # move into the species directory
    cd $Path_working_directory/annotation/scipio/scipio_query_cat/gfftofasta_${sp};
    
    echo "SUMMARY FILE: concatenation of Scipio outputs" >> concatenation_${sp}.out;
    echo "SPECIES: $sp" >> concatenation_${sp}.out;
    echo "INFO: gfftogff_${sp} directory has been created" >> concatenation_${sp}.out;
    
    # copy gff files
    cp $Path_working_directory/annotation/scipio/scipio_query_${sp1}/scipio_${sp}.gff $Path_working_directory/annotation/scipio/scipio_query_cat/gfftofasta_${sp}/scipio_${sp}_${sp1}.gff;
    cp $Path_working_directory/annotation/scipio/scipio_query_${sp2}/scipio_${sp}.gff $Path_working_directory/annotation/scipio/scipio_query_cat/gfftofasta_${sp}/scipio_${sp}_${sp2}.gff;
    cp $Path_working_directory/annotation/scipio/scipio_query_${sp3}/scipio_${sp}.gff $Path_working_directory/annotation/scipio/scipio_query_cat/gfftofasta_${sp}/scipio_${sp}_${sp3}.gff;
    echo "INFO: GFF files from references $sp1, $sp2 and $sp3 have been copied" >> concatenation_${sp}.out;
    
    # extract CDS and rename gene
    grep protein_match scipio_${sp}_${sp1}.gff | sed -E "s/ID=([0-9]+);Query/Parent=SC\1_${sp1};Query/" | awk '{split($0, a, "\t"); if (a[4] <= a[5]) print}' | bedtools sort > ${sp}_${sp1}_CDS.gff;
    grep protein_match scipio_${sp}_${sp2}.gff | sed -E "s/ID=([0-9]+);Query/Parent=SC\1_${sp2};Query/" | awk '{split($0, a, "\t"); if (a[4] <= a[5]) print}' | bedtools sort > ${sp}_${sp2}_CDS.gff;
    grep protein_match scipio_${sp}_${sp3}.gff | sed -E "s/ID=([0-9]+);Query/Parent=SC\1_${sp3};Query/" | awk '{split($0, a, "\t"); if (a[4] <= a[5]) print}' | bedtools sort > ${sp}_${sp3}_CDS.gff;
    
    # remove CDS include in an other CDS    
    bedtools window -a ${sp}_${sp1}_CDS.gff -b ${sp}_${sp1}_CDS.gff -w 0 > tmp;
    $Path_working_directory/scripts/listAlternativeTranscript2.py tmp > tmp2;
    $Path_working_directory/scripts/ExcludeCDSFromGFF.py ${sp}_${sp1}_CDS.gff ./tmp2 > ${sp}_${sp1}_CDS_clean.gff;
    
    # remove CDS include in an other CDS
    bedtools window -a ${sp}_${sp2}_CDS.gff -b ${sp}_${sp2}_CDS.gff -w 0 > tmp;
    $Path_working_directory/scripts/listAlternativeTranscript2.py tmp > tmp2;
    $Path_working_directory/scripts/ExcludeCDSFromGFF.py ${sp}_${sp2}_CDS.gff ./tmp2 > ${sp}_${sp2}_CDS_clean.gff;
    
    # remove CDS include in an other CDS
    bedtools window -a ${sp}_${sp3}_CDS.gff -b ${sp}_${sp3}_CDS.gff -w 0 > tmp;
    $Path_working_directory/scripts/listAlternativeTranscript2.py tmp > tmp2;
    $Path_working_directory/scripts/ExcludeCDSFromGFF.py ${sp}_${sp3}_CDS.gff ./tmp2 > ${sp}_${sp3}_CDS_clean.gff;
    
    # concatenation of the gff files for each query
    cat ${sp}_${sp1}_CDS_clean.gff ${sp}_${sp2}_CDS_clean.gff ${sp}_${sp3}_CDS_clean.gff | bedtools sort > ${sp}_${sp1}${sp2}${sp3}_CDS.gff;
    
    # remove CDS include in an other CDS
    bedtools window -a ${sp}_${sp1}${sp2}${sp3}_CDS.gff -b ${sp}_${sp1}${sp2}${sp3}_CDS.gff -w 0 > tmp;
    $Path_working_directory/scripts/listAlternativeTranscript2.py tmp > tmp2
    $Path_working_directory/scripts/ExcludeCDSFromGFF.py ${sp}_${sp1}${sp2}${sp3}_CDS.gff ./tmp2 > ${sp}_${sp1}${sp2}${sp3}_CDS_clean.gff;
    
    # information retrieval
    nb_CDS=$(cut -f9 ${sp}_${sp1}${sp2}${sp3}_CDS.gff | cut -d";" -f1 | sort -u | wc -l);
    echo "INFO: The GFF file contains $nb_CDS cds" >> concatenation_${sp}.out;
    
    nb_CDS_clean=$(cut -f9 ${sp}_${sp1}${sp2}${sp3}_CDS_clean.gff | cut -d";" -f1 | sort -u | wc -l);
    echo "INFO: The cleaned GFF file contains $nb_CDS_clean cds" >> concatenation_${sp}.out;
    
    # puts the gene's name in column 3 of the GFF
    $Path_working_directory/scripts/putIDinNameGFF.py -f ${sp}_${sp1}${sp2}${sp3}_CDS_clean.gff > ${sp}_exon.gff;

    # converts GFF to exons
    bedtools getfasta -s -name -fi $Path_working_directory/assemblies/${assembly} -bed ${sp}_exon.gff -fo ${sp}_exons.fasta;
    
    cut -d"_" -f1,2 ${sp}_exons.fasta > tmp && mv tmp ${sp}_exons.fasta;

    # concatenates exons to transcripts
    $Path_working_directory/scripts/concateExonFromBedtoolsGetFasta2_forCat.py ${sp}_exons.fasta > ${sp}_Transcript.fasta;
    
    # sort the gff
    bedtools sort -i ${sp}_exon.gff > ${sp}_exon_sort.gff;

    # retrieve list of gene without overlapping exons
    $Path_working_directory/scripts/SelectOverlappingExonGFFsort_forCat.py ${sp}_exon_sort.gff > ${sp}_gene2keep.txt;

    # retrieve sequences according to the list of genes to keep
    $Path_working_directory/scripts/SelectSeq.py -l ${sp}_gene2keep.txt -f ${sp}_Transcript.fasta -c partial -o ${sp}_Transcript_uniq.fasta;
    
    # conversion of nucleotide sequences into protein
    transeq -sequence ${sp}_Transcript_uniq.fasta -outseq ${sp}_Transcript_uniq.faa;
    
    # Add '_1' at the end of the unique fna file
    sed -i '/^>/s/$/_1/' ${sp}_Transcript_uniq.fasta
    
    # information retrieval
    nb_Transcript_uniq=$(grep -c "^>" ${sp}_Transcript_uniq.faa);
    echo "INFO: The FASTA file contains $nb_Transcript_uniq transcripts" >> concatenation_${sp}.out;
    
    # sort faa sequence names
    grep '^>' ${sp}_Transcript_uniq.faa | sed 's/>//'| sort > List_Transcript_uniq_sort.txt;
    
    # specify redundant sequence names in the list while preserving the origin of the query
    $Path_working_directory/scripts/RenameTranscriptRedundants_forList.py List_Transcript_uniq_sort.txt List_Transcript_uniq_rename.txt;
    
    # specify redundant sequence names in the faa while preserving the origin of the query
    $Path_working_directory/scripts/RenameTranscriptRedundants_forFasta.py ${sp}_Transcript_uniq.faa ${sp}_Transcript_uniq_rename.faa;
    
    # specify redundant sequence names in the fna while preserving the origin of the query
    $Path_working_directory/scripts/RenameTranscriptRedundants_forFasta.py ${sp}_Transcript_uniq.fasta ${sp}_Transcript_uniq_rename.fna;
    
    # retrieve faa sequences according to the list of genes to keep
    $Path_working_directory/scripts/SelectSeq.py -f ${sp}_Transcript_uniq_rename.faa -l List_Transcript_uniq_rename.txt -c partial -o ${sp}_Transcript_uniq_seqperline.faa;
    
    grep -A1 -E '>[S][C][0-9]{1,}_[A-Za-z]{4}_1' ${sp}_Transcript_uniq_seqperline.faa > ${sp}_Transcript_uniq_final.faa;
    
    # information retrieval
    nb_Transcript_uniq_final=$(grep -c "^>" ${sp}_Transcript_uniq_final.faa);
    echo "INFO: The final FASTA file contains $nb_Transcript_uniq_final unique transcripts" >> concatenation_${sp}.out;
    
    # retrieve fna sequences according to the list of genes to keep
    $Path_working_directory/scripts/SelectSeq.py -f ${sp}_Transcript_uniq_rename.fna -l List_Transcript_uniq_rename.txt -c partial -o ${sp}_Transcript_uniq_seqperline.fna;
    
    grep -A1 -E '>[M][P][0-9]{6}_[A-Za-z]{4}_1' ${sp}_Transcript_uniq_seqperline.fna > ${sp}_Transcript_uniq_final.fna;
    
    # information retrieval
    nb_Transcript_uniq_final_fna=$(grep -c "^>" ${sp}_Transcript_uniq_final.fna);
    echo "INFO: The final FASTA (fna) file contains $nb_Transcript_uniq_final_fna unique transcripts" >> concatenation_${sp}.out;
    
    # renames sequences
    sed -i "s/>/>Scipio_${sp}_/" ${sp}_Transcript_uniq_final.faa;
    sed -i "s/>/>Miniprot_${sp}_/" ${sp}_Transcript_uniq_final.fna;
    
    #copy fasta files (fna and faa) to an upstream folder in the path
    cp ${sp}_Transcript_uniq_final.faa $Path_working_directory/annotation/scipio/scipio_genomes/${sp}.faa;
    cp ${sp}_Transcript_uniq_final.fna $Path_working_directory/annotation/scipio/scipio_genomes/${sp}.fna;
    
done

### V) Profiling step (continuity of HMMER)

# 2) Search for profiles against sequences

# Creation of directories for further profiling
mkdir $Path_working_directory/profiling/new_species_profiles_busco
mkdir $Path_working_directory/profiling/new_species_profiles_miniprot
mkdir $Path_working_directory/profiling/new_species_profiles_scipio

# Creation of species list
ls $Path_working_directory/enrichment/assemblies/ > $Path_working_directory/enrichment/list_species_to_enrich.txt
sed -i 's/\.[^.]*$//' $Path_working_directory/enrichment/list_species_to_enrich.txt

# BUSCO

# Creating sub-folders
for sp in $(cat $Path_working_directory/enrichment/list_species_to_enrich.txt); do mkdir $Path_working_directory/profiling/new_species_profiles_busco/${sp}_HMM; mkdir $Path_working_directory/profiling/new_species_profiles_busco/${sp}_HMM/search_out; done

# Importing .faa BUSCO files for new species
for sp in $(cat $Path_working_directory/enrichment/list_species_to_enrich.txt); do cp $Path_working_directory/enrichment/annotation/annotation_busco/busco_genomes/${sp}.faa $Path_working_directory/profiling/new_species_profiles_busco/${sp}_HMM/Busco_${sp}.faa; done

# Searching for profiles against sequences
for sp_HMM in $(ls $Path_working_directory/profiling/new_species_profiles_busco/); do for profil in $(ls $Path_working_directory/profiling/orthologue_alignments_profiles/ | grep '.hmm'); do echo "hmmsearch --noali --notextw --tblout $Path_working_directory/profiling/new_species_profiles_busco/${sp_HMM}/search_out/${profil%.hmm}_out.txt $Path_working_directory/profiling/orthologue_alignments_profiles/${profil} $Path_working_directory/profiling/new_species_profiles_busco/${sp_HMM}/Busco_${sp_HMM%_HMM}.faa" >> $Path_working_directory/profiling/new_species_profiles_busco/${sp_HMM}/hmmsearch_cmmd.bash; done; done

for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_busco/*; do cat ${path_sp_HMM}/hmmsearch_cmmd.bash | parallel --jobs=$CPU; done

# Miniprot

# Creating sub-folders
for sp in $(cat $Path_working_directory/enrichment/list_species_to_enrich.txt); do mkdir $Path_working_directory/profiling/new_species_profiles_miniprot/${sp}_HMM; mkdir $Path_working_directory/profiling/new_species_profiles_miniprot/${sp}_HMM/search_out; done

# Importing .faa Miniprot files for new species
for sp in $(cat $Path_working_directory/enrichment/list_species_to_enrich.txt); do cp $Path_working_directory/enrichment/annotation/annotation_miniprot/miniprot_genomes/${sp}.faa $Path_working_directory/profiling/new_species_profiles_miniprot/${sp}_HMM/Miniprot_${sp}.faa; done

# Checking for the undesirable presence of ‘-’ in the sequences of the .faa file for each species
# Check that all the ‘-’s are at the end of the sequence
# Total number of ‘-’s
for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_miniprot/*; do grep -v '>' ${path_sp_HMM}/Miniprot_*.faa | grep -- '-'; done | wc -l
# Total number of ‘-’ at the end of the sequence
for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_miniprot/*; do grep -v '>' ${path_sp_HMM}/Miniprot_*.faa | grep -- '-$'; done | wc -l

# Removing the ‘-’ in the sequences in the .faa file for each species
for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_miniprot/*; do sed -i 's/-//g' $path_sp_HMM/*.faa; done

# Search for profiles against sequences
for sp_HMM in $(ls $Path_working_directory/profiling/new_species_profiles_miniprot/); do for profil in $(ls $Path_working_directory/profiling/orthologue_alignments_profiles/ | grep '.hmm'); do echo "hmmsearch --noali --notextw --tblout $Path_working_directory/profiling/new_species_profiles_miniprot/${sp_HMM}/search_out/${profil%.hmm}_out.txt $Path_working_directory/profiling/orthologue_alignments_profiles/${profil} $Path_working_directory/profiling/new_species_profiles_miniprot/${sp_HMM}/Miniprot_${sp_HMM%_HMM}.faa" >> $Path_working_directory/profiling/new_species_profiles_miniprot/${sp_HMM}/hmmsearch_cmmd.bash; done; done

for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_miniprot/*; do cat ${path_sp_HMM}/hmmsearch_cmmd.bash | parallel --jobs=$CPU; done

# Scipio

# Creating sub-folders
for sp in $(cat $Path_working_directory/enrichment/list_species_to_enrich.txt); do mkdir $Path_working_directory/profiling/new_species_profiles_scipio/${sp}_HMM; mkdir $Path_working_directory/profiling/new_species_profiles_scipio/${sp}_HMM/search_out; done

# Importing .faa Scipio files for new species
for sp in $(cat $Path_working_directory/enrichment/list_species_to_enrich.txt); do cp $Path_working_directory/enrichment/annotation/annotation_scipio/scipio_genomes/${sp}.faa $Path_working_directory/profiling/new_species_profiles_scipio/${sp}_HMM/Scipio_${sp}.faa; done

# Checking for the undesirable presence of ‘-’ in the sequences of the .faa file for each species
# Check that all the ‘-’s are at the end of the sequence
# Total number of ‘-’s
for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_scipio/*; do grep -v '>' ${path_sp_HMM}/Scipio_*.faa | grep -- '-'; done | wc -l
# Total number of ‘-’ at the end of the sequence
for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_scipio/*; do grep -v '>' ${path_sp_HMM}/Scipio_*.faa | grep -- '-$'; done | wc -l

# Removing the ‘-’ in the sequences in the .faa file for each species
for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_scipio/*; do sed -i 's/-//g' $path_sp_HMM/*.faa; done

# Search for profiles against sequences
for sp_HMM in $(ls $Path_working_directory/profiling/new_species_profiles_scipio/); do for profil in $(ls $Path_working_directory/profiling/orthologue_alignments_profiles/ | grep '.hmm'); do echo "hmmsearch --noali --notextw --tblout $Path_working_directory/profiling/new_species_profiles_scipio/${sp_HMM}/search_out/${profil%.hmm}_out.txt $Path_working_directory/profiling/orthologue_alignments_profiles/${profil} $Path_working_directory/profiling/new_species_profiles_scipio/${sp_HMM}/Scipio_${sp_HMM%_HMM}.faa" >> $Path_working_directory/profiling/new_species_profiles_scipio/${sp_HMM}/hmmsearch_cmmd.bash; done; done

for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_scipio/*; do cat ${path_sp_HMM}/hmmsearch_cmmd.bash | parallel --jobs=$CPU; done

# 3) search for sequences against profiles

# BUSCO

# Creating sub-folders
for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_busco/*; do mkdir ${path_sp_HMM}/scan_out; mkdir ${path_sp_HMM}/genes; done

# Importing .faa BUSCO files for new species (here one gene per file)
for sp in $(cat $Path_working_directory/enrichment/list_species_to_enrich.txt); do cd $Path_working_directory/enrichment/annotation/annotation_busco/busco_outputs/busco_${sp}/run_lepidoptera_odb10/busco_sequences/single_copy_busco_sequences/; for faa in *.faa; do sed "s/>/>Busco_${sp}_/" $faa > $Path_working_directory/profiling/new_species_profiles_busco/${sp}_HMM/genes/Busco_${sp}_${faa}; done; done

# Rename BUSCO .faa files by gene name
for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_busco/*; do for gene in $(ls $path_sp_HMM/genes/); do new_name=$(cat $path_sp_HMM/genes/$gene | grep '>' | sed 's/>//'); mv $path_sp_HMM/genes/$gene $path_sp_HMM/genes/${new_name}.faa; done; done

# If not renamed before running hmmscan
for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_busco/*; do for gene in $(ls $path_sp_HMM/genes/); do new_name=$(cat $path_sp_HMM/genes/$gene | grep '>' | sed 's/>//'); mv $path_sp_HMM/genes/$gene $path_sp_HMM/genes/${new_name}.faa; mv $path_sp_HMM/scan_out/${gene%.faa}.txt $path_sp_HMM/scan_out/${new_name}.txt;  mv $path_sp_HMM/scan_out/${gene%.faa}_res.txt $path_sp_HMM/scan_out/${new_name}_res.txt; done; done
#Error message : 
#mv: target ‘description>.faa’ is not a directory
#mv: target ‘description>.txt’ is not a directory
#mv: target ‘description>_res.txt’ is not a directory
# Then run hmmscan again

# Scan the hmm database for a sequence
for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_busco/*; do for gene in $(ls $path_sp_HMM/genes/); do echo "hmmscan  --noali --notextw --tblout ${path_sp_HMM}/scan_out/${gene%.faa}.txt $Path_working_directory/profiling/orthologue_alignments.hmm ${path_sp_HMM}/genes/${gene}" >> ${path_sp_HMM}/hmmscan_cmmd.bash; done; done

for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_busco/*; do cat ${path_sp_HMM}/hmmscan_cmmd.bash | parallel --jobs=$CPU; done

# Miniprot

# Creating sub-folders
for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_miniprot/*; do mkdir ${path_sp_HMM}/scan_out; mkdir ${path_sp_HMM}/genes; done

# Importing .faa Miniprot files for new species (here one gene per file)
for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_miniprot/*; do for gene in $(cat $path_sp_HMM/*.faa | grep '>' | sed 's/>//'); do grep -A1 "$gene" $path_sp_HMM/*.faa > $path_sp_HMM/genes/$gene.faa; done; done

# Scan the hmm database for a sequence
for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_miniprot/*; do for gene in $(ls $path_sp_HMM/genes/); do echo "hmmscan  --noali --notextw --tblout ${path_sp_HMM}/scan_out/${gene%.faa}.txt $Path_working_directory/profiling/orthologue_alignments.hmm ${path_sp_HMM}/genes/${gene}" >> ${path_sp_HMM}/hmmscan_cmmd.bash; done; done

for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_miniprot/*; do cat ${path_sp_HMM}/hmmscan_cmmd.bash | parallel --jobs=$CPU; done

# Scipio

# Creating sub-folders
for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_scipio/*; do mkdir ${path_sp_HMM}/scan_out; mkdir ${path_sp_HMM}/genes; done

# Importing .faa Scipio files for new species (here one gene per file)
for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_scipio/*; do for gene in $(cat $path_sp_HMM/*.faa | grep '>' | sed 's/>//'); do grep -A1 "$gene" $path_sp_HMM/*.faa > $path_sp_HMM/genes/$gene.faa; done; done

# Scan the hmm database for a sequence
for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_scipio/*; do for gene in $(ls $path_sp_HMM/genes/); do echo "hmmscan  --noali --notextw --tblout ${path_sp_HMM}/scan_out/${gene%.faa}.txt $Path_working_directory/profiling/orthologue_alignments.hmm ${path_sp_HMM}/genes/${gene}" >> ${path_sp_HMM}/hmmscan_cmmd.bash; done; done

for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_scipio/*; do cat ${path_sp_HMM}/hmmscan_cmmd.bash | parallel --jobs=$CPU; done

# 4) The results are processed to check that the results of steps 2) & 3) are consistent

# BUSCO

# Search_out
for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_busco/*; do for sear in $(ls $path_sp_HMM/search_out/); do $Path_working_directory/profiling/Hmmout2Table.py $path_sp_HMM/search_out/${sear} > $path_sp_HMM/search_out/${sear%_out.txt}_res.txt; done; done

# Scan_out
for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_busco/*; do for scan in $(ls $path_sp_HMM/scan_out/); do $Path_working_directory/profiling/Hmmout2Table.py $path_sp_HMM/scan_out/${scan} > $path_sp_HMM/scan_out/${scan%.txt}_res.txt; done; done

# Miniprot

# Search_out
for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_miniprot/*; do for sear in $(ls $path_sp_HMM/search_out/); do echo "$Path_working_directory/profiling/Hmmout2Table.py $path_sp_HMM/search_out/${sear} > $path_sp_HMM/search_out/${sear%_out.txt}_res.txt" >> ${path_sp_HMM}/hmmout_search.bash; done; done

for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_miniprot/*; do cat ${path_sp_HMM}/hmmout_search.bash | parallel --jobs=$CPU; done

# Scan_out
for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_miniprot/*; do for scan in $(ls $path_sp_HMM/scan_out/); do echo "$Path_working_directory/profiling/Hmmout2Table.py $path_sp_HMM/scan_out/${scan} > $path_sp_HMM/scan_out/${scan%.txt}_res.txt" >> ${path_sp_HMM}/hmmout_scan.bash; done; done

for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_miniprot/*; do cat ${path_sp_HMM}/hmmout_scan.bash | parallel --jobs=$CPU; done

# Scipio

# Search_out
for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_scipio/*; do for sear in $(ls $path_sp_HMM/search_out/); do echo "$Path_working_directory/profiling/Hmmout2Table.py $path_sp_HMM/search_out/${sear} > $path_sp_HMM/search_out/${sear%_out.txt}_res.txt" >> ${path_sp_HMM}/hmmout_search.bash; done; done

for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_scipio/*; do cat ${path_sp_HMM}/hmmout_search.bash | parallel --jobs=$CPU; done

# Scan_out
for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_scipio/*; do for scan in $(ls $path_sp_HMM/scan_out/); do echo "$Path_working_directory/profiling/Hmmout2Table.py $path_sp_HMM/scan_out/${scan} > $path_sp_HMM/scan_out/${scan%.txt}_res.txt" >> ${path_sp_HMM}/hmmout_scan.bash; done; done

for path_sp_HMM in $Path_working_directory/profiling/new_species_profiles_scipio/*; do cat ${path_sp_HMM}/hmmout_scan.bash | parallel --jobs=$CPU; done

# R script for sorting results
# best_reciprocal_hmm.R

# Busco

for sp_HMM in $(ls $Path_working_directory/profiling/new_species_profiles_busco/); do cp $Path_working_directory/profiling/best_reciprocal_hmm.R $Path_working_directory/profiling/new_species_profiles_busco/$sp_HMM/best_reciprocal_hmm_${sp_HMM%_HMM}.R; sed -i 's/ANNOTATOR/Busco/g' $Path_working_directory/profiling/new_species_profiles_busco/$sp_HMM/best_reciprocal_hmm_${sp_HMM%_HMM}.R; sed -i "s/SPECIES/${sp_HMM%_HMM}/g" $Path_working_directory/profiling/new_species_profiles_busco/$sp_HMM/best_reciprocal_hmm_${sp_HMM%_HMM}.R; done

for sp_HMM in $(ls $Path_working_directory/profiling/new_species_profiles_busco/); do echo "Rscript $Path_working_directory/profiling/new_species_profiles_busco/$sp_HMM/best_reciprocal_hmm_${sp_HMM%_HMM}.R" >> $Path_working_directory/profiling/best_reciprocal_hmm_busco.bash; done

cat $Path_working_directory/profiling/best_reciprocal_hmm_busco.bash | parallel --jobs=$CPU

# Check that there are no duplicates
for sp_HMM in $(ls $Path_working_directory/profiling/new_species_profiles_busco/); do cut -d, -f2 $Path_working_directory/profiling/new_species_profiles_busco/$sp_HMM/orthogroups_${sp_HMM%_HMM}.csv | sort | uniq -d; done

# Gather csv files for all species
Rscript $Path_working_directory/profiling/best_reciprocal_hmm_busco_reunification.R

# Miniprot

for sp_HMM in $(ls $Path_working_directory/profiling/new_species_profiles_miniprot/); do cp $Path_working_directory/profiling/best_reciprocal_hmm.R $Path_working_directory/profiling/new_species_profiles_miniprot/$sp_HMM/best_reciprocal_hmm_${sp_HMM%_HMM}.R; sed -i 's/ANNOTATOR/Miniprot/g' $Path_working_directory/profiling/new_species_profiles_miniprot/$sp_HMM/best_reciprocal_hmm_${sp_HMM%_HMM}.R; sed -i "s/SPECIES/${sp_HMM%_HMM}/g" $Path_working_directory/profiling/new_species_profiles_miniprot/$sp_HMM/best_reciprocal_hmm_${sp_HMM%_HMM}.R; done

for sp_HMM in $(ls $Path_working_directory/profiling/new_species_profiles_miniprot/); do echo "Rscript $Path_working_directory/profiling/new_species_profiles_miniprot/$sp_HMM/best_reciprocal_hmm_${sp_HMM%_HMM}.R" >> $Path_working_directory/profiling/best_reciprocal_hmm_miniprot.bash; done

cat $Path_working_directory/profiling/best_reciprocal_hmm_miniprot.bash | parallel --jobs=$CPU

# Check that there are no duplicates
for sp_HMM in $(ls $Path_working_directory/profiling/new_species_profiles_miniprot/); do cut -d, -f2 $Path_working_directory/profiling/new_species_profiles_miniprot/$sp_HMM/orthogroups_${sp_HMM%_HMM}.csv | sort | uniq -d; done

# Gather csv files for all species
Rscript $Path_working_directory/profiling/best_reciprocal_hmm_miniprot_reunification.R

# Scipio

for sp_HMM in $(ls $Path_working_directory/profiling/new_species_profiles_scipio/); do cp $Path_working_directory/profiling/best_reciprocal_hmm.R $Path_working_directory/profiling/new_species_profiles_scipio/$sp_HMM/best_reciprocal_hmm_${sp_HMM%_HMM}.R; sed -i 's/ANNOTATOR/Scipio/g' $Path_working_directory/profiling/new_species_profiles_scipio/$sp_HMM/best_reciprocal_hmm_${sp_HMM%_HMM}.R; sed -i "s/SPECIES/${sp_HMM%_HMM}/g" $Path_working_directory/profiling/new_species_profiles_scipio/$sp_HMM/best_reciprocal_hmm_${sp_HMM%_HMM}.R; done

for sp_HMM in $(ls $Path_working_directory/profiling/new_species_profiles_scipio/); do echo "Rscript $Path_working_directory/profiling/new_species_profiles_scipio/$sp_HMM/best_reciprocal_hmm_${sp_HMM%_HMM}.R" >> $Path_working_directory/profiling/best_reciprocal_hmm_scipio.bash; done

cat $Path_working_directory/profiling/best_reciprocal_hmm_scipio.bash | parallel --jobs=$CPU

# Check that there are no duplicates
for sp_HMM in $(ls $Path_working_directory/profiling/new_species_profiles_scipio/); do cut -d, -f2 $Path_working_directory/profiling/new_species_profiles_scipio/$sp_HMM/orthogroups_${sp_HMM%_HMM}.csv | sort | uniq -d; done

# Gather csv files for all species
Rscript $Path_working_directory/profiling/best_reciprocal_hmm_scipio_reunification.R

### VI) EnrichAlignment

mkdir $Path_working_directory/enrichment/alignment/enrich_alignments
mkdir $Path_working_directory/enrichment/alignment/enrich_alignments

# Importing alignments in nucleotide form
for line in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_BMS_new_names_2_complet_rename.csv); do new_OG=$(cut -d';' -f1 <<< $line); old_OG=$(cut -d';' -f2 <<< $line | sed 's/_macse_final_mask_align_NT_pruned_complet.aln//'); cp $Path_working_directory/alignment/align_busco/alignment_macse_busco/${old_OG}_macse/${old_OG}_macse_final_unmask_align_NT.aln $Path_working_directory/enrichment/alignment/enrich_alignments/${new_OG}_macse_final_unmask_align_NT.aln; done

for line in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_BM_CommonToTwo_new_names_2_complet_rename.csv); do new_OG=$(cut -d';' -f1 <<< $line); old_OG=$(cut -d';' -f2 <<< $line | sed 's/_macse_final_mask_align_NT_pruned_complet.aln//'); cp $Path_working_directory/alignment/align_busco/alignment_macse_busco/${old_OG}_macse/${old_OG}_macse_final_unmask_align_NT.aln $Path_working_directory/enrichment/alignment/enrich_alignments/${new_OG}_macse_final_unmask_align_NT.aln; done

for line in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_BS_CommonToTwo_new_names_2_complet_rename.csv); do new_OG=$(cut -d';' -f1 <<< $line); old_OG=$(cut -d';' -f2 <<< $line | sed 's/_macse_final_mask_align_NT_pruned_complet.aln//'); cp $Path_working_directory/alignment/align_busco/alignment_macse_busco/${old_OG}_macse/${old_OG}_macse_final_unmask_align_NT.aln $Path_working_directory/enrichment/alignment/enrich_alignments/${new_OG}_macse_final_unmask_align_NT.aln; done

for line in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_MS_CommonToTwo_new_names_2_complet_rename.csv); do new_OG=$(cut -d';' -f1 <<< $line); old_OG=$(cut -d';' -f2 <<< $line | sed 's/_macse_final_mask_align_NT_pruned_complet.aln//'); cp $Path_working_directory/alignment/align_miniprot/alignment_macse_miniprot/${old_OG}_macse/${old_OG}_macse_final_unmask_align_NT.aln $Path_working_directory/enrichment/alignment/enrich_alignments/${new_OG}_macse_final_unmask_align_NT.aln; done

for line in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_busco_uniq_filtered_2_rename.csv); do new_OG=$(cut -d';' -f1 <<< $line); old_OG=$(cut -d';' -f2 <<< $line | sed 's/_macse_final_mask_align_NT_pruned_complet.aln//'); cp $Path_working_directory/alignment/align_busco/alignment_macse_busco/${old_OG}_macse/${old_OG}_macse_final_unmask_align_NT.aln $Path_working_directory/enrichment/alignment/enrich_alignments/${new_OG}_macse_final_unmask_align_NT.aln; done

for line in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_miniprot_uniq_filtered_2_rename.csv); do new_OG=$(cut -d';' -f1 <<< $line); old_OG=$(cut -d';' -f2 <<< $line | sed 's/_macse_final_mask_align_NT_pruned_complet.aln//'); cp $Path_working_directory/alignment/align_miniprot/alignment_macse_miniprot/${old_OG}_macse/${old_OG}_macse_final_unmask_align_NT.aln $Path_working_directory/enrichment/alignment/enrich_alignments/${new_OG}_macse_final_unmask_align_NT.aln; done

for line in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_scipio_uniq_filtered_2_rename.csv); do new_OG=$(cut -d';' -f1 <<< $line); old_OG=$(cut -d';' -f2 <<< $line | sed 's/_macse_final_mask_align_NT_pruned_complet.aln//'); cp $Path_working_directory/alignment/align_scipio/alignment_macse_scipio/${old_OG}_macse/${old_OG}_macse_final_unmask_align_NT.aln $Path_working_directory/enrichment/alignment/enrich_alignments/${new_OG}_macse_final_unmask_align_NT.aln; done

# Removing ‘*’ and ‘!’ from alignments
#for aln in $Path_working_directory/enrichment/alignment/enrich_alignments/*; do sed -i 's/*/-/g' $aln; sed -i 's/!/-/g' $aln; done 

# Busco

mkdir $Path_working_directory/enrichment/alignment/enrich_macse

# Creating sub-folders
for OG in $(cat $Path_working_directory/profiling/orthogroups_busco_reunified.csv | cut -d, -f1 | grep 'OG'); do mkdir $Path_working_directory/enrichment/alignment/enrich_macse/${OG}_macse; done

# Recovery of genes associated with each OG
for line in $(cat $Path_working_directory/profiling/orthogroups_busco_reunified.csv | grep 'OG'); do OG=$(cut -d, -f1 <<< $line); list=$(grep -o 'Busco[^,]*' <<< $line); for gene in $list; do sp=$(cut -d '_' -f 2-3 <<< $gene); sed -n "/$gene/{p; :a; n; /^>/q; p; ba}" $Path_working_directory/enrichment/annotation/busco/busco_genomes/${sp}.fna > $Path_working_directory/enrichment/alignment/enrich_macse/${OG}_macse/${gene}.fna; done; done

# Miniprot

# Recovery of genes associated with each OG
for line in $(cat $Path_working_directory/profiling/orthogroups_miniprot_reunified.csv | grep 'OG'); do OG=$(echo "$line" | cut -d ',' -f1); line_busco=$(grep "$OG" $Path_working_directory/profiling/orthogroups_busco_reunified.csv); if [ "$line_busco" ]; then echo "${OG}_present_in_busco_reunified.csv" >> $Path_working_directory/enrichment/alignment/summary_addition_miniprot_genes.txt; list=$(echo "$line" | grep -o 'Miniprot[^,]*'); for gene in $list; do sp=$(echo "$gene" | cut -d '_' -f 2-3); sp_busco=$(echo "$line_busco" | grep -o "$sp"); if [ "$sp_busco" ]; then continue; else grep -A1 "$gene" $Path_working_directory/enrichment/annotation/miniprot/busco_miniprot/${sp}.fna > $Path_working_directory/enrichment/alignment/enrich_macse/${OG}_macse/${gene}.fna; fi; done; else echo "${OG}_absent_in_busco_reunified.csv" >> $Path_working_directory/enrichment/alignment/summary_addition_miniprot_genes.txt; mkdir $Path_working_directory/enrichment/alignment/enrich_macse/${OG}_macse; list=$(echo "$line" | grep -o 'Miniprot[^,]*'); for gene in $list; do sp=$(echo "$gene" | cut -d '_' -f 2-3); grep -A1 "$gene" $Path_working_directory/enrichment/annotation/miniprot/busco_miniprot/${sp}.fna > $Path_working_directory/enrichment/alignment/enrich_macse/${OG}_macse/${gene}.fna; done; fi; done 

# Scipio

# Recovery of genes associated with each OG
for line in $(cat $Path_working_directory/profiling/orthogroups_scipio_reunified.csv | grep 'OG'); do OG=$(echo "$line" | cut -d ',' -f1); line_busco=$(grep "$OG" $Path_working_directory/profiling/orthogroups_busco_reunified.csv); line_miniprot=$(grep "$OG" $Path_working_directory/profiling/orthogroups_miniprot_reunified.csv); if [ "$line_busco" ] || [ "$line_miniprot" ]; then echo "${OG}_present_in_busco_or_miniprot_reunified.csv" >> $Path_working_directory/enrichment/alignment/summary_addition_scipio_genes.txt; list=$(echo "$line" | grep -o 'Scipio[^,]*'); for gene in $list; do sp=$(echo "$gene" | cut -d '_' -f 2-3); sp_busco=$(echo "$line_busco" | grep -o "$sp"); sp_miniprot=$(echo "$line_miniprot" | grep -o "$sp"); if [ "$sp_busco" ] || [ "$sp_miniprot" ]; then continue; else grep -A1 "$gene" $Path_working_directory/enrichment/annotation/scipio/scipio_genomes/${sp}.fna > $Path_working_directory/enrichment/alignment/enrich_macse/${OG}_macse/${gene}.fna; fi; done; else echo "${OG}_absent_in_busco_or_miniprot_reunified.csv" >> $Path_working_directory/enrichment/alignment/summary_addition_scipio_genes.txt; mkdir $Path_working_directory/enrichment/alignment/enrich_macse/${OG}_macse; list=$(echo "$line" | grep -o 'Scipio[^,]*'); for gene in $list; do sp=$(echo "$gene" | cut -d '_' -f 2-3); grep -A1 "$gene" $Path_working_directory/enrichment/annotation/scipio/scipio_genomes/${sp}.fna > $Path_working_directory/enrichment/alignment/enrich_macse/${OG}_macse/${gene}.fna; done; fi; done

# Copies of the alignments in their corresponding files
for OG_macse in $(ls $Path_working_directory/enrichment/alignment/enrich_macse/); do cp $Path_working_directory/enrichment/alignment/enrich_alignments/${OG_macse}_final_unmask_align_NT.aln $Path_working_directory/enrichment/alignment/enrich_macse/${OG_macse}/; done

# Building alignments
for OG_macse in $(ls $Path_working_directory/enrichment/alignment/enrich_macse/); do cat $Path_working_directory/enrichment/alignment/enrich_macse/$OG_macse/*.fna > $Path_working_directory/enrichment/alignment/enrich_macse/${OG_macse}/${OG_macse}_all_sequences.fna; done

for OG_macse in $(ls $Path_working_directory/enrichment/alignment/enrich_macse/); do echo "java -jar ~/bin/macse_v2.07.jar -prog enrichAlignment -align $Path_working_directory/enrichment/alignment/enrich_macse/$OG_macse/${OG_macse}_final_unmask_align_NT.aln -seq $Path_working_directory/enrichment/alignment/enrich_macse/$OG_macse/${OG_macse}_all_sequences.fna -maxFS_inSeq 1 -maxSTOP_inSeq 0" >> $Path_working_directory/enrichment/alignment/macse_enrichAlignment.bash; done

cat $Path_working_directory/enrichment/alignment/macse_enrichAlignment.bash | parallel --jobs=$CPU
