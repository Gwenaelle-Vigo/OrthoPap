#!/bin/sh

# Command to use:
#Alignment_Busco.sh [Path_working_directory] 

### Alignment step

# Definition of the access path to the working directory:
Path_working_directory=$1

# Definition of the number of CPUs:
CPU=$2

# Creation of directories for alignment:
mkdir -p $Path_working_directory/alignment
mkdir $Path_working_directory/alignment/align_busco
mkdir $Path_working_directory/alignment/align_busco/alignment_macse_busco
mkdir $Path_working_directory/alignment/align_busco/orthogroup_sequences_faa
mkdir $Path_working_directory/alignment/align_busco/orthogroup_sequences_fna
mkdir $Path_working_directory/alignment/align_busco/orthogroup_sequences_txt
mkdir $Path_working_directory/alignment/align_busco/sequences_fna

# Selection of the names of OGs whose genes are strictly orthologous 1:1 between at least 5 species
$Path_working_directory/script/SelectOrthogroupNamesNoParalog.py $Path_working_directory/orthology/OrthoF_busco/OrthoF_busco_results/Results_*/Orthogroups/Orthogroups.GeneCount.tsv > $Path_working_directory/alignment/align_busco/List_orthogroup_names_no_paralog.txt

# Selection of the names of OGs whose genes are strictly orthologous 1:1 between at least 5 species and which have an additional paralogue gene.
$Path_working_directory/script/SelectOrthogroupNamesOneParalog.py $Path_working_directory/orthology/OrthoF_busco/OrthoF_busco_results/Results_*/Orthogroups/Orthogroups.GeneCount.tsv > $Path_working_directory/alignment/align_busco/List_orthogroup_names_one_paralog.txt

# Verification in OGs with a paralogous gene if it is the result of a recent duplication
$Path_working_directory/script/SelectOrthogroupParalogSisters.py $Path_working_directory/alignment/align_busco/List_orthogroup_names_one_paralog.txt $Path_working_directory/orthology/OrthoF_busco/OrthoF_busco_results/Results_*/Resolved_Gene_Trees

# Selection of the names of OGs with a paralogous on the sister brother or cousin branch
$Path_working_directory/script/SelectOrthogroupNamesOneParalogSister.py $Path_working_directory/alignment/align_busco/List_orthogroup_names_one_paralog.txt $Path_working_directory/orthology/OrthoF_busco/OrthoF_busco_results/Results_*/Resolved_Gene_Trees > $Path_working_directory/alignment/align_busco/List_orthogroup_names_one_paralog_sister.txt

# Selection of names of OGs without a paralogue and those with a paralogue on a sister or cousin branch
cat $Path_working_directory/alignment/align_busco/List_orthogroup_names_no_paralog.txt $Path_working_directory/alignment/align_busco/List_orthogroup_names_one_paralog_sister.txt > $Path_working_directory/alignment/align_busco/List_orthogroup_for_alignment.txt

# Recuperation des fichiers .fa des OG a aligner
for OG in $(cat $Path_working_directory/alignment/align_busco/List_orthogroup_for_alignment.txt); do cp $Path_working_directory/orthology/OrthoF_busco/OrthoF_busco_results/Results_*/orthogroup_sequences/${OG}.fa $Path_working_directory/alignment/align_busco/orthogroup_sequences_faa/${OG}.faa; done

# Recovering nucleotide sequences
cp $Path_working_directory/annotation/busco/busco_genomes/*.fna $Path_working_directory/alignment/align_busco/sequences_fna/; done

# Creation of the ‘fasta_file.fna’ file containing the nucleotide sequences of all the species
cat $Path_working_directory/alignment/align_busco/sequences_fna/*.fna $Path_working_directory/annotation/queries/*.fna > $Path_working_directory/alignment/align_busco/fasta_file.fna

# Copy .faa files, keeping only the gene names (without the amino acid sequences)
$Path_working_directory/scripts/CopySeqFileByFile_Part1.sh $Path_working_directory/alignment/align_busco/orthogroup_sequences_faa $Path_working_directory/alignment/align_busco/orthogroup_sequences_txt

# Deletion of the species with two paralogous genes
$Path_working_directory/scripts/RemoveParalogSpecies.sh $Path_working_directory/alignment/align_busco/orthogroup_sequences_txt $Path_working_directory/alignment/align_busco/List_orthogroup_names_one_paralog_sister.txt

# Selection of OG names whose files, after deletion of paralogs, have fewer than 5 genes

nb_files=0; for fna in (ls $Path_working_directory/alignment/align_busco/orthogroup_sequences_txt/); do
  nb_gene=$(grep '^>' $Path_working_directory/alignment/align_busco/orthogroup_sequences_txt/$fna | wc -l);
  if [ "$nb_gene" -lt 5 ]; then
    echo "${fna%.txt}" >> $Path_working_directory/alignment/align_busco/List_orthogroup_names_less_five_species.txt;
    nb_files=$((nb_files + 1));
  fi;
done

# Deletion of OGs with fewer than 5 genes

for OG in $(cat $Path_working_directory/alignment/align_busco/List_orthogroup_names_less_five_species.txt); do
  rm $Path_working_directory/alignment/align_busco/orthogroup_sequences_txt/${OG}.txt;
  sed -i "/$OG/d" $Path_working_directory/alignment/align_busco/List_orthogroup_names_for_alignment.txt;
done

# Copy the .txt files, adding the corresponding nucleotide sequences to each gene name

$Path_working_directory/scripts/CopySeqFileByFile_Part2.py -i $Path_working_directory/alignment/align_busco/orthogroup_sequences_txt -o $Path_working_directory/alignment/align_busco/orthogroup_sequences_fna -f $Path_working_directory/alignment/align_busco/fasta_file.fna

### Be careful not to make the gene names too long for the alignment !

# Alignment
# Text file containing the list of orthogroup names
Orthogroup="$Path_working_directory/alignment/align_busco/List_orthogroup_names_for_alignment.txt"

# Set the directory containing the input files
input_dir="$Path_working_directory/alignment/align_busco/orthogroup_sequences_fna"

# Set the output directory
output_dir="$Path_working_directory/alignment/align_busco/alignment_macse_busco"

# Execute the aligner using singularity and output to output folder
singularity run -H $PWD ~/bin/omm_macse_v11.05b.sif --out_dir $output_dir/${Orthogroup}_macse --out_file_prefix ${Orthogroup}_macse --in_seq_file ${input_dir}/${Orthogroup}.fna --genetic_code_number 1 --alignAA_soft MAFFT  --java_mem 10000m












