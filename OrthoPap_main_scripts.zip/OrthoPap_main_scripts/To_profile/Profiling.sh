#!/bin/sh

# Command to use:
#Profiling.sh [Path_working_directory] [CPU]

### Profiling step

# Definition of the access path to the working directory:
Path_working_directory=$1

# Definition of the number of CPUs:
CPU=$2

# Creation of directories for profiling:
mkdir $Path_working_directory/profiling
mkdir $Path_working_directory/profiling/orthologue_alignments
mkdir $Path_working_directory/profiling/orthologue_alignments_profiles

# Copy the alignments chosen to create the HMM profiles and rename the files according to the names of the common OGs
for line in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_BMS_new_names_2_complet_rename.csv); do new_OG=$(cut -d';' -f1 <<< $line); old_OG=$(cut -d';' -f2 <<< $line | sed 's/_macse_final_mask_align_NT_pruned_complet.aln//'); cp $Path_working_directory/alignment/align_busco/alignement_macse_busco/${old_OG}_macse/${old_OG}_macse_final_unmask_align_AA.aln $Path_working_directory/profiling/orthologue_alignments/${new_OG}_macse_final_unmask_align_AA.aln; done

for line in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_BM_CommonToTwo_new_names_2_complet_rename.csv); do new_OG=$(cut -d';' -f1 <<< $line); old_OG=$(cut -d';' -f2 <<< $line | sed 's/_macse_final_mask_align_NT_pruned_complet.aln//'); cp $Path_working_directory/alignment/align_busco/alignement_macse_busco/${old_OG}_macse/${old_OG}_macse_final_unmask_align_AA.aln $Path_working_directory/profiling/orthologue_alignments/${new_OG}_macse_final_unmask_align_AA.aln; done

for line in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_BS_CommonToTwo_new_names_2_complet_rename.csv); do new_OG=$(cut -d';' -f1 <<< $line); old_OG=$(cut -d';' -f2 <<< $line | sed 's/_macse_final_mask_align_NT_pruned_complet.aln//'); cp $Path_working_directory/alignment/align_busco/alignement_macse_busco/${old_OG}_macse/${old_OG}_macse_final_unmask_align_AA.aln $Path_working_directory/profiling/orthologue_alignments/${new_OG}_macse_final_unmask_align_AA.aln; done

for line in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_MS_CommonToTwo_new_names_2_complet_rename.csv); do new_OG=$(cut -d';' -f1 <<< $line); old_OG=$(cut -d';' -f2 <<< $line | sed 's/_macse_final_mask_align_NT_pruned_complet.aln//'); cp $Path_working_directory/alignment/align_miniprot/alignement_macse_miniprot/${old_OG}_macse/${old_OG}_macse_final_unmask_align_AA.aln $Path_working_directory/profiling/orthologue_alignments/${new_OG}_macse_final_unmask_align_AA.aln; done

for line in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_busco_uniq_filtered_2_rename.csv); do new_OG=$(cut -d';' -f1 <<< $line); old_OG=$(cut -d';' -f2 <<< $line | sed 's/_macse_final_mask_align_NT_pruned_complet.aln//'); cp $Path_working_directory/alignment/align_busco/alignement_macse_busco/${old_OG}_macse/${old_OG}_macse_final_unmask_align_AA.aln $Path_working_directory/profiling/orthologue_alignments/${new_OG}_macse_final_unmask_align_AA.aln; done

for line in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_miniprot_uniq_filtered_2_rename.csv); do new_OG=$(cut -d';' -f1 <<< $line); old_OG=$(cut -d';' -f2 <<< $line | sed 's/_macse_final_mask_align_NT_pruned_complet.aln//'); cp $Path_working_directory/alignment/align_miniprot/alignement_macse_miniprot/${old_OG}_macse/${old_OG}_macse_final_unmask_align_AA.aln $Path_working_directory/profiling/orthologue_alignments/${new_OG}_macse_final_unmask_align_AA.aln; done

for line in $(cat $Path_working_directory/comparison/common_OG_lists/list_aln_scipio_uniq_filtered_2_rename.csv); do new_OG=$(cut -d';' -f1 <<< $line); old_OG=$(cut -d';' -f2 <<< $line | sed 's/_macse_final_mask_align_NT_pruned_complet.aln//'); cp $Path_working_directory/alignment/align_scipio/alignement_macse_scipio/${old_OG}_macse/${old_OG}_macse_final_unmask_align_AA.aln $Path_working_directory/profiling/orthologue_alignments/${new_OG}_macse_final_unmask_align_AA.aln; done

# Retrait des '*' et des '!' dans les alignements

for aln in $Path_working_directory/profiling/orthologue_alignments/*; do sed -i 's/*/-/g' $aln; sed -i 's/!/-/g' $aln; done

# HMMER
# 1) création des profils à partir des alignements

for align in $(ls $Path_working_directory/profiling/orthologue_alignments/); do OG=$(sed 's/_macse_final_unmask_align_AA.aln//' <<< $align); echo "hmmbuild -n HMM_${OG} -o $Path_working_directory/profiling/orthologue_alignments_profiles/${OG}.out --amino $Path_working_directory/profiling/orthologue_alignments_profiles/${OG}.hmm $Path_working_directory/profiling/orthologue_alignments/${align}" >> $Path_working_directory/profiling/hmmbuild.bash; done

cat $Path_working_directory/profiling/hmmbuild.bash | parallel --jobs=$CPU

cat $Path_working_directory/profiling/orthologue_alignments_profiles/*.hmm > $Path_working_directory/profiling/orthologue_alignments.hmm

hmmpress $Path_working_directory/profiling/orthologue_alignments.hmm

