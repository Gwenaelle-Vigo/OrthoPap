#!/bin/sh

# Command to use:
#Annotation_Miniprot.sh [Path_working_directory] [CPU]

### Annotation step

# Definition of the access path to the working directory:
Path_working_directory=$1

# Definition of the number of CPUs:
CPU=$2

# Creation of directories for Miniprot annotation:
mkdir $Path_working_directory/annotation/miniprot
mkdir $Path_working_directory/annotation/miniprot/miniprot_mpi
mkdir $Path_working_directory/annotation/miniprot/miniprot_query_one
mkdir $Path_working_directory/annotation/miniprot/miniprot_query_two
mkdir $Path_working_directory/annotation/miniprot/miniprot_query_thr
mkdir $Path_working_directory/annotation/miniprot/miniprot_query_cat
mkdir $Path_working_directory/annotation/miniprot/miniprot_genomes

# Annotation with the first query:
counter=1; for assembly in $(ls $Path_working_directory/assemblies/*); do species="$assembly%.*"; echo "START: ${species}"; echo "Species n°$counter"; miniprot -t$CPU -d $Path_working_directory/annotation/miniprot/miniprot_mpi/genome_${species}.mpi $Path_working_directory/assemblies/${assembly}; miniprot -Iut$CPU --gff $Path_working_directory/annotation/miniprot/miniprot_mpi/genome_${species}.mpi $Path_working_directory/annotation/queries/query_one.fasta > $Path_working_directory/annotation/miniprot/miniprot_query_one/miniprot_${species}.gff; ((counter++)); done

# Annotation with the second query:
counter=1; for assembly in $(ls $Path_working_directory/assemblies/*); do species="$assembly%.*"; echo "START: ${species}"; echo "Species n°$counter"; miniprot -Iut$CPU --gff $Path_working_directory/annotation/miniprot/miniprot_mpi/genome_${species}.mpi $Path_working_directory/annotation/queries/query_two.fasta > $Path_working_directory/annotation/miniprot/miniprot_query_two/miniprot_${species}.gff; ((counter++)); done

# Annotation with the thrid query:
counter=1; for assembly in $(ls $Path_working_directory/assemblies/*); do species="$assembly%.*"; echo "START: ${species}"; echo "Species n°$counter"; miniprot -Iut$CPU --gff $Path_working_directory/annotation/miniprot/miniprot_mpi/genome_${species}.mpi $Path_working_directory/annotation/queries/query_thr.fasta > $Path_working_directory/annotation/miniprot/miniprot_query_thr/miniprot_${species}.gff; ((counter++)); done

