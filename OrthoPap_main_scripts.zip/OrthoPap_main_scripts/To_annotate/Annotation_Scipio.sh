#!/bin/sh

# Command to use:
#Annotation_Scipio.sh [Path_working_directory] [CPU]

### Annotation step

# Definition of the access path to the working directory:
Path_working_directory=$1

# Definition of the number of CPUs:
CPU=$2

# Creation of directories for Scipio annotation:
mkdir $Path_working_directory/annotation/scipio
mkdir $Path_working_directory/annotation/scipio/scipio_query_one
mkdir $Path_working_directory/annotation/scipio/scipio_query_two
mkdir $Path_working_directory/annotation/scipio/scipio_query_thr
mkdir $Path_working_directory/annotation/scipio/scipio_query_cat
mkdir $Path_working_directory/annotation/scipio/scipio_genomes

# Creation of the scipio annotation script for parallelized running:
for assembly in $(ls $Path_working_directory/assemblies/*); do species="$assembly%.*"; echo "echo \"START: ${species}\" ; scipio.1.4.1.pl $Path_working_directory/assemblies/$assembly $Path_working_directory/annotation/queries/query_one.fasta > $Path_working_directory/annotation/scipio/scipio_query_one/scipio_${species}.yaml ; scipio.1.4.1.pl $Path_working_directory/assemblies/$assembly $Path_working_directory/annotation/queries/query_two.fasta > $Path_working_directory/annotation/scipio/scipio_query_two/scipio_${species}.yaml ; scipio.1.4.1.pl $Path_working_directory/assemblies/$assembly $Path_working_directory/annotation/queries/query_thr.fasta > $Path_working_directory/annotation/scipio/scipio_query_thr/scipio_${species}.yaml"; done >> $Path_working_directory/annotation/scipio/script_scipio.sh

# Execution of the scipio annotation script:
cat $Path_working_directory/annotation/scipio/script_scipio.sh | parallel --jobs=$CPU

# YAML to GFF

for yaml in $Path_working_directory/annotation/scipio/scipio_query_one/*.yaml; do echo "yaml2gff.1.4.pl $yaml > ${yaml%.yaml}.gff" >> $Path_working_directory/annotation/scipio/script_yamltogff.sh; done

for yaml in $Path_working_directory/annotation/scipio/scipio_query_two/*.yaml; do echo "yaml2gff.1.4.pl $yaml > ${yaml%.yaml}.gff" >> $Path_working_directory/annotation/scipio/script_yamltogff.sh; done

for yaml in $Path_working_directory/annotation/scipio/scipio_query_thr/*.yaml; do echo "yaml2gff.1.4.pl $yaml > ${yaml%.yaml}.gff" >> $Path_working_directory/annotation/scipio/script_yamltogff.sh; done

cat $Path_working_directory/annotation/scipio/script_yamltogff.sh | parallel --jobs=$CPU
