#!/bin/sh

# Command to use:
#Annotation_Busco.sh [Path_working_directory] [CPU] [odb_BUSCO]

### Annotation step

# Definition of the access path to the working directory:
Path_working_directory=$1

# Definition of the number of CPUs:
CPU=$2

# odb library
odb=$3

# Creation of directories for BUSCO annotation:
mkdir $Path_working_directory/annotation/busco
mkdir $Path_working_directory/annotation/busco/busco_outputs
mkdir $Path_working_directory/annotation/busco/busco_genomes

# bbmap path
#export PATH=$PATH:/bin/bbmap/ (run if busco error message about bbmap)

# Execution of the annotation
counter=1; for assembly in $(ls $Path_working_directory/assemblies/); do species="$assembly%.*"; echo "START: ${species}"; echo "Species n°$counter"; busco -i $Path_working_directory/assemblies/${assembly} --out_path $Path_working_directory/annotation/busco/busco_outputs/ -o busco_${species} -l $odb -m genome --metaeuk -c $CPU; ((counter++)); done

# Creation of a csv file summarising busco results for all species
echo "Species;Number_of_complete_and_single_copy_BUSCOs_(S);Percentage_of_complete_and_single_copy_BUSCOs_(S)" > $Path_working_directory/annotation/busco/busco_results_summary.csv; for dir in $(ls $Path_working_directory/annotation/busco/busco_outputs/); do if [ ! -d "$dir" ]; then echo "$dir is not a directory"; elif [ "$dir" == "busco_downloads" ]; then echo "$dir is equal to 'busco_downloads'"; else num_S=$(grep "Complete and single-copy BUSCOs (S)" $Path_working_directory/annotation/busco/busco_outputs/$dir/short_summary*.txt | sed 's/^[[:space:]]*\([0-9]\+\).*$/\1/'); percent_S=$(grep -E 'C:[0-9]+(\.[0-9]+)?%\[S:[0-9]+(\.[0-9]+)?%,D:[0-9]+(\.[0-9]+)?%\],F:[0-9]+(\.[0-9]+)?%,M:[0-9]+(\.[0-9]+)?%,n:[0-9]+' $Path_working_directory/annotation/busco/busco_outputs/$dir/short_summary*.txt | sed 's/.*S:\([0-9.]\+\)%,.*/\1/'); echo "$dir;$num_S;$percent_S" >> $Path_working_directory/annotation/busco/busco_results_summary.csv; fi; done

# Concatenation of single copy genes to obtain a protein set for each species
for assembly in $(ls $Path_working_directory/assemblies/) ; do species="$assembly%.*"; for faa in $Path_working_directory/annotation/busco/busco_outputs/busco_${species}/run_${odb}/busco_sequences/single_copy_busco_sequences/*.faa; do gene=$(basename $faa .faa); sed "s/>/>Busco_${species}_${gene}_/" $faa >> $Path_working_directory/annotation/busco/busco_genomes/${species}.faa; done; done

for assembly in $(ls $Path_working_directory/assemblies/) ; do species="$assembly%.*"; for fna in $Path_working_directory/annotation/busco/busco_outputs/busco_${species}/run_${odb}/busco_sequences/single_copy_busco_sequences/*.fna; do gene=$(basename $fna .fna); sed "s/>/>Busco_${species}_${gene}_/" $fna >> $Path_working_directory/annotation/busco/busco_genomes/${species}.fna; done; done


