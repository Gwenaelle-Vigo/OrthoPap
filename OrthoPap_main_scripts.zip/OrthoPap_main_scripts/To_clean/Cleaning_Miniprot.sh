#!/bin/sh

# Command to use:
#Cleaning_Miniprot.sh [Path_working_directory] [CPU]

### Cleaning step

# Definition of the access path to the working directory:
Path_working_directory=$1

# Definition of the number of CPUs:
CPU=$2

# Creation of directories for cleaning:
mkdir -p $Path_working_directory/cleaning
mkdir $Path_working_directory/cleaning/phylter_miniprot
mkdir $Path_working_directory/cleaning/phylter_miniprot/alignment_phylter_miniprot
mkdir $Path_working_directory/cleaning/phylter_miniprot/treefiles


# Selected the OG names for which alignment worked
for OG in $(ls $Path_working_directory/alignment/align_miniprot/alignment_macse_miniprot/*); do nb_file=$(ls $Path_working_directory/alignment/align_miniprot/alignment_macse_miniprot/$OG | wc -l); if [ $nb_file -ge 10 ]; then echo "${OG%_macse}" >> $Path_working_directory/alignment/align_miniprot/List_orthogroup_names_post_alignment.txt; fi; done

# Transferring .aln files from alignment with macse
for OG in $(cat $Path_working_directory/alignment/align_miniprot/List_orthogroup_names_post_alignment.txt); do
    # Creation of sub-folders by alignment
    mkdir $Path_working_directory/cleaning/phylter_miniprot/alignment_phylter_miniprot/${OG}_phylter;
    # Copy of the alignment
    cp $Path_working_directory/alignment/align_miniprot/alignment_macse_miniprot/${OG}_macse/${OG}_macse_final_mask_align_NT.aln $Path_working_directory/cleaning/phylter_miniprot/alignment_phylter_miniprot/${OG}_phylter/;
    # Change ! to - because iqtree does not understand ! set by macse
    sed -i 's/!/-/g' $Path_working_directory/cleaning/phylter_miniprot/alignment_phylter_miniprot/${OG}_phylter/${OG}_macse_final_mask_align_NT.aln;
    # Creation of a copy to modify gene names so that they only contain the species name
    cp $Path_working_directory/cleaning/phylter_miniprot/alignment_phylter_miniprot/${OG}_phylter/${OG}_macse_final_mask_align_NT.aln $Path_working_directory/cleaning/phylter_miniprot/alignment_phylter_miniprot/${OG}_phylter/${OG}_macse_final_mask_align_NT_rename.aln
    # Loop to modify gene names into the copy file so that they only contain the species name
    for assembly in $(ls $Path_working_directory/assemblies/*) ; do species="$assembly%.*"; sed -i "s/>${sp}.*/>${sp}/" $Path_working_directory/cleaning/phylter_miniprot/alignment_phylter_miniprot/${OG}_phylter/${OG}_macse_final_mask_align_NT_rename.aln; done
    # Creation of a bash script to generate gene trees with iqtree
    echo "iqtree2 -m GTR+G4 -s $Path_working_directory/cleaning/phylter_miniprot/alignment_phylter_miniprot/${OG}_phylter/${OG}_macse_final_mask_align_NT_rename.aln -T 1" >> $Path_working_directory/cleaning/phylter_miniprot/IQTREE_miniprot.bash;
done

# Running IQTREE to generate gene trees (works much faster when run on 1 CPU per gene but in parallel)
cat $Path_working_directory/cleaning/phylter_miniprot/IQTREE_miniprot.bash | parallel --jobs=$CPU

# Recovering gene tree files
for dir in $(ls $Path_working_directory/cleaning/phylter_miniprot/alignment_phylter_miniprot/); do
    treefile="$Path_working_directory/cleaning/phylter_miniprot/alignment_phylter_miniprot/${dir}/${dir%_phylter}_macse_final_mask_align_NT_rename.aln.treefile";
    # Checks whether the file exists before copying it
    if [ -f "$treefile" ]; then
        # Creation of the file containing the concatenation of gene trees required by PhylteR
        cat "$treefile" >> $Path_working_directory/cleaning/phylter_miniprot/treefiles.tre;
        # Creation of the gene tree list with only OG names
        #Important: must be in the same order as the gene trees contained in the concatenated file "treefiles.tre" for PhylteR
        echo "${dir%_phylter}" >> $Path_working_directory/cleaning/phylter_miniprot/list_treefiles.txt;
    fi;
done

# Execution of PhylteR (to check: perhaps it needs to be run from the folder where the various necessary files are located)
Rscript $Path_working_directory/scripts/Script_PhylteR_miniprot.r 

# Create a copy of ‘_rename.aln’ as ‘_rename_pruned.aln
for dir in $(ls $Path_working_directory/cleaning/phylter_miniprot/alignment_phylter_miniprot/*); do cp $Path_working_directory/cleaning/phylter_miniprot/alignment_phylter_miniprot/${dir}/${dir%_phylter}_macse_final_mask_align_NT_rename.aln $Path_working_directory/cleaning/phylter_miniprot/alignment_phylter_miniprot/${dir}/${dir%_phylter}_macse_final_mask_align_NT_rename_pruned.aln; done

# removal of PhylteR outliers from alignments
phylterfile_path="$Path_working_directory/cleaning/phylter_miniprot/phylter_miniprot.out"  # path to the file containing species to be removed for each .aln file
folder_path="$Path_working_directory/cleaning/phylter_miniprot/alignment_phylter_miniprot" # path to the folder containing species folders

# Reading the PhylteR output file
while IFS=$'\t' read -r line; do
    # Ignore lines beginning with ‘#’.
    if [ "$(echo "$line" | cut -c1)" = "#" ]; then
        continue
    fi
    # Extract OG_name and seq_name values
    OG_name=$(echo "$line" | cut -f1)
    seq_name=$(echo "$line" | cut -f2)
    # Use sed to delete sequences classified as outlyer by phylter
    sed -i "/${seq_name}/{N;d;}" $folder_path/${OG_name}_phylter/${OG_name}_macse_final_mask_align_NT_rename_pruned.aln
    echo "$OG_name $seq_name" 
done < "$phylterfile_path"

# Deletion of folders for which alignment ‘rename_pruned’ contains less than 5 species
for dir in $(ls $Path_working_directory/cleaning/phylter_miniprot/alignment_phylter_miniprot/*); do num_sp=$(grep -c '^>' $Path_working_directory/cleaning/phylter_miniprot/alignment_phylter_miniprot/${dir}/${dir%_phylter}_macse_final_mask_align_NT_rename_pruned.aln); if [ $num_sp -lt 5 ]; then echo "${dir}" >> $Path_working_directory/cleaning/phylter_miniprot/alignment_phylter_miniprot/List_alignments_removed.txt; rm -r $Path_working_directory/cleaning/phylter_miniprot/alignment_phylter_miniprot/${dir}; fi; done
