#!/bin/sh

# Command to use:
#Orthology_Scipio.sh [Path_working_directory] [CPU]

### Search for orthologous genes step

# Definition of the access path to the working directory:
Path_working_directory=$1

# Definition of the number of CPUs:
CPU=$2

# Creation of directories for orthology:
mkdir -p $Path_working_directory/orthology
mkdir $Path_working_directory/orthology/OrthoF_scipio_faa/

# Recovery of fasta files (.faa)
for query in $(ls $Path_working_directory/annotation/queries/*.faa) ; do cp $Path_working_directory/annotation/queries/${query} $Path_working_directory/orthology/OrthoF_scipio_faa/; done

cp $Path_working_directory/annotation/scipio/scipio_genomes/*.faa $Path_working_directory/orthology/OrthoF_scipio_faa/; done

# OrthoFinder
~/bin/OrthoFinder/orthofinder -f $Path_working_directory/orthology/OrthoF_scipio_faa/ -M msa -T iqtree -o $Path_working_directory/orthology/OrthoF_Scipio_faa/OrthoF_scipio_results -t $CPU
