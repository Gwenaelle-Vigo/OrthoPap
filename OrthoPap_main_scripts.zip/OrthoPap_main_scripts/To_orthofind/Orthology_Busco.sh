#!/bin/sh

# Command to use:
#Orthology_Busco.sh [Path_working_directory] [CPU]

### Search for orthologous genes step

# Definition of the access path to the working directory:
Path_working_directory=$1

# Definition of the number of CPUs:
CPU=$2

# Creation of directories for orthology:
mkdir -p $Path_working_directory/orthology
mkdir $Path_working_directory/orthology/OrthoF_busco_faa/

# Recovery of fasta files (.faa)
for query_path in $(ls $Path_working_directory/annotation/queries/*.faa) ; do query=$(basename "$query_path"); cp $Path_working_directory/annotation/queries/${query} $Path_working_directory/orthology/OrthoF_busco_faa/; done

cp $Path_working_directory/annotation/busco/busco_genomes/*.faa $Path_working_directory/orthology/OrthoF_busco_faa/; done

# OrthoFinder
~/bin/OrthoFinder/orthofinder -f $Path_working_directory/orthology/OrthoF_busco_faa/ -M msa -T iqtree -o $Path_working_directory/orthology/OrthoF_Busco_faa/OrthoF_busco_results -t $CPU
