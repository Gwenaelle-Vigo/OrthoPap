#!/bin/sh

# Command to use:
#Installation.sh [Path_working_directory] [Path_to_assembly_folder] [Path_to_query_folder]

# Definition of the access path to the working directory:
Path_working_directory=$1

# Definition of the access path to the assembly directory:
Path_to_assembly_folder=$2

# Definition of the access path to the query directory:
Path_to_query_folder=$2

# Creation of initial directories:
mkdir $Path_working_directory/assemblies
mkdir $Path_working_directory/annotation
mkdir $Path_working_directory/annotation/queries

# Recovery of assemblies
cp $Path_to_assembly_folder/* $Path_working_directory/assemblies/

# Recovery and renaming of queries
query_names=(query_one query_two query_thr); counter=0; for query in $(ls $Path_to_query_folder/*.faa); do species="$query%.*"; sed "s/>/>Query_${species}_/" $Path_to_query_folder/$query > $Path_working_directory/annotation/queries/${query_names[$counter]}.faa; ((counter++)); done

query_names=(query_one query_two query_thr); counter=0; for query in $(ls $Path_to_query_folder/*.fna); do species="$query%.*"; sed "s/>/>Query_${species}_/" $Path_to_query_folder/$query > $Path_working_directory/annotation/queries/${query_names[$counter]}.fna; ((counter++)); done
