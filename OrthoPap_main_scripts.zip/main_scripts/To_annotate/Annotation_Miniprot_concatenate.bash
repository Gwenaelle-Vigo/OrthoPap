#!/bin/sh

# Command to use:
#Annotation_Miniprot_concatenate.bash [Path_working_directory]

# Definition of the access path to the working directory:
Path_working_directory=$1

# Species used to query for Miniprot:
sp1=one
sp2=two
sp3=thr

# reuniting gff output files and transforming into fasta files:
for assembly in $(ls $Path_working_directory/assemblies/*); do 
    # keep the species name
    sp="$assembly%.*";
    # create a directory for each species
    mkdir $Path_working_directory/annotation/miniprot/miniprot_query_cat/gfftofasta_${sp};
    # move into the species directory
    cd $Path_working_directory/annotation/miniprot/miniprot_query_cat/gfftofasta_${sp};
    
    echo "SUMMARY FILE: concatenation of Miniprot outputs" >> concatenation_${sp}.out;
    echo "SPECIES: $sp" >> concatenation_${sp}.out;
    echo "INFO: gfftogff_${sp} directory has been created" >> concatenation_${sp}.out;
    
    # copy gff files
    cp $Path_working_directory/annotation/miniprot/miniprot_query_${sp1}/miniprot_${sp}.gff $Path_working_directory/annotation/miniprot/miniprot_query_cat/gfftofasta_${sp}/miniprot_${sp}_${sp1}.gff;
    cp $Path_working_directory/annotation/miniprot/miniprot_query_${sp2}/miniprot_${sp}.gff $Path_working_directory/annotation/miniprot/miniprot_query_cat/gfftofasta_${sp}/miniprot_${sp}_${sp2}.gff;
    cp $Path_working_directory/annotation/miniprot/miniprot_query_${sp3}/miniprot_${sp}.gff $Path_working_directory/annotation/miniprot/miniprot_query_cat/gfftofasta_${sp}/miniprot_${sp}_${sp3}.gff;
    echo "INFO: GFF files from references $sp1, $sp2 and $sp3 have been copied" >> concatenation_${sp}.out;
    
    # extract CDS and rename gene
    grep -P "\tCDS\t" miniprot_${sp}_${sp1}.gff | sed "s/;Rank/_${sp1};Rank/" | bedtools sort > ${sp}_${sp1}_CDS.gff;
    grep -P "\tCDS\t" miniprot_${sp}_${sp2}.gff | sed "s/;Rank/_${sp2};Rank/" | bedtools sort > ${sp}_${sp2}_CDS.gff;
    grep -P "\tCDS\t" miniprot_${sp}_${sp3}.gff | sed "s/;Rank/_${sp3};Rank/" | bedtools sort > ${sp}_${sp3}_CDS.gff;
    
    # remove CDS include in an other CDS
    bedtools window -a ${sp}_${sp1}_CDS.gff -b ${sp}_${sp1}_CDS.gff -w 0 > tmp;
    $Path_working_directory/scripts/listAlternativeTranscript2.py tmp > tmp2;
    $Path_working_directory/scripts/ExcludeCDSFromGFF.py ${sp}_${sp1}_CDS.gff ./tmp2 > ${sp}_${sp1}_CDS_clean.gff;
    
    # remove CDS include in an other CDS
    bedtools window -a ${sp}_${sp2}_CDS.gff -b ${sp}_${sp2}_CDS.gff -w 0 > tmp;
    $Path_working_directory/scripts/listAlternativeTranscript2.py tmp > tmp2;
    $Path_working_directory/scripts/ExcludeCDSFromGFF.py ${sp}_${sp2}_CDS.gff ./tmp2 > ${sp}_${sp2}_CDS_clean.gff;
    
    # remove CDS include in an other CDS
    bedtools window -a ${sp}_${sp3}_CDS.gff -b ${sp}_${sp3}_CDS.gff -w 0 > tmp;
    $Path_working_directory/scripts/listAlternativeTranscript2.py tmp > tmp2;
    $Path_working_directory/scripts/ExcludeCDSFromGFF.py ${sp}_${sp3}_CDS.gff ./tmp2 > ${sp}_${sp3}_CDS_clean.gff;
    
    # concatenation of the gff files for each query
    cat ${sp}_${sp1}_CDS_clean.gff ${sp}_${sp2}_CDS_clean.gff ${sp}_${sp3}_CDS_clean.gff | bedtools sort > ${sp}_${sp1}${sp2}${sp3}_CDS.gff;
    
    # remove CDS include in an other CDS
    bedtools window -a ${sp}_${sp1}${sp2}${sp3}_CDS.gff -b ${sp}_${sp1}${sp2}${sp3}_CDS.gff -w 0 > tmp;
    $Path_working_directory/scripts/listAlternativeTranscript2.py tmp > tmp2
    $Path_working_directory/scripts/ExcludeCDSFromGFF.py ${sp}_${sp1}${sp2}${sp3}_CDS.gff ./tmp2 > ${sp}_${sp1}${sp2}${sp3}_CDS_clean.gff;
    
    # information retrieval
    nb_CDS=$(cut -f9 ${sp}_${sp1}${sp2}${sp3}_CDS.gff | cut -d";" -f1 | sort -u | wc -l);
    echo "INFO: The GFF file contains $nb_CDS cds" >> concatenation_${sp}.out;
    
    nb_CDS_clean=$(cut -f9 ${sp}_${sp1}${sp2}${sp3}_CDS_clean.gff | cut -d";" -f1 | sort -u | wc -l);
    echo "INFO: The cleaned GFF file contains $nb_CDS_clean cds" >> concatenation_${sp}.out;
    
    # puts the gene's name in column 3 of the GFF
    $Path_working_directory/scripts/putIDinNameGFF.py -f ${sp}_${sp1}${sp2}${sp3}_CDS_clean.gff > ${sp}_exon.gff;

    # converts GFF to exons
    bedtools getfasta -s -name -fi $assembly_path -bed ${sp}_exon.gff > ${sp}_exons.fasta;
    
    cut -d"_" -f1,2 ${sp}_exons.fasta > tmp && mv tmp ${sp}_exons.fasta;

    # concatenates exons to transcripts
    $Path_working_directory/scripts/concateExonFromBedtoolsGetFasta2_forCat.py ${sp}_exons.fasta > ${sp}_Transcript.fasta;
    
    # sort the gff
    bedtools sort -i ${sp}_exon.gff > ${sp}_exon_sort.gff;

    # retrieve list of gene without overlapping exons
    $Path_working_directory/scripts/SelectOverlappingExonGFFsort_forCat.py ${sp}_exon_sort.gff > ${sp}_gene2keep.txt;
    
    # retrieve sequences according to the list of genes to keep
    $Path_working_directory/scripts/SelectSeq.py -l ${sp}_gene2keep.txt -f ${sp}_Transcript.fasta -c partial -o ${sp}_Transcript_uniq.fasta;
    
    # conversion of nucleotide sequences into protein
    transeq -sequence ${sp}_Transcript_uniq.fasta -outseq ${sp}_Transcript_uniq.faa;
    
    # Add '_1' at the end of the unique fna file
    sed -i '/^>/s/$/_1/' ${sp}_Transcript_uniq.fasta
    
    # information retrieval
    nb_Transcript_uniq=$(grep -c "^>" ${sp}_Transcript_uniq.faa);
    echo "INFO: The FASTA file contains $nb_Transcript_uniq transcripts" >> concatenation_${sp}.out;
    
    # sort faa sequence names
    grep '^>' ${sp}_Transcript_uniq.faa | sed 's/>//'| sort > List_Transcript_uniq_sort.txt;
    
    # specify redundant sequence names in the list while preserving the origin of the query
    $Path_working_directory/scripts/RenameTranscriptRedundants_forList.py List_Transcript_uniq_sort.txt List_Transcript_uniq_rename.txt;
    
    # specify redundant sequence names in the faa while preserving the origin of the query    
    $Path_working_directory/scripts/RenameTranscriptRedundants_forFasta.py ${sp}_Transcript_uniq.faa ${sp}_Transcript_uniq_rename.faa;
    
    # specify redundant sequence names in the fna while preserving the origin of the query
    $Path_working_directory/scripts/RenameTranscriptRedundants_forFasta.py ${sp}_Transcript_uniq.fasta ${sp}_Transcript_uniq_rename.fna;
    
    # retrieve faa sequences according to the list of genes to keep
    $Path_working_directory/scripts/SelectSeq.py -f ${sp}_Transcript_uniq_rename.faa -l List_Transcript_uniq_rename.txt -c partial -o ${sp}_Transcript_uniq_seqperline.faa;
    
    grep -A1 -E '>[M][P][0-9]{6}_[A-Za-z]{4}_1' ${sp}_Transcript_uniq_seqperline.faa > ${sp}_Transcript_uniq_final.faa;
    
    # information retrieval
    nb_Transcript_uniq_final_faa=$(grep -c "^>" ${sp}_Transcript_uniq_final.faa);
    echo "INFO: The final FASTA (faa) file contains $nb_Transcript_uniq_final_faa unique transcripts" >> concatenation_${sp}.out;
    
    # retrieve fna sequences according to the list of genes to keep
    $Path_working_directory/scripts/SelectSeq.py -f ${sp}_Transcript_uniq_rename.fna -l List_Transcript_uniq_rename.txt -c partial -o ${sp}_Transcript_uniq_seqperline.fna;
    
    grep -A1 -E '>[M][P][0-9]{6}_[A-Za-z]{4}_1' ${sp}_Transcript_uniq_seqperline.fna > ${sp}_Transcript_uniq_final.fna;
    
    # information retrieval
    nb_Transcript_uniq_final_fna=$(grep -c "^>" ${sp}_Transcript_uniq_final.fna);
    echo "INFO: The final FASTA (fna) file contains $nb_Transcript_uniq_final_fna unique transcripts" >> concatenation_${sp}.out;
    
    # renames sequences
    sed -i "s/>/>Miniprot_${sp}_/" ${sp}_Transcript_uniq_final.faa;
    sed -i "s/>/>Miniprot_${sp}_/" ${sp}_Transcript_uniq_final.fna;
    
    #copy fasta files (fna and faa) to an upstream folder in the path
    cp ${sp}_Transcript_uniq_final.faa $Path_working_directory/annotation/miniprot/miniprot_genomes/${sp}.faa;
    cp ${sp}_Transcript_uniq_final.fna $Path_working_directory/annotation/miniprot/miniprot_genomes/${sp}.fna;
        
done
    
